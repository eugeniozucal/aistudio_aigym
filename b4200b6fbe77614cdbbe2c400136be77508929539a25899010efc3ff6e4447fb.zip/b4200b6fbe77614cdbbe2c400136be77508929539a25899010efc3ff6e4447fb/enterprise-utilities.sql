-- enterprise-utilities.sql
-- Enterprise Database Utility Functions
-- Author: MiniMax Agent
-- Version: 1.0

-- Function to export organization data for migrations
CREATE OR REPLACE FUNCTION export_organization_data(org_id UUID)
RETURNS JSONB AS $$
DECLARE
    result JSONB := '{}';
BEGIN
    -- Export organization metadata
    SELECT to_jsonb(o) INTO result
    FROM organizations o
    WHERE o.id = org_id;
    
    -- Add users
    result := result || jsonb_build_object(
        'users', (
            SELECT jsonb_agg(to_jsonb(up))
            FROM user_profiles up
            WHERE up.organization_id = org_id
        )
    );
    
    -- Add content
    result := result || jsonb_build_object(
        'content', (
            SELECT jsonb_agg(to_jsonb(ci))
            FROM content_items ci
            WHERE ci.organization_id = org_id
        )
    );
    
    -- Add conversations (last 90 days)
    result := result || jsonb_build_object(
        'conversations', (
            SELECT jsonb_agg(
                to_jsonb(c) || jsonb_build_object(
                    'messages', (
                        SELECT jsonb_agg(to_jsonb(cm))
                        FROM conversation_messages cm
                        WHERE cm.conversation_id = c.id
                    )
                )
            )
            FROM conversations c
            JOIN user_profiles up ON c.user_id = up.id
            WHERE up.organization_id = org_id
            AND c.started_at > NOW() - INTERVAL '90 days'
        )
    );
    
    RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Function to verify backup integrity
CREATE OR REPLACE FUNCTION verify_backup_integrity()
RETURNS TABLE (
    table_name TEXT,
    record_count BIGINT,
    last_updated TIMESTAMPTZ,
    backup_status TEXT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        'user_profiles'::TEXT,
        COUNT(*)::BIGINT,
        MAX(updated_at),
        CASE WHEN COUNT(*) > 0 THEN 'OK' ELSE 'EMPTY' END::TEXT
    FROM user_profiles
    UNION ALL
    SELECT 
        'content_items'::TEXT,
        COUNT(*)::BIGINT,
        MAX(updated_at),
        CASE WHEN COUNT(*) > 0 THEN 'OK' ELSE 'EMPTY' END::TEXT
    FROM content_items
    UNION ALL
    SELECT 
        'conversations'::TEXT,
        COUNT(*)::BIGINT,
        MAX(last_message_at),
        CASE WHEN COUNT(*) > 0 THEN 'OK' ELSE 'EMPTY' END::TEXT
    FROM conversations;
END;
$$ LANGUAGE plpgsql;

-- Performance monitoring view
CREATE OR REPLACE VIEW performance_summary AS
SELECT 
    query,
    calls,
    total_time,
    mean_time,
    rows,
    100.0 * shared_blks_hit / nullif(shared_blks_hit + shared_blks_read, 0) AS hit_percent
FROM pg_stat_statements 
WHERE pg_stat_statements.query NOT LIKE '%pg_stat_statements%'
ORDER BY total_time DESC
LIMIT 20;

-- Table performance view
CREATE OR REPLACE VIEW table_performance AS
SELECT 
    schemaname,
    tablename,
    seq_scan,
    seq_tup_read,
    idx_scan,
    idx_tup_fetch,
    n_tup_ins,
    n_tup_upd,
    n_tup_del,
    n_live_tup,
    n_dead_tup,
    last_vacuum,
    last_autovacuum,
    last_analyze,
    last_autoanalyze,
    CASE 
        WHEN seq_scan > 0 AND idx_scan > 0 THEN 
            ROUND((idx_scan::NUMERIC / (seq_scan + idx_scan)) * 100, 2)
        ELSE 0
    END as index_usage_percent
FROM pg_stat_user_tables
WHERE schemaname = 'public'
ORDER BY seq_tup_read DESC;

-- Unused indexes view
CREATE OR REPLACE VIEW unused_indexes AS
SELECT 
    schemaname,
    tablename,
    indexname,
    idx_scan,
    pg_size_pretty(pg_relation_size(indexrelid)) as index_size,
    'DROP INDEX ' || indexname || ';' as drop_statement
FROM pg_stat_user_indexes
WHERE idx_scan = 0
AND indexname NOT LIKE '%_pkey'
AND schemaname = 'public'
ORDER BY pg_relation_size(indexrelid) DESC;

-- Function to suggest missing indexes
CREATE OR REPLACE FUNCTION suggest_missing_indexes()
RETURNS TABLE (
    table_name TEXT,
    seq_scan_count BIGINT,
    rows_read BIGINT,
    suggested_optimization TEXT
) AS $$
BEGIN
    RETURN QUERY
    WITH table_scans AS (
        SELECT 
            schemaname,
            tablename,
            seq_scan,
            seq_tup_read,
            idx_scan,
            CASE 
                WHEN idx_scan > 0 THEN (idx_scan::NUMERIC / (seq_scan + idx_scan)) * 100
                ELSE 0
            END as index_usage_percent
        FROM pg_stat_user_tables
        WHERE seq_scan > 1000 
        AND seq_tup_read > 100000
        AND schemaname = 'public'
    )
    SELECT 
        ts.tablename::TEXT,
        ts.seq_scan,
        ts.seq_tup_read,
        CASE 
            WHEN ts.index_usage_percent < 50 THEN 
                'Consider adding indexes - low index usage (' || ROUND(ts.index_usage_percent, 1) || '%)'
            WHEN ts.seq_tup_read > 1000000 THEN
                'High sequential scan volume - analyze query patterns'
            ELSE
                'Monitor query patterns for optimization opportunities'
        END::TEXT
    FROM table_scans ts
    ORDER BY ts.seq_tup_read DESC;
END;
$$ LANGUAGE plpgsql;

-- Function to check performance thresholds
CREATE TABLE IF NOT EXISTS performance_thresholds (
    metric_name TEXT PRIMARY KEY,
    warning_threshold NUMERIC,
    critical_threshold NUMERIC,
    check_interval INTERVAL DEFAULT '5 minutes'
);

-- Insert default thresholds
INSERT INTO performance_thresholds (metric_name, warning_threshold, critical_threshold) VALUES
('avg_query_time_ms', 100, 500),
('connection_count', 150, 190),
('cache_hit_ratio', 90, 85),
('table_bloat_ratio', 20, 40)
ON CONFLICT (metric_name) DO NOTHING;

-- Performance alert function
CREATE OR REPLACE FUNCTION check_performance_alerts()
RETURNS TABLE (
    alert_level TEXT,
    metric_name TEXT,
    current_value NUMERIC,
    threshold_value NUMERIC,
    recommendation TEXT
) AS $$
DECLARE
    current_connections INTEGER;
    avg_query_time NUMERIC;
BEGIN
    -- Check connection count
    SELECT COUNT(*) INTO current_connections 
    FROM pg_stat_activity 
    WHERE state = 'active';
    
    RETURN QUERY
    SELECT 
        CASE 
            WHEN current_connections > pt.critical_threshold THEN 'CRITICAL'
            WHEN current_connections > pt.warning_threshold THEN 'WARNING'
            ELSE 'OK'
        END::TEXT,
        pt.metric_name,
        current_connections::NUMERIC,
        CASE 
            WHEN current_connections > pt.critical_threshold THEN pt.critical_threshold
            ELSE pt.warning_threshold 
        END,
        'Consider connection pooling or increasing max_connections'::TEXT
    FROM performance_thresholds pt
    WHERE pt.metric_name = 'connection_count'
    AND current_connections > pt.warning_threshold;
    
    -- Check query performance (if pg_stat_statements is available)
    BEGIN
        SELECT AVG(mean_time) INTO avg_query_time
        FROM pg_stat_statements
        WHERE calls > 10;
        
        IF avg_query_time IS NOT NULL THEN
            RETURN QUERY
            SELECT 
                CASE 
                    WHEN avg_query_time > pt.critical_threshold THEN 'CRITICAL'
                    WHEN avg_query_time > pt.warning_threshold THEN 'WARNING'
                    ELSE 'OK'
                END::TEXT,
                pt.metric_name,
                ROUND(avg_query_time, 2),
                CASE 
                    WHEN avg_query_time > pt.critical_threshold THEN pt.critical_threshold
                    ELSE pt.warning_threshold 
                END,
                'Optimize slow queries - check pg_stat_statements'::TEXT
            FROM performance_thresholds pt
            WHERE pt.metric_name = 'avg_query_time_ms'
            AND avg_query_time > pt.warning_threshold;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            -- pg_stat_statements not available
            NULL;
    END;
END;
$$ LANGUAGE plpgsql;

-- Automated maintenance function
CREATE OR REPLACE FUNCTION automated_maintenance()
RETURNS VOID AS $$
DECLARE
    table_record RECORD;
    analyze_threshold INTEGER := 1000;
    vacuum_threshold INTEGER := 5000;
BEGIN
    -- Analyze tables with significant changes
    FOR table_record IN
        SELECT schemaname, tablename, n_tup_ins + n_tup_upd + n_tup_del as changes
        FROM pg_stat_user_tables
        WHERE schemaname = 'public'
        AND n_tup_ins + n_tup_upd + n_tup_del > analyze_threshold
    LOOP
        EXECUTE 'ANALYZE ' || quote_ident(table_record.schemaname) || '.' || quote_ident(table_record.tablename);
        RAISE NOTICE 'Analyzed table %.%', table_record.schemaname, table_record.tablename;
    END LOOP;
    
    -- Vacuum tables with high dead tuple ratio
    FOR table_record IN
        SELECT schemaname, tablename, n_dead_tup, n_live_tup
        FROM pg_stat_user_tables
        WHERE schemaname = 'public'
        AND n_dead_tup > vacuum_threshold
        AND n_dead_tup::FLOAT / NULLIF(n_live_tup + n_dead_tup, 0) > 0.1
    LOOP
        EXECUTE 'VACUUM ' || quote_ident(table_record.schemaname) || '.' || quote_ident(table_record.tablename);
        RAISE NOTICE 'Vacuumed table %.%', table_record.schemaname, table_record.tablename;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- System health check function
CREATE OR REPLACE FUNCTION system_health_check()
RETURNS TABLE (
    check_name TEXT,
    status TEXT,
    details JSONB
) AS $$
BEGIN
    -- Check RLS policies
    RETURN QUERY
    SELECT 
        'RLS Policies'::TEXT,
        CASE WHEN COUNT(*) >= 10 THEN 'OK' ELSE 'WARNING' END::TEXT,
        jsonb_build_object(
            'policy_count', COUNT(*),
            'tables_with_rls', COUNT(DISTINCT tablename)
        )
    FROM pg_policies 
    WHERE schemaname = 'public';
    
    -- Check critical indexes
    RETURN QUERY
    SELECT 
        'Performance Indexes'::TEXT,
        CASE WHEN COUNT(*) >= 20 THEN 'OK' ELSE 'WARNING' END::TEXT,
        jsonb_build_object(
            'index_count', COUNT(*),
            'total_size', pg_size_pretty(SUM(pg_relation_size(indexrelid)))
        )
    FROM pg_indexes
    WHERE schemaname = 'public';
    
    -- Check table sizes
    RETURN QUERY
    SELECT 
        'Table Sizes'::TEXT,
        'INFO'::TEXT,
        jsonb_object_agg(
            tablename, 
            pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename))
        )
    FROM pg_tables
    WHERE schemaname = 'public'
    AND tablename IN ('user_profiles', 'content_items', 'conversations', 'conversation_messages');
END;
$$ LANGUAGE plpgsql;

-- Emergency rollback function
CREATE OR REPLACE FUNCTION emergency_rollback()
RETURNS VOID AS $$
BEGIN
    -- Disable RLS on critical tables temporarily
    ALTER TABLE user_profiles DISABLE ROW LEVEL SECURITY;
    ALTER TABLE content_items DISABLE ROW LEVEL SECURITY;
    ALTER TABLE conversations DISABLE ROW LEVEL SECURITY;
    ALTER TABLE content_assignments DISABLE ROW LEVEL SECURITY;
    
    -- Log rollback event
    INSERT INTO audit_logs (
        table_name,
        operation, 
        new_values,
        created_at
    ) VALUES (
        'system',
        'ROLLBACK',
        jsonb_build_object(
            'event', 'emergency_rollback',
            'timestamp', NOW(),
            'reason', 'Production issue - emergency rollback executed'
        ),
        NOW()
    );
    
    RAISE NOTICE 'Emergency rollback executed at %', NOW();
END;
$$ LANGUAGE plpgsql;