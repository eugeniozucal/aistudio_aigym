/**
 * Authentication Utilities
 * Helper functions for authentication operations
 */

/**
 * Route access matrix
 * Defines which roles can access which route patterns
 */
export const ROUTE_ACCESS_MATRIX = {
  '/admin/*': ['admin'],
  '/user/*': ['community_user', 'admin'],
  '/community/*': ['community_user', 'admin'],
  '/login': ['public'],
  '/': ['authenticated']
} as const

/**
 * Authentication error types
 */
export const AUTH_ERRORS = {
  INVALID_CREDENTIALS: 'Invalid email or password. Please check your credentials and try again.',
  EMAIL_NOT_CONFIRMED: 'Please verify your email address before signing in. Check your inbox for a verification link.',
  TOO_MANY_REQUESTS: 'Too many login attempts. Please wait a few minutes before trying again.',
  USER_NOT_FOUND: 'No account found with this email address.',
  ROLE_DETECTION_FAILED: 'Authentication succeeded but role detection failed. Please contact support.',
  PERMISSION_DENIED: 'You do not have permission to access this resource.',
  SESSION_EXPIRED: 'Your session has expired. Please sign in again.',
  UNEXPECTED_ERROR: 'An unexpected error occurred. Please try again.'
} as const

/**
 * Event types for audit logging
 */
export const AUTH_EVENT_TYPES = {
  LOGIN_SUCCESS: 'login_success',
  LOGIN_FAILED: 'login_failed',
  LOGOUT: 'logout',
  ROLE_ASSIGNED: 'role_assigned',
  ROLE_CHANGED: 'role_changed',
  ROUTE_ACCESS: 'route_access',
  PERMISSION_DENIED: 'permission_denied',
  SESSION_EXPIRED: 'session_expired'
} as const

/**
 * User role types
 */
export type UserRole = 'admin' | 'community_user'

/**
 * Route patterns
 */
export type RoutePattern = keyof typeof ROUTE_ACCESS_MATRIX

/**
 * Check if a route requires authentication
 */
export function requiresAuthentication(route: string): boolean {
  return !route.includes('/login') && !route.includes('/signup')
}

/**
 * Check if a route is admin-only
 */
export function isAdminRoute(route: string): boolean {
  return route.startsWith('/admin')
}

/**
 * Check if a route is community-accessible
 */
export function isCommunityRoute(route: string): boolean {
  return route.startsWith('/user') || route.startsWith('/community')
}

/**
 * Get default route for user role
 */
export function getDefaultRoute(role: UserRole): string {
  switch (role) {
    case 'admin':
      return '/admin/dashboard'
    case 'community_user':
      return '/user/community'
    default:
      return '/login'
  }
}

/**
 * Format user display name
 */
export function formatUserDisplayName(email: string, firstName?: string, lastName?: string): string {
  if (firstName && lastName) {
    return `${firstName} ${lastName}`
  }
  if (firstName) {
    return firstName
  }
  return email.split('@')[0]
}

/**
 * Validate email format
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

/**
 * Validate password strength
 */
export function validatePassword(password: string): {
  isValid: boolean
  errors: string[]
} {
  const errors: string[] = []

  if (password.length < 8) {
    errors.push('Password must be at least 8 characters long')
  }

  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter')
  }

  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter')
  }

  if (!/[0-9]/.test(password)) {
    errors.push('Password must contain at least one number')
  }

  return {
    isValid: errors.length === 0,
    errors
  }
}

/**
 * Generate a secure random token
 */
export function generateSecureToken(length: number = 32): string {
  const charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  let result = ''
  for (let i = 0; i < length; i++) {
    result += charset.charAt(Math.floor(Math.random() * charset.length))
  }
  return result
}

/**
 * Debounce function for API calls
 */
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timeoutId: NodeJS.Timeout
  return (...args: Parameters<T>) => {
    clearTimeout(timeoutId)
    timeoutId = setTimeout(() => func(...args), delay)
  }
}

/**
 * Format timestamp for display
 */
export function formatTimestamp(timestamp: string): string {
  const date = new Date(timestamp)
  return date.toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}