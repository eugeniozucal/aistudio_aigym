/**
 * Unified Content API Client - Complete implementation with advanced features
 * Based on comprehensive research findings for save/load architecture
 */

import { supabase } from '@/lib/supabase'
import { ContentItem, RepositoryType } from '@/lib/stores/contentStore'
import { z } from 'zod'

// API Response schemas
const apiResponseSchema = z.object({
  success: z.boolean(),
  data: z.any().optional(),
  error: z.string().optional(),
  code: z.string().optional()
})

const contentItemSchema = z.object({
  id: z.string().uuid(),
  workspace_id: z.string().uuid(),
  repository_type: z.enum(['wods', 'blocks', 'programs', 'ai_agents', 'videos', 'documents', 'prompts', 'automations', 'images', 'pdfs']),
  title: z.string().min(1).max(255),
  description: z.string().optional(),
  content: z.record(z.any()),
  metadata: z.record(z.any()),
  status: z.enum(['draft', 'published', 'archived']),
  folder_id: z.string().uuid().optional(),
  thumbnail_url: z.string().optional(),
  created_by: z.string().uuid(),
  updated_by: z.string().uuid(),
  created_at: z.string(),
  updated_at: z.string(),
  version: z.number().int().positive(),
  estimated_duration_minutes: z.number().int().optional(),
  difficulty_level: z.enum(['beginner', 'intermediate', 'advanced']).optional(),
  tags: z.array(z.string())
})

// Error types
export class APIError extends Error {
  constructor(
    message: string,
    public code?: string,
    public status?: number,
    public originalError?: any
  ) {
    super(message)
    this.name = 'APIError'
  }
}

export class ValidationError extends APIError {
  constructor(message: string, public validationErrors: string[]) {
    super(message, 'VALIDATION_ERROR')
    this.name = 'ValidationError'
  }
}

export class NetworkError extends APIError {
  constructor(message: string, originalError?: any) {
    super(message, 'NETWORK_ERROR', undefined, originalError)
    this.name = 'NetworkError'
  }
}

export class TimeoutError extends APIError {
  constructor(timeout: number) {
    super(`Request timed out after ${timeout}ms`, 'TIMEOUT_ERROR')
    this.name = 'TimeoutError'
  }
}

// API Configuration
const API_CONFIG = {
  wods: 'wods-api',
  blocks: 'workout-blocks-api',
  programs: 'programs-api',
  ai_agents: 'content-management-api',
  videos: 'content-management-api',
  documents: 'content-management-api',
  prompts: 'content-management-api',
  automations: 'content-management-api',
  images: 'content-management-api',
  pdfs: 'content-management-api'
}

// Timeout configuration
const REQUEST_TIMEOUT = 30000 // 30 seconds
const RETRY_ATTEMPTS = 3
const RETRY_DELAY = 1000 // 1 second

// Request deduplication map
const pendingRequests = new Map<string, Promise<any>>()

// Request queue for rate limiting
interface QueuedRequest {
  key: string
  promise: Promise<any>
  timestamp: number
}

const requestQueue: QueuedRequest[] = []
const MAX_CONCURRENT_REQUESTS = 5
let activeRequests = 0

// Utility function to create request key for deduplication
const createRequestKey = (endpoint: string, params?: Record<string, any>): string => {
  const paramsString = params ? JSON.stringify(params, Object.keys(params).sort()) : ''
  return `${endpoint}:${paramsString}`
}

// Request throttling
const throttleRequest = async (): Promise<void> => {
  if (activeRequests >= MAX_CONCURRENT_REQUESTS) {
    await new Promise(resolve => {
      const checkQueue = () => {
        if (activeRequests < MAX_CONCURRENT_REQUESTS) {
          resolve(undefined)
        } else {
          setTimeout(checkQueue, 100)
        }
      }
      checkQueue()
    })
  }
}

// Cleanup old pending requests
const cleanupPendingRequests = () => {
  const now = Date.now()
  const expiredKeys: string[] = []
  
  for (const [key, promise] of pendingRequests.entries()) {
    // Check if promise is settled or too old (5 minutes)
    if (now - parseInt(key.split(':')[0]) > 300000) {
      expiredKeys.push(key)
    }
  }
  
  expiredKeys.forEach(key => pendingRequests.delete(key))
}

// Generic API call wrapper with advanced features
const apiCall = async <T>(
  functionName: string,
  params: Record<string, any> = {},
  options: {
    timeout?: number
    retries?: number
    validate?: (data: any) => T
    skipDeduplication?: boolean
  } = {}
): Promise<T> => {
  const { 
    timeout = REQUEST_TIMEOUT, 
    retries = RETRY_ATTEMPTS, 
    validate,
    skipDeduplication = false
  } = options
  
  // Create request key for deduplication
  const requestKey = skipDeduplication ? 
    `${Date.now()}:${Math.random()}:${functionName}` : 
    createRequestKey(functionName, params)
  
  // Check if request is already pending (deduplication)
  if (!skipDeduplication && pendingRequests.has(requestKey)) {
    console.log(`Deduplicating request: ${functionName}`)
    return pendingRequests.get(requestKey)!
  }
  
  // Cleanup old requests periodically
  if (Math.random() < 0.1) { // 10% chance to cleanup
    cleanupPendingRequests()
  }
  
  const request = async (): Promise<T> => {
    // Wait for throttling
    await throttleRequest()
    activeRequests++
    
    let lastError: any
    
    try {
      for (let attempt = 0; attempt <= retries; attempt++) {
        try {
          console.log(`API Call: ${functionName}, Attempt: ${attempt + 1}/${retries + 1}`)
          
          // Create abort controller for timeout
          const abortController = new AbortController()
          const timeoutId = setTimeout(() => {
            abortController.abort()
          }, timeout)
          
          try {
            // Make the API call with timeout
            const response = await supabase.functions.invoke(functionName, {
              body: params
            })
            
            clearTimeout(timeoutId)
            
            // Handle Supabase function response
            if (response.error) {
              throw new APIError(
                response.error.message || 'API call failed',
                response.error.code || 'API_ERROR',
                500,
                response.error
              )
            }
            
            // Validate response structure
            let validatedResponse
            try {
              validatedResponse = apiResponseSchema.parse(response.data || response)
            } catch (parseError) {
              // If parsing fails, try to use the raw response
              validatedResponse = {
                success: true,
                data: response.data || response
              }
            }
            
            if (validatedResponse.success === false) {
              throw new APIError(
                validatedResponse.error || 'API call was not successful',
                validatedResponse.code
              )
            }
            
            // Apply custom validation if provided
            if (validate) {
              try {
                return validate(validatedResponse.data)
              } catch (validationError) {
                if (validationError instanceof z.ZodError) {
                  throw new ValidationError(
                    'Response validation failed',
                    validationError.errors.map(e => `${e.path.join('.')}: ${e.message}`)
                  )
                }
                throw validationError
              }
            }
            
            return validatedResponse.data as T
            
          } catch (error) {
            clearTimeout(timeoutId)
            
            // Handle abort/timeout
            if (error.name === 'AbortError') {
              throw new TimeoutError(timeout)
            }
            
            throw error
          }
          
        } catch (error) {
          lastError = error
          
          // Don't retry on validation errors or 4xx errors
          if (error instanceof ValidationError || 
              error instanceof TimeoutError ||
              (error instanceof APIError && error.status && error.status < 500)) {
            break
          }
          
          // Wait before retry (except on last attempt)
          if (attempt < retries) {
            const delay = RETRY_DELAY * Math.pow(2, attempt) // Exponential backoff
            console.log(`Retrying after ${delay}ms...`)
            await new Promise(resolve => setTimeout(resolve, delay))
          }
        }
      }
      
      // All retries exhausted
      throw lastError
      
    } finally {
      activeRequests--
    }
  }
  
  // Store the promise for deduplication
  const promise = request().finally(() => {
    // Remove from pending requests when complete
    pendingRequests.delete(requestKey)
  })
  
  if (!skipDeduplication) {
    pendingRequests.set(requestKey, promise)
  }
  
  return promise
}

// Type assertion helper for schema validation results
const assertContentItem = (data: any): ContentItem => {
  const parsed = contentItemSchema.parse(data)
  return parsed as ContentItem
}

// Content API functions
export const contentApi = {
  // Get content item by ID
  getById: async (id: string, repositoryType: RepositoryType): Promise<ContentItem> => {
    const functionName = API_CONFIG[repositoryType]
    
    try {
      const result = await apiCall(
        functionName,
        { action: 'get', id },
        {
          validate: (data) => {
            if (repositoryType === 'wods' || repositoryType === 'blocks') {
              // For legacy APIs, transform response to unified format
              return transformLegacyResponse(data, repositoryType)
            }
            return assertContentItem(data)
          }
        }
      )
      
      return result
    } catch (error) {
      console.error(`Failed to fetch ${repositoryType} with ID ${id}:`, error)
      throw new APIError(`Failed to fetch ${repositoryType} with ID ${id}: ${error}`)
    }
  },

  // List content items
  list: async (
    repositoryType: RepositoryType,
    filters: {
      workspaceId?: string
      folderId?: string
      status?: string
      limit?: number
      offset?: number
    } = {}
  ): Promise<ContentItem[]> => {
    const functionName = API_CONFIG[repositoryType]
    
    try {
      const result = await apiCall(
        functionName,
        { action: 'list', ...filters },
        {
          validate: (data) => {
            if (!Array.isArray(data)) {
              // Single item response
              const items = data ? [data] : []
              return items.map((item: any) => {
                if (repositoryType === 'wods' || repositoryType === 'blocks') {
                  return transformLegacyResponse(item, repositoryType)
                }
                return assertContentItem(item)
              })
            }
            
            return data.map((item: any) => {
              if (repositoryType === 'wods' || repositoryType === 'blocks') {
                return transformLegacyResponse(item, repositoryType)
              }
              return assertContentItem(item)
            })
          }
        }
      )
      
      return result
    } catch (error) {
      console.error(`Failed to list ${repositoryType}:`, error)
      throw new APIError(`Failed to list ${repositoryType}: ${error}`)
    }
  },

  // Create content item
  create: async (contentData: Omit<ContentItem, 'id' | 'created_at' | 'updated_at' | 'version'>): Promise<ContentItem> => {
    const functionName = API_CONFIG[contentData.repository_type]
    
    try {
      // Validate input data
      const validationResult = contentItemSchema.omit({ 
        id: true, 
        created_at: true, 
        updated_at: true, 
        version: true 
      }).safeParse(contentData)
      
      if (!validationResult.success) {
        throw new ValidationError(
          'Invalid content data',
          validationResult.error.errors.map(e => e.message)
        )
      }
      
      const result = await apiCall(
        functionName,
        { action: 'create', ...contentData },
        {
          validate: (data) => {
            if (contentData.repository_type === 'wods' || contentData.repository_type === 'blocks') {
              return transformLegacyResponse(data, contentData.repository_type)
            }
            return assertContentItem(data)
          }
        }
      )
      
      return result
    } catch (error) {
      console.error(`Failed to create ${contentData.repository_type}:`, error)
      throw new APIError(`Failed to create ${contentData.repository_type}: ${error}`)
    }
  },

  // Update content item
  update: async (
    id: string,
    repositoryType: RepositoryType,
    updates: Partial<ContentItem>
  ): Promise<ContentItem> => {
    const functionName = API_CONFIG[repositoryType]
    
    try {
      const result = await apiCall(
        functionName,
        { action: 'update', id, ...updates },
        {
          validate: (data) => {
            if (repositoryType === 'wods' || repositoryType === 'blocks') {
              return transformLegacyResponse(data, repositoryType)
            }
            return assertContentItem(data)
          }
        }
      )
      
      return result
    } catch (error) {
      console.error(`Failed to update ${repositoryType} with ID ${id}:`, error)
      throw new APIError(`Failed to update ${repositoryType} with ID ${id}: ${error}`)
    }
  },

  // Delete content item
  delete: async (id: string, repositoryType: RepositoryType): Promise<{ success: boolean }> => {
    const functionName = API_CONFIG[repositoryType]
    
    try {
      await apiCall(
        functionName,
        { action: 'delete', id }
      )
      
      return { success: true }
    } catch (error) {
      console.error(`Failed to delete ${repositoryType} with ID ${id}:`, error)
      throw new APIError(`Failed to delete ${repositoryType} with ID ${id}: ${error}`)
    }
  },

  // Auto-save functionality
  autoSave: async (
    contentId: string,
    sessionId: string,
    snapshotData: Record<string, any>,
    metadata: Record<string, any> = {}
  ): Promise<{ success: boolean }> => {
    try {
      await apiCall(
        'content-management-api',
        {
          action: 'auto_save',
          content_id: contentId,
          session_id: sessionId,
          snapshot_data: snapshotData,
          metadata
        },
        { skipDeduplication: true } // Don't deduplicate auto-save requests
      )
      
      return { success: true }
    } catch (error) {
      console.error('Auto-save failed:', error)
      throw new APIError(`Auto-save failed: ${error}`)
    }
  },

  // Get auto-save snapshots
  getAutoSaveSnapshots: async (
    contentId: string,
    sessionId: string
  ): Promise<Array<{ id: string; content: any; created_at: string }>> => {
    try {
      const result = await apiCall(
        'content-management-api',
        {
          action: 'get_auto_save_snapshots',
          content_id: contentId,
          session_id: sessionId
        }
      )
      
      return Array.isArray(result) ? result : []
    } catch (error) {
      console.error('Failed to get auto-save snapshots:', error)
      throw new APIError(`Failed to get auto-save snapshots: ${error}`)
    }
  },

  // Batch update functionality
  batchUpdate: async (
    updates: Array<{
      id: string
      repositoryType: RepositoryType
      updates: Partial<ContentItem>
    }>
  ): Promise<Array<{ success: boolean; data?: ContentItem; error?: string }>> => {
    const results = await Promise.allSettled(
      updates.map(async ({ id, repositoryType, updates: updateData }) => {
        try {
          const result = await contentApi.update(id, repositoryType, updateData)
          return { success: true, data: result }
        } catch (error) {
          return { 
            success: false, 
            error: error instanceof Error ? error.message : 'Unknown error' 
          }
        }
      })
    )
    
    return results.map(result => 
      result.status === 'fulfilled' ? result.value : { success: false, error: 'Request failed' }
    )
  }
}

// Legacy response transformer for WODs and Blocks
function transformLegacyResponse(data: any, repositoryType: RepositoryType): ContentItem {
  // Ensure we have a valid ID
  const id = data.id || `generated-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
  
  const baseTransform: ContentItem = {
    id,
    workspace_id: data.workspace_id || 'default-workspace',
    repository_type: repositoryType,
    title: data.title || 'Untitled',
    description: data.description || '',
    content: data.content || data,
    metadata: data.metadata || {},
    status: data.status || 'draft',
    folder_id: data.folder_id,
    thumbnail_url: data.thumbnail_url,
    created_by: data.created_by || data.user_id || 'system',
    updated_by: data.updated_by || data.user_id || 'system',
    created_at: data.created_at || new Date().toISOString(),
    updated_at: data.updated_at || new Date().toISOString(),
    version: data.version || 1,
    estimated_duration_minutes: data.estimated_duration_minutes || data.estimatedDuration,
    difficulty_level: data.difficulty_level || mapDifficultyLevel(data.difficulty),
    tags: data.tags || []
  }
  
  return baseTransform
}

// Map legacy difficulty numbers to new difficulty levels
function mapDifficultyLevel(difficulty: number | string): 'beginner' | 'intermediate' | 'advanced' {
  const difficultyNum = typeof difficulty === 'string' ? parseInt(difficulty) : difficulty
  
  if (difficultyNum <= 2) return 'beginner'
  if (difficultyNum <= 3) return 'intermediate'
  return 'advanced'
}

// Testing utilities
export const __testing__ = {
  clearCache: () => {
    pendingRequests.clear()
    requestQueue.length = 0
    activeRequests = 0
  },
  getPendingRequests: () => pendingRequests,
  getActiveRequests: () => activeRequests,
  getCacheSize: () => pendingRequests.size
}
