import { authService, type UserWithRole } from './auth-service'

/**
 * Role Management Service
 * Handles user role assignment and management operations
 */
export class RoleManagementService {
  private static instance: RoleManagementService

  private constructor() {}

  static getInstance(): RoleManagementService {
    if (!RoleManagementService.instance) {
      RoleManagementService.instance = new RoleManagementService()
    }
    return RoleManagementService.instance
  }

  /**
   * Assign a role to a user (admin only)
   */
  async assignRole(
    userId: string,
    role: 'admin' | 'community_user',
    communityId?: string
  ): Promise<{ success: boolean; error?: string }> {
    try {
      // Get current user to verify admin permissions
      const currentUser = await authService.getAuthenticatedUser()
      if (!currentUser || currentUser.role !== 'admin') {
        return {
          success: false,
          error: 'Only administrators can assign user roles'
        }
      }

      // Validate parameters
      if (role === 'community_user' && !communityId) {
        return {
          success: false,
          error: 'Community ID is required for community users'
        }
      }

      const success = await authService.assignUserRole({
        userId,
        role,
        communityId,
        assignedBy: currentUser.id
      })

      if (success) {
        return { success: true }
      } else {
        return {
          success: false,
          error: 'Failed to assign role. Please try again.'
        }
      }
    } catch (error) {
      console.error('Error in assignRole:', error)
      return {
        success: false,
        error: 'An unexpected error occurred while assigning the role'
      }
    }
  }

  /**
   * Get all users with their roles (admin only)
   */
  async getAllUsersWithRoles(): Promise<{
    success: boolean
    data?: any[]
    error?: string
  }> {
    try {
      // Verify admin permissions
      const currentUser = await authService.getAuthenticatedUser()
      if (!currentUser || currentUser.role !== 'admin') {
        return {
          success: false,
          error: 'Only administrators can view user roles'
        }
      }

      const data = await authService.getAllUserRoles()
      return {
        success: true,
        data
      }
    } catch (error) {
      console.error('Error in getAllUsersWithRoles:', error)
      return {
        success: false,
        error: 'Failed to retrieve user roles'
      }
    }
  }

  /**
   * Get authentication audit log (admin only)
   */
  async getAuditLog(): Promise<{
    success: boolean
    data?: any[]
    error?: string
  }> {
    try {
      // Verify admin permissions
      const currentUser = await authService.getAuthenticatedUser()
      if (!currentUser || currentUser.role !== 'admin') {
        return {
          success: false,
          error: 'Only administrators can view audit logs'
        }
      }

      const data = await authService.getAuthAuditLog()
      return {
        success: true,
        data
      }
    } catch (error) {
      console.error('Error in getAuditLog:', error)
      return {
        success: false,
        error: 'Failed to retrieve audit log'
      }
    }
  }

  /**
   * Check if user has specific permission
   */
  async hasPermission(
    permission: 'admin' | 'community_access' | 'role_management'
  ): Promise<boolean> {
    try {
      const user = await authService.getAuthenticatedUser()
      if (!user) return false

      switch (permission) {
        case 'admin':
          return user.role === 'admin'
        case 'community_access':
          return user.role === 'community_user' || user.role === 'admin'
        case 'role_management':
          return user.role === 'admin'
        default:
          return false
      }
    } catch (error) {
      console.error('Error checking permission:', error)
      return false
    }
  }

  /**
   * Get user's accessible communities
   */
  async getUserCommunities(userId?: string): Promise<any[]> {
    try {
      const targetUserId = userId || (await authService.getAuthenticatedUser())?.id
      if (!targetUserId) return []

      // This would typically query the user_communities table
      // For now, we'll return the user's primary community if they have one
      const user = await authService.getAuthenticatedUser()
      if (user?.communityId) {
        // In a real implementation, you'd fetch community details from the database
        return [{
          id: user.communityId,
          role: user.role === 'admin' ? 'admin' : 'member'
        }]
      }

      return []
    } catch (error) {
      console.error('Error getting user communities:', error)
      return []
    }
  }

  /**
   * Validate route access for current user
   */
  async validateRouteAccess(route: string): Promise<{
    hasAccess: boolean
    redirectTo?: string
    userRole?: string
  }> {
    try {
      const result = await authService.validateUserPermissions(route)
      if (!result) {
        return {
          hasAccess: false,
          redirectTo: '/login'
        }
      }

      return {
        hasAccess: result.hasAccess,
        redirectTo: result.redirectTo,
        userRole: result.userRole
      }
    } catch (error) {
      console.error('Error validating route access:', error)
      return {
        hasAccess: false,
        redirectTo: '/login'
      }
    }
  }
}

// Export singleton instance
export const roleManagementService = RoleManagementService.getInstance()