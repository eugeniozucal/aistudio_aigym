/**
 * URL Parameter Store - Type-safe URL parameter handling with Zod validation
 * Based on comprehensive research findings for save/load architecture
 */

import { create } from 'zustand'
import { immer } from 'zustand/middleware/immer'
import { z } from 'zod'
import { RepositoryType } from './contentStore'

// URL parameter schemas with Zod validation
export const urlParamsSchema = z.object({
  id: z.string().uuid().optional(),
  repo: z.enum(['wods', 'blocks', 'programs', 'ai_agents', 'videos', 'documents', 'prompts', 'automations', 'images', 'pdfs']).optional(),
  mode: z.enum(['edit', 'view', 'create']).optional(),
  page: z.string().optional(),
  folder: z.string().uuid().optional()
})

export type URLParams = z.infer<typeof urlParamsSchema>

export interface URLState {
  // Current URL parameters
  params: URLParams
  // Validation state
  isValid: boolean
  validationErrors: string[]
  // Navigation state
  isNavigating: boolean
}

export interface URLActions {
  // Parameter management
  setParams: (params: Partial<URLParams>) => void
  updateParam: <K extends keyof URLParams>(key: K, value: URLParams[K]) => void
  clearParams: () => void
  
  // Navigation helpers
  setNavigating: (navigating: boolean) => void
  
  // Validation
  validateParams: (searchParams: URLSearchParams) => boolean
  getValidatedParams: (searchParams: URLSearchParams) => URLParams | null
}

type URLStore = URLState & URLActions

const initialState: URLState = {
  params: {},
  isValid: true,
  validationErrors: [],
  isNavigating: false
}

export const useURLStore = create<URLStore>()(
  immer((set, get) => ({
    ...initialState,
    
    setParams: (params) => set((state) => {
      state.params = { ...state.params, ...params }
    }),
    
    updateParam: (key, value) => set((state) => {
      if (value === undefined) {
        delete state.params[key]
      } else {
        state.params[key] = value
      }
    }),
    
    clearParams: () => set((state) => {
      state.params = {}
      state.isValid = true
      state.validationErrors = []
    }),
    
    setNavigating: (navigating) => set((state) => {
      state.isNavigating = navigating
    }),
    
    validateParams: (searchParams) => {
      const params: Record<string, string> = {}
      for (const [key, value] of searchParams.entries()) {
        params[key] = value
      }
      
      try {
        const validated = urlParamsSchema.parse(params)
        set((state) => {
          state.params = validated
          state.isValid = true
          state.validationErrors = []
        })
        return true
      } catch (error) {
        if (error instanceof z.ZodError) {
          const errors = error.errors.map(e => `${e.path.join('.')}: ${e.message}`)
          set((state) => {
            state.isValid = false
            state.validationErrors = errors
          })
        }
        return false
      }
    },
    
    getValidatedParams: (searchParams) => {
      const params: Record<string, string> = {}
      for (const [key, value] of searchParams.entries()) {
        params[key] = value
      }
      
      try {
        return urlParamsSchema.parse(params)
      } catch {
        return null
      }
    }
  }))
)

// Helper hooks
export const useURLParams = () => useURLStore(state => state.params)
export const useURLValidation = () => useURLStore(state => ({
  isValid: state.isValid,
  errors: state.validationErrors
}))
export const useIsNavigating = () => useURLStore(state => state.isNavigating)

// Utility functions for URL management
export const buildURL = (base: string, params: URLParams): string => {
  const url = new URL(base, window.location.origin)
  
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined) {
      url.searchParams.set(key, value)
    }
  })
  
  return url.pathname + url.search
}

export const parseURLParams = (searchParams: URLSearchParams): URLParams | null => {
  const params: Record<string, string> = {}
  for (const [key, value] of searchParams.entries()) {
    params[key] = value
  }
  
  try {
    return urlParamsSchema.parse(params)
  } catch {
    return null
  }
}
