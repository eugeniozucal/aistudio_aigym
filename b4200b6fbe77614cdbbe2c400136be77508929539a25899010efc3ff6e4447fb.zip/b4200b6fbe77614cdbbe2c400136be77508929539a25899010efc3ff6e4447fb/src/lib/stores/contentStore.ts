/**
 * Content Store - Zustand with Immer for client state management
 * Based on comprehensive research findings for save/load architecture
 */

import { create } from 'zustand'
import { immer } from 'zustand/middleware/immer'
import { subscribeWithSelector } from 'zustand/middleware'
import { Block, PageData } from '@/types/pageBuilder'

// Types for the unified content system
export type RepositoryType = 'wods' | 'blocks' | 'programs' | 'ai_agents' | 'videos' | 'documents' | 'prompts' | 'automations' | 'images' | 'pdfs'

export interface ContentItem {
  id: string
  workspace_id: string
  repository_type: RepositoryType
  title: string
  description?: string
  content: Record<string, any>
  metadata: Record<string, any>
  status: 'draft' | 'published' | 'archived'
  folder_id?: string
  thumbnail_url?: string
  created_by: string
  updated_by: string
  created_at: string
  updated_at: string
  version: number
  estimated_duration_minutes?: number
  difficulty_level?: 'beginner' | 'intermediate' | 'advanced'
  tags: string[]
}

// Content editor state
export interface ContentEditorState {
  // Current editing state
  currentContent: ContentItem | null
  isEditing: boolean
  isDirty: boolean
  isAutoSaving: boolean
  
  // Page builder specific state
  pageData: PageData | null
  currentPageId: string
  selectedBlock: Block | null
  
  // UI state
  activeLeftMenu: string | null
  showRightPanel: boolean
  repositoryPopup: {
    type: string
    isOpen: boolean
  }
  showPreview: boolean
  
  // Error and success states
  error: string | null
  successMessage: string | null
  
  // Session management
  sessionId: string
  lastSaved: Date | null
  
  // Auto-save configuration
  autoSaveInterval: number // milliseconds
  autoSaveEnabled: boolean
}

export interface ContentEditorActions {
  // Content management
  setCurrentContent: (content: ContentItem | null) => void
  updateContent: (updates: Partial<ContentItem>) => void
  setPageData: (pageData: PageData) => void
  updatePageData: (updates: Partial<PageData>) => void
  
  // Page management
  setCurrentPageId: (pageId: string) => void
  addPage: (page: any) => void
  removePage: (pageId: string) => void
  
  // Block management
  setSelectedBlock: (block: Block | null) => void
  addBlock: (pageId: string, block: Block) => void
  updateBlock: (pageId: string, blockId: string, updates: Partial<Block>) => void
  removeBlock: (pageId: string, blockId: string) => void
  reorderBlocks: (pageId: string, blockIds: string[]) => void
  
  // UI state management
  setActiveLeftMenu: (menu: string | null) => void
  setShowRightPanel: (show: boolean) => void
  setRepositoryPopup: (popup: { type: string; isOpen: boolean }) => void
  setShowPreview: (show: boolean) => void
  
  // Error and success handling
  setError: (error: string | null) => void
  setSuccessMessage: (message: string | null) => void
  clearMessages: () => void
  
  // State management
  setDirty: (dirty: boolean) => void
  setAutoSaving: (autoSaving: boolean) => void
  setLastSaved: (date: Date) => void
  
  // Session management
  generateSessionId: () => void
  
  // Reset functions
  resetEditor: () => void
  resetUIState: () => void
}

type ContentStore = ContentEditorState & ContentEditorActions

// Utility function to generate session ID
const generateSessionId = () => {
  return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
}

// Initial state
const initialState: ContentEditorState = {
  currentContent: null,
  isEditing: false,
  isDirty: false,
  isAutoSaving: false,
  
  pageData: null,
  currentPageId: 'page-1',
  selectedBlock: null,
  
  activeLeftMenu: null,
  showRightPanel: false,
  repositoryPopup: { type: '', isOpen: false },
  showPreview: false,
  
  error: null,
  successMessage: null,
  
  sessionId: '',
  lastSaved: null,
  
  autoSaveInterval: 2000, // 2 seconds as specified in architecture
  autoSaveEnabled: true
}

// Create the store with Immer middleware for immutable updates
export const useContentStore = create<ContentStore>()(
  subscribeWithSelector(
    immer((set, get) => ({
      ...initialState,
      sessionId: generateSessionId(),
      
      // Content management
      setCurrentContent: (content) => set((state) => {
        state.currentContent = content
        state.isEditing = Boolean(content)
        if (content) {
          state.pageData = {
            title: content.title,
            description: content.description || '',
            status: content.status,
            targetRepository: content.repository_type as any,
            pages: content.content.pages || [{
              id: 'page-1',
              title: 'Page 1',
              blocks: [],
              order: 0
            }],
            settings: content.content.settings || {
              communities: [],
              tags: [],
              people: [],
              difficulty: 1,
              estimatedDuration: content.estimated_duration_minutes || 30,
              autoSaveEnabled: true
            }
          }
        }
      }),
      
      updateContent: (updates) => set((state) => {
        if (state.currentContent) {
          Object.assign(state.currentContent, updates)
          state.isDirty = true
        }
      }),
      
      setPageData: (pageData) => set((state) => {
        state.pageData = pageData
        state.isDirty = true
      }),
      
      updatePageData: (updates) => set((state) => {
        if (state.pageData) {
          Object.assign(state.pageData, updates)
          state.isDirty = true
        }
      }),
      
      // Page management
      setCurrentPageId: (pageId) => set((state) => {
        state.currentPageId = pageId
      }),
      
      addPage: (page) => set((state) => {
        if (state.pageData) {
          state.pageData.pages.push(page)
          state.isDirty = true
        }
      }),
      
      removePage: (pageId) => set((state) => {
        if (state.pageData) {
          state.pageData.pages = state.pageData.pages.filter(p => p.id !== pageId)
          if (state.currentPageId === pageId) {
            state.currentPageId = state.pageData.pages[0]?.id || 'page-1'
          }
          state.isDirty = true
        }
      }),
      
      // Block management
      setSelectedBlock: (block) => set((state) => {
        state.selectedBlock = block
        state.showRightPanel = Boolean(block)
      }),
      
      addBlock: (pageId, block) => set((state) => {
        if (state.pageData) {
          const page = state.pageData.pages.find(p => p.id === pageId)
          if (page) {
            page.blocks.push(block)
            state.isDirty = true
          }
        }
      }),
      
      updateBlock: (pageId, blockId, updates) => set((state) => {
        if (state.pageData) {
          const page = state.pageData.pages.find(p => p.id === pageId)
          if (page) {
            const block = page.blocks.find(b => b.id === blockId)
            if (block) {
              Object.assign(block, updates)
              state.isDirty = true
            }
          }
        }
        // Update selected block if it's the one being updated
        if (state.selectedBlock?.id === blockId) {
          Object.assign(state.selectedBlock, updates)
        }
      }),
      
      removeBlock: (pageId, blockId) => set((state) => {
        if (state.pageData) {
          const page = state.pageData.pages.find(p => p.id === pageId)
          if (page) {
            page.blocks = page.blocks.filter(b => b.id !== blockId)
            state.isDirty = true
          }
        }
        // Clear selected block if it was the one removed
        if (state.selectedBlock?.id === blockId) {
          state.selectedBlock = null
          state.showRightPanel = false
        }
      }),
      
      reorderBlocks: (pageId, blockIds) => set((state) => {
        if (state.pageData) {
          const page = state.pageData.pages.find(p => p.id === pageId)
          if (page) {
            const blocksMap = new Map(page.blocks.map(b => [b.id, b]))
            page.blocks = blockIds.map(id => blocksMap.get(id)!).filter(Boolean)
            state.isDirty = true
          }
        }
      }),
      
      // UI state management
      setActiveLeftMenu: (menu) => set((state) => {
        state.activeLeftMenu = menu
      }),
      
      setShowRightPanel: (show) => set((state) => {
        state.showRightPanel = show
      }),
      
      setRepositoryPopup: (popup) => set((state) => {
        state.repositoryPopup = popup
      }),
      
      setShowPreview: (show) => set((state) => {
        state.showPreview = show
      }),
      
      // Error and success handling
      setError: (error) => set((state) => {
        state.error = error
        if (error) {
          // Auto-clear error after 5 seconds
          setTimeout(() => {
            const currentState = get()
            if (currentState.error === error) {
              set((state) => { state.error = null })
            }
          }, 5000)
        }
      }),
      
      setSuccessMessage: (message) => set((state) => {
        state.successMessage = message
        if (message) {
          // Auto-clear success message after 3 seconds
          setTimeout(() => {
            const currentState = get()
            if (currentState.successMessage === message) {
              set((state) => { state.successMessage = null })
            }
          }, 3000)
        }
      }),
      
      clearMessages: () => set((state) => {
        state.error = null
        state.successMessage = null
      }),
      
      // State management
      setDirty: (dirty) => set((state) => {
        state.isDirty = dirty
      }),
      
      setAutoSaving: (autoSaving) => set((state) => {
        state.isAutoSaving = autoSaving
      }),
      
      setLastSaved: (date) => set((state) => {
        state.lastSaved = date
        state.isDirty = false
      }),
      
      // Session management
      generateSessionId: () => set((state) => {
        state.sessionId = generateSessionId()
      }),
      
      // Reset functions
      resetEditor: () => set(() => ({
        ...initialState,
        sessionId: generateSessionId()
      })),
      
      resetUIState: () => set((state) => {
        state.activeLeftMenu = null
        state.showRightPanel = false
        state.repositoryPopup = { type: '', isOpen: false }
        state.showPreview = false
        state.selectedBlock = null
        state.error = null
        state.successMessage = null
      })
    }))
  )
)

// Selector hooks for better performance
export const useCurrentContent = () => useContentStore(state => state.currentContent)
export const usePageData = () => useContentStore(state => state.pageData)
export const useIsDirty = () => useContentStore(state => state.isDirty)
export const useIsAutoSaving = () => useContentStore(state => state.isAutoSaving)
export const useSelectedBlock = () => useContentStore(state => state.selectedBlock)
export const useUIState = () => useContentStore(state => ({
  activeLeftMenu: state.activeLeftMenu,
  showRightPanel: state.showRightPanel,
  repositoryPopup: state.repositoryPopup,
  showPreview: state.showPreview
}))
export const useMessages = () => useContentStore(state => ({
  error: state.error,
  successMessage: state.successMessage
}))
