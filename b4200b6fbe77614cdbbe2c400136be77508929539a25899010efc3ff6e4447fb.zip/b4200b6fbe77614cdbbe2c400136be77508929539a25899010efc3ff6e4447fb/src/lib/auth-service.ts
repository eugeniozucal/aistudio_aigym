import { supabase } from './supabase'
import type { User } from '@supabase/supabase-js'

export interface UserWithRole {
  id: string
  email: string
  role: 'admin' | 'community_user'
  communityId?: string
  emailConfirmed: boolean
  createdAt: string
}

export interface AuthValidationResult {
  hasAccess: boolean
  userRole: 'admin' | 'community_user'
  communityId?: string
  redirectTo?: string
  userId: string
}

export interface RoleAssignmentData {
  userId: string
  role: 'admin' | 'community_user'
  communityId?: string
  assignedBy?: string
}

/**
 * Core Authentication Service
 * Provides bulletproof authentication with explicit role-based access control
 */
export class AuthService {
  private static instance: AuthService
  private userCache: Map<string, UserWithRole> = new Map()
  private cacheTimeout = 5 * 60 * 1000 // 5 minutes

  private constructor() {}

  static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService()
    }
    return AuthService.instance
  }

  /**
   * Get current user role with fallbacks (Priority Order):
   * 1. Primary: Query user_roles table for explicit role assignment
   * 2. Fallback: Check auth.users.raw_user_meta_data for legacy role info
   * 3. Default: Assign community role and prompt for confirmation
   */
  async getCurrentUserRole(): Promise<{ role: 'admin' | 'community_user'; communityId?: string } | null> {
    try {
      const { data: { user }, error } = await supabase.auth.getUser()
      if (error || !user) {
        return null
      }

      // Use role management edge function for reliable role detection
      const { data, error: roleError } = await supabase.functions.invoke('role-management-api', {
        body: {
          action: 'getUserRole',
          userId: user.id
        }
      })

      if (roleError) {
        console.error('Failed to get user role:', roleError)
        return null
      }

      return {
        role: data.data.role,
        communityId: data.data.communityId
      }
    } catch (error) {
      console.error('Error getting current user role:', error)
      return null
    }
  }

  /**
   * Validate user permissions for a specific route
   */
  async validateUserPermissions(route: string): Promise<AuthValidationResult | null> {
    try {
      const { data: { user }, error } = await supabase.auth.getUser()
      if (error || !user) {
        return null
      }

      // Use auth validation edge function
      const { data, error: validationError } = await supabase.functions.invoke('auth-validation-api', {
        body: {
          action: 'validateAccess',
          route
        }
      })

      if (validationError) {
        console.error('Failed to validate user permissions:', validationError)
        return null
      }

      return data.data
    } catch (error) {
      console.error('Error validating user permissions:', error)
      return null
    }
  }

  /**
   * Admin function to assign roles
   */
  async assignUserRole(data: RoleAssignmentData): Promise<boolean> {
    try {
      const { data: result, error } = await supabase.functions.invoke('role-management-api', {
        body: {
          action: 'assignRole',
          userId: data.userId,
          role: data.role,
          communityId: data.communityId,
          assignedBy: data.assignedBy
        }
      })

      if (error) {
        console.error('Failed to assign user role:', error)
        return false
      }

      // Clear cache for the affected user
      this.userCache.delete(data.userId)

      return true
    } catch (error) {
      console.error('Error assigning user role:', error)
      return false
    }
  }

  /**
   * Get authenticated user with role information
   */
  async getAuthenticatedUser(): Promise<UserWithRole | null> {
    try {
      const { data: { user }, error } = await supabase.auth.getUser()
      if (error || !user) {
        return null
      }

      // Check cache first
      const cached = this.userCache.get(user.id)
      if (cached) {
        return cached
      }

      // Use auth validation edge function to get full user data
      const { data, error: userError } = await supabase.functions.invoke('auth-validation-api', {
        body: {
          action: 'getAuthenticatedUser'
        }
      })

      if (userError) {
        console.error('Failed to get authenticated user:', userError)
        return null
      }

      const userWithRole: UserWithRole = data.data

      // Cache the result
      this.userCache.set(user.id, userWithRole)
      setTimeout(() => this.userCache.delete(user.id), this.cacheTimeout)

      return userWithRole
    } catch (error) {
      console.error('Error getting authenticated user:', error)
      return null
    }
  }

  /**
   * Smart routing post-authentication
   */
  getPostAuthenticationRoute(userRole: 'admin' | 'community_user'): string {
    switch (userRole) {
      case 'admin':
        return '/admin/dashboard'
      case 'community_user':
        return '/user/community'
      default:
        return '/login'
    }
  }

  /**
   * Enhanced sign in with comprehensive error handling
   */
  async signIn(email: string, password: string): Promise<{ success: boolean; error?: string; redirectTo?: string }> {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      })

      if (error) {
        // Log failed authentication attempt
        await this.logAuthEvent('login_failed', { email, error: error.message }, false)

        // Provide user-friendly error messages
        if (error.message.includes('Invalid login credentials')) {
          return {
            success: false,
            error: 'Invalid email or password. Please check your credentials and try again.'
          }
        } else if (error.message.includes('Email not confirmed')) {
          return {
            success: false,
            error: 'Please verify your email address before signing in. Check your inbox for a verification link.'
          }
        } else if (error.message.includes('Too many requests')) {
          return {
            success: false,
            error: 'Too many login attempts. Please wait a few minutes before trying again.'
          }
        } else {
          return {
            success: false,
            error: error.message
          }
        }
      }

      if (data.user) {
        // Get user role and determine redirect
        const roleData = await this.getCurrentUserRole()
        if (roleData) {
          const redirectTo = this.getPostAuthenticationRoute(roleData.role)
          
          // Log successful authentication
          await this.logAuthEvent('login_success', { email, role: roleData.role }, true)

          return {
            success: true,
            redirectTo
          }
        }
      }

      return {
        success: false,
        error: 'Authentication succeeded but role detection failed. Please contact support.'
      }
    } catch (error) {
      console.error('Sign in error:', error)
      return {
        success: false,
        error: 'An unexpected error occurred during sign in. Please try again.'
      }
    }
  }

  /**
   * Sign out with cleanup
   */
  async signOut(): Promise<void> {
    try {
      const user = await this.getAuthenticatedUser()
      if (user) {
        await this.logAuthEvent('logout', { userId: user.id }, true)
      }

      await supabase.auth.signOut()
      this.userCache.clear()
    } catch (error) {
      console.error('Sign out error:', error)
    }
  }

  /**
   * Log authentication events for audit trail
   */
  private async logAuthEvent(eventType: string, eventData: any, success: boolean): Promise<void> {
    try {
      await supabase.functions.invoke('auth-validation-api', {
        body: {
          action: 'logAuthEvent',
          additionalData: {
            eventType,
            eventData,
            success
          }
        }
      })
    } catch (error) {
      // Don't throw on logging errors, just log to console
      console.warn('Failed to log auth event:', error)
    }
  }

  /**
   * Get all user roles (admin function)
   */
  async getAllUserRoles(): Promise<any[]> {
    try {
      const { data, error } = await supabase.functions.invoke('role-management-api', {
        body: {
          action: 'listUserRoles'
        }
      })

      if (error) {
        console.error('Failed to get user roles:', error)
        return []
      }

      return data.data || []
    } catch (error) {
      console.error('Error getting user roles:', error)
      return []
    }
  }

  /**
   * Get authentication audit log (admin function)
   */
  async getAuthAuditLog(): Promise<any[]> {
    try {
      const { data, error } = await supabase.functions.invoke('role-management-api', {
        body: {
          action: 'getAuthAuditLog'
        }
      })

      if (error) {
        console.error('Failed to get audit log:', error)
        return []
      }

      return data.data || []
    } catch (error) {
      console.error('Error getting audit log:', error)
      return []
    }
  }

  /**
   * Clear user cache (useful for testing or after role changes)
   */
  clearCache(): void {
    this.userCache.clear()
  }
}

// Export singleton instance
export const authService = AuthService.getInstance()