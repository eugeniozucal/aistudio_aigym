/**
 * Auto-Save Hook - Debounced auto-save with 2-second delay
 * Based on comprehensive research findings for save/load architecture
 */

import { useEffect, useRef, useCallback } from 'react'
import { useContentStore } from '@/lib/stores/contentStore'
import { useUpdateContent, useAutoSave } from './useContent'

export const useAutoSaveEffect = () => {
  const {
    currentContent,
    pageData,
    isDirty,
    autoSaveEnabled,
    autoSaveInterval,
    sessionId,
    setAutoSaving,
    setLastSaved,
    setError
  } = useContentStore()

  const updateContentMutation = useUpdateContent()
  const autoSaveMutation = useAutoSave()
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)
  const lastSaveRef = useRef<string>('')

  // Clear timeout on cleanup
  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [])

  // Auto-save function
  const performAutoSave = useCallback(async () => {
    if (!currentContent || !pageData || !isDirty || !autoSaveEnabled) {
      return
    }

    try {
      setAutoSaving(true)

      // Create content hash to prevent duplicate saves
      const contentHash = JSON.stringify({ pageData, currentContent })
      if (contentHash === lastSaveRef.current) {
        setAutoSaving(false)
        return
      }

      // Update the content with current pageData
      const updatedContent = {
        ...currentContent,
        title: pageData.title,
        description: pageData.description,
        status: pageData.status,
        content: {
          pages: pageData.pages,
          settings: pageData.settings
        },
        updated_by: currentContent.created_by, // Use current user
      }

      if (currentContent.id.startsWith('temp-')) {
        // This is a new item, create it
        // Note: This would need to be handled by a create mutation
        console.log('Auto-save: Creating new content')
      } else {
        // Update existing content
        await updateContentMutation.mutateAsync({
          id: currentContent.id,
          repositoryType: currentContent.repository_type,
          updates: updatedContent
        })
      }

      // Also save auto-save snapshot
      await autoSaveMutation.mutateAsync({
        contentId: currentContent.id,
        sessionId,
        snapshotData: { pages: pageData.pages, settings: pageData.settings },
        metadata: { lastSaved: new Date().toISOString() }
      })

      lastSaveRef.current = contentHash
      setLastSaved(new Date())
      
    } catch (error) {
      console.error('Auto-save failed:', error)
      setError(`Auto-save failed: ${error}`)
    } finally {
      setAutoSaving(false)
    }
  }, [
    currentContent,
    pageData,
    isDirty,
    autoSaveEnabled,
    sessionId,
    updateContentMutation,
    autoSaveMutation,
    setAutoSaving,
    setLastSaved,
    setError
  ])

  // Set up debounced auto-save
  useEffect(() => {
    if (!isDirty || !autoSaveEnabled || !currentContent || !pageData) {
      return
    }

    // Clear existing timeout
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
    }

    // Set new timeout for auto-save
    timeoutRef.current = setTimeout(() => {
      performAutoSave()
    }, autoSaveInterval)

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [isDirty, autoSaveEnabled, currentContent, pageData, autoSaveInterval, performAutoSave])

  // Manual save function
  const manualSave = useCallback(async () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
    }
    await performAutoSave()
  }, [performAutoSave])

  return {
    manualSave,
    isAutoSaving: updateContentMutation.isPending || autoSaveMutation.isPending
  }
}
