/**
 * Content Management Hooks - TanStack Query integration with optimistic updates
 * Based on comprehensive research findings for save/load architecture
 */

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { contentApi } from '@/lib/api/contentApi'
import { ContentItem, RepositoryType } from '@/lib/stores/contentStore'
import { useContentStore } from '@/lib/stores/contentStore'

// Query keys for proper cache management
export const contentKeys = {
  all: ['content'] as const,
  lists: () => [...contentKeys.all, 'list'] as const,
  list: (repositoryType: RepositoryType, filters?: any) => 
    [...contentKeys.lists(), repositoryType, filters] as const,
  details: () => [...contentKeys.all, 'detail'] as const,
  detail: (id: string, repositoryType: RepositoryType) => 
    [...contentKeys.details(), id, repositoryType] as const,
}

// Hook for fetching a single content item
export const useContentItem = (id: string | null, repositoryType: RepositoryType) => {
  return useQuery({
    queryKey: contentKeys.detail(id || '', repositoryType),
    queryFn: () => contentApi.getById(id!, repositoryType),
    enabled: Boolean(id),
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 2,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
  })
}

// Hook for fetching content list
export const useContentList = (
  repositoryType: RepositoryType,
  filters: Parameters<typeof contentApi.list>[1] = {}
) => {
  return useQuery({
    queryKey: contentKeys.list(repositoryType, filters),
    queryFn: () => contentApi.list(repositoryType, filters),
    staleTime: 2 * 60 * 1000, // 2 minutes
    retry: 2,
  })
}

// Hook for creating content with optimistic updates
export const useCreateContent = () => {
  const queryClient = useQueryClient()
  const { setSuccessMessage, setError } = useContentStore()

  return useMutation({
    mutationFn: contentApi.create,
    onMutate: async (newContent) => {
      // Cancel any outgoing refetches
      await queryClient.cancelQueries({ 
        queryKey: contentKeys.list(newContent.repository_type) 
      })

      // Snapshot the previous value
      const previousContent = queryClient.getQueryData(
        contentKeys.list(newContent.repository_type)
      )

      // Optimistically update to the new value
      const optimisticContent: ContentItem = {
        ...newContent,
        id: `temp-${Date.now()}`,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        version: 1,
      } as ContentItem

      queryClient.setQueryData(
        contentKeys.list(newContent.repository_type),
        (old: ContentItem[] | undefined) => 
          old ? [optimisticContent, ...old] : [optimisticContent]
      )

      return { previousContent }
    },
    onError: (err, newContent, context) => {
      // Rollback optimistic update
      if (context?.previousContent) {
        queryClient.setQueryData(
          contentKeys.list(newContent.repository_type),
          context.previousContent
        )
      }
      setError(`Failed to create content: ${err.message}`)
    },
    onSuccess: (data, variables) => {
      setSuccessMessage(`${variables.repository_type} created successfully!`)
      
      // Invalidate and refetch
      queryClient.invalidateQueries({ 
        queryKey: contentKeys.list(variables.repository_type) 
      })
    },
    onSettled: () => {
      // Always refetch after error or success
      queryClient.invalidateQueries({ queryKey: contentKeys.all })
    },
  })
}

// Hook for updating content with optimistic updates
export const useUpdateContent = () => {
  const queryClient = useQueryClient()
  const { setSuccessMessage, setError, setLastSaved } = useContentStore()

  return useMutation({
    mutationFn: ({ id, repositoryType, updates }: {
      id: string
      repositoryType: RepositoryType
      updates: Partial<ContentItem>
    }) => contentApi.update(id, repositoryType, updates),
    
    onMutate: async ({ id, repositoryType, updates }) => {
      // Cancel any outgoing refetches
      await queryClient.cancelQueries({ 
        queryKey: contentKeys.detail(id, repositoryType) 
      })

      // Snapshot the previous value
      const previousContent = queryClient.getQueryData(
        contentKeys.detail(id, repositoryType)
      )

      // Optimistically update to the new value
      queryClient.setQueryData(
        contentKeys.detail(id, repositoryType),
        (old: ContentItem | undefined) => 
          old ? { ...old, ...updates, updated_at: new Date().toISOString() } : undefined
      )

      // Also update in list cache if present
      queryClient.setQueryData(
        contentKeys.list(repositoryType),
        (old: ContentItem[] | undefined) => 
          old?.map(item => 
            item.id === id 
              ? { ...item, ...updates, updated_at: new Date().toISOString() }
              : item
          )
      )

      return { previousContent }
    },
    
    onError: (err, { id, repositoryType }, context) => {
      // Rollback optimistic update
      if (context?.previousContent) {
        queryClient.setQueryData(
          contentKeys.detail(id, repositoryType),
          context.previousContent
        )
      }
      setError(`Failed to update content: ${err.message}`)
    },
    
    onSuccess: (data, { repositoryType }) => {
      setSuccessMessage('Content updated successfully!')
      setLastSaved(new Date())
      
      // Update cache with server response
      queryClient.setQueryData(
        contentKeys.detail(data.id, repositoryType),
        data
      )
    },
    
    onSettled: (data, error, { repositoryType }) => {
      // Invalidate list to ensure consistency
      queryClient.invalidateQueries({ 
        queryKey: contentKeys.list(repositoryType) 
      })
    },
  })
}

// Hook for deleting content
export const useDeleteContent = () => {
  const queryClient = useQueryClient()
  const { setSuccessMessage, setError } = useContentStore()

  return useMutation({
    mutationFn: ({ id, repositoryType }: {
      id: string
      repositoryType: RepositoryType
    }) => contentApi.delete(id, repositoryType),
    
    onMutate: async ({ id, repositoryType }) => {
      // Cancel any outgoing refetches
      await queryClient.cancelQueries({ 
        queryKey: contentKeys.list(repositoryType) 
      })

      // Snapshot the previous value
      const previousContent = queryClient.getQueryData(
        contentKeys.list(repositoryType)
      )

      // Optimistically remove from list
      queryClient.setQueryData(
        contentKeys.list(repositoryType),
        (old: ContentItem[] | undefined) => 
          old?.filter(item => item.id !== id)
      )

      return { previousContent }
    },
    
    onError: (err, { repositoryType }, context) => {
      // Rollback optimistic update
      if (context?.previousContent) {
        queryClient.setQueryData(
          contentKeys.list(repositoryType),
          context.previousContent
        )
      }
      setError(`Failed to delete content: ${err.message}`)
    },
    
    onSuccess: (_, { id, repositoryType }) => {
      setSuccessMessage('Content deleted successfully!')
      
      // Remove from detail cache
      queryClient.removeQueries({ 
        queryKey: contentKeys.detail(id, repositoryType) 
      })
    },
    
    onSettled: (_, __, { repositoryType }) => {
      // Invalidate list to ensure consistency
      queryClient.invalidateQueries({ 
        queryKey: contentKeys.list(repositoryType) 
      })
    },
  })
}

// Hook for auto-save functionality
export const useAutoSave = () => {
  const queryClient = useQueryClient()
  const { setAutoSaving, setError } = useContentStore()

  return useMutation({
    mutationFn: ({ contentId, sessionId, snapshotData, metadata }: {
      contentId: string
      sessionId: string
      snapshotData: Record<string, any>
      metadata?: Record<string, any>
    }) => contentApi.autoSave(contentId, sessionId, snapshotData, metadata),
    onMutate: () => {
      setAutoSaving(true)
    },
    onError: (err) => {
      setError(`Auto-save failed: ${err.message}`)
    },
    onSettled: () => {
      setAutoSaving(false)
    },
  })
}
