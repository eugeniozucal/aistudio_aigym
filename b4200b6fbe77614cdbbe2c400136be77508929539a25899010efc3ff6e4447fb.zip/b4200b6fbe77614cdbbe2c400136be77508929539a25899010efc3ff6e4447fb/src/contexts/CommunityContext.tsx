import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { useAuth } from './BulletproofAuthContext'
import { supabase } from '../lib/supabase'

interface Community {
  community_id: string
  community_name: string
  role: string
  joined_at: string
  brand_color: string | null
  logo_url: string | null
}

interface CommunityContextType {
  communities: Community[]
  selectedCommunity: Community | null
  setSelectedCommunity: (community: Community) => void
  loading: boolean
  error: string | null
}

const CommunityContext = createContext<CommunityContextType | undefined>(undefined)

export function useCommunity() {
  const context = useContext(CommunityContext)
  if (context === undefined) {
    // Instead of throwing error, return default values to prevent app crash
    console.warn('useCommunity must be used within a CommunityProvider, returning default values')
    return {
      communities: [],
      selectedCommunity: null,
      setSelectedCommunity: () => {},
      loading: false,
      error: null
    }
  }
  return context
}

export function CommunityProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth()
  const [communities, setCommunities] = useState<Community[]>([])
  const [selectedCommunity, setSelectedCommunity] = useState<Community | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!user) {
      setCommunities([])
      setSelectedCommunity(null)
      setLoading(false)
      return
    }

    // Add delay to ensure auth is fully initialized
    const timeoutId = setTimeout(() => {
      loadUserCommunities()
    }, 100)

    return () => clearTimeout(timeoutId)
  }, [user])

  const loadUserCommunities = async () => {
    if (!user?.id) return

    try {
      setLoading(true)
      setError(null)

      // Use the get_user_communities function from the database
      const { data, error } = await supabase
        .rpc('get_user_communities', { p_user_id: user.id })

      if (error) {
        console.error('Error loading user communities:', error)
        // Don't set error state to prevent app from breaking
        // Just set empty communities and continue
        setCommunities([])
        setSelectedCommunity(null)
        return
      }

      setCommunities(data || [])
      
      // Auto-select the first community if none is selected
      if (data && data.length > 0 && !selectedCommunity) {
        setSelectedCommunity(data[0])
      }

    } catch (error) {
      console.error('Error:', error)
      // Don't set error state to prevent app from breaking
      setCommunities([])
      setSelectedCommunity(null)
    } finally {
      setLoading(false)
    }
  }

  const value = {
    communities,
    selectedCommunity,
    setSelectedCommunity,
    loading,
    error
  }

  return (
    <CommunityContext.Provider value={value}>
      {children}
    </CommunityContext.Provider>
  )
}
