-- Enhanced clients table with additional Phase 2 fields
ALTER TABLE clients ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'active' CHECK (status IN ('active', 'archived'));
ALTER TABLE clients ADD COLUMN IF NOT EXISTS template_source_id UUID REFERENCES clients(id);
ALTER TABLE clients ADD COLUMN IF NOT EXISTS api_key_id UUID REFERENCES api_keys(id);

-- Client feature toggles
CREATE TABLE IF NOT EXISTS client_features (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    feature_name TEXT NOT NULL,
    enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(client_id, feature_name)
);

-- Insert default features for existing clients
INSERT INTO client_features (client_id, feature_name, enabled)
SELECT c.id, feature.name, true
FROM clients c
CROSS JOIN (
    VALUES 
    ('agents_marketplace'),
    ('courses'),
    ('missions'),
    ('forums'),
    ('documents'),
    ('prompts'),
    ('automations')
) AS feature(name)
ON CONFLICT (client_id, feature_name) DO NOTHING;