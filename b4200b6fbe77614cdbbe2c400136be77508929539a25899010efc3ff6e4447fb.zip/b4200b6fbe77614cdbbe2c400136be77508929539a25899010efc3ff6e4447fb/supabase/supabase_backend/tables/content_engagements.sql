-- Content engagement tracking
CREATE TABLE IF NOT EXISTS content_engagements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_item_id UUID NOT NULL REFERENCES content_items(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    engagement_type TEXT NOT NULL, -- 'view', 'practice', 'complete', 'favorite'
    engagement_data JSONB, -- Additional engagement-specific data
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(content_item_id, user_id, engagement_type)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_content_engagements_content_id ON content_engagements(content_item_id);
CREATE INDEX IF NOT EXISTS idx_content_engagements_user_id ON content_engagements(user_id);
CREATE INDEX IF NOT EXISTS idx_content_engagements_client_id ON content_engagements(client_id);
CREATE INDEX IF NOT EXISTS idx_content_engagements_type ON content_engagements(engagement_type);