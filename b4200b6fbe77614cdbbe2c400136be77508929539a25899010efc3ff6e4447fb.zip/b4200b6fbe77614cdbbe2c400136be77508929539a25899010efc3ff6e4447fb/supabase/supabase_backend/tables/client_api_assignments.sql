CREATE TABLE client_api_assignments (
    client_id UUID NOT NULL,
    api_key_id UUID NOT NULL,
    PRIMARY KEY (client_id,
    api_key_id)
);