CREATE TABLE admins (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('super_admin',
    'manager',
    'specialist')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);