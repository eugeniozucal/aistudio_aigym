-- Global platform settings
CREATE TABLE IF NOT EXISTS platform_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    setting_key TEXT NOT NULL UNIQUE,
    setting_value JSONB NOT NULL,
    setting_type TEXT NOT NULL, -- 'string', 'number', 'boolean', 'object', 'array'
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default platform settings
INSERT INTO platform_settings (setting_key, setting_value, setting_type, description) VALUES
('available_features', '["agents_marketplace", "courses", "missions", "forums", "documents", "prompts", "automations"]'::jsonb, 'array', 'List of all available platform features'),
('default_user_password_length', '12'::jsonb, 'number', 'Default length for auto-generated user passwords'),
('max_bulk_upload_rows', '1000'::jsonb, 'number', 'Maximum rows allowed in bulk uploads'),
('analytics_retention_days', '365'::jsonb, 'number', 'Number of days to retain analytics data')
ON CONFLICT (setting_key) DO NOTHING;