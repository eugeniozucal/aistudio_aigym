-- Create uploaded_files table for Mission Builder file management
CREATE TABLE uploaded_files (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    filename TEXT NOT NULL,
    original_filename TEXT NOT NULL,
    file_path TEXT NOT NULL,
    file_url TEXT NOT NULL,
    file_size BIGINT NOT NULL,
    mime_type TEXT NOT NULL,
    folder TEXT DEFAULT 'general',
    metadata JSONB DEFAULT '{}',
    uploaded_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- RLS policies
ALTER TABLE uploaded_files ENABLE ROW LEVEL SECURITY;

-- Policy for authenticated users (admins)
CREATE POLICY "Admins can manage uploaded files" ON uploaded_files FOR ALL USING (auth.role() = 'authenticated');

-- Indexes for performance
CREATE INDEX idx_uploaded_files_type ON uploaded_files(mime_type);
CREATE INDEX idx_uploaded_files_folder ON uploaded_files(folder);
CREATE INDEX idx_uploaded_files_uploaded_by ON uploaded_files(uploaded_by);
CREATE INDEX idx_uploaded_files_created_at ON uploaded_files(created_at);

-- Trigger for updated_at
CREATE TRIGGER set_uploaded_files_timestamp
    BEFORE UPDATE ON uploaded_files
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();