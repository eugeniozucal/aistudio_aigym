-- Pages table for individual pages within missions/courses
CREATE TABLE pages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    mission_id UUID,
    course_id UUID,
    order_index INTEGER NOT NULL DEFAULT 0,
    is_locked BOOLEAN DEFAULT false,
    unlock_conditions JSONB DEFAULT '{}',
    page_config JSONB DEFAULT '{}', -- Global page settings
    status TEXT NOT NULL CHECK (status IN ('draft', 'published', 'archived')) DEFAULT 'draft',
    created_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Ensure page belongs to either mission or course, not both
    CONSTRAINT check_page_parent CHECK (
        (mission_id IS NOT NULL AND course_id IS NULL) OR
        (mission_id IS NULL AND course_id IS NOT NULL)
    )
);

-- RLS policies
ALTER TABLE pages ENABLE ROW LEVEL SECURITY;

-- Policy for authenticated users (admins)
CREATE POLICY "Admins can manage pages" ON pages FOR ALL USING (auth.role() = 'authenticated');

-- Indexes for performance
CREATE INDEX idx_pages_mission_id ON pages(mission_id);
CREATE INDEX idx_pages_course_id ON pages(course_id);
CREATE INDEX idx_pages_order_index ON pages(order_index);

-- Trigger for updated_at
CREATE TRIGGER set_pages_timestamp
    BEFORE UPDATE ON pages
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();