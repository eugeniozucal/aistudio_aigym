-- Blocks table for page content blocks
CREATE TABLE blocks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    page_id UUID NOT NULL,
    block_type TEXT NOT NULL CHECK (block_type IN (
        -- Foundational blocks
        'section_header',
        'rich_text', 
        'image',
        'list',
        'quote',
        'divider',
        -- Embedded content blocks
        'video',
        'agent',
        'document', 
        'prompt',
        'automation',
        -- Interactive blocks
        'quiz',
        'user_submission',
        'accordion'
    )),
    order_index INTEGER NOT NULL DEFAULT 0,
    config JSONB NOT NULL DEFAULT '{}', -- Block-specific configuration
    style JSONB DEFAULT '{}', -- Styling configuration
    content JSONB NOT NULL DEFAULT '{}', -- Block content data
    visibility_conditions JSONB DEFAULT '{}', -- Conditional display logic
    is_visible BOOLEAN DEFAULT true,
    created_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- RLS policies
ALTER TABLE blocks ENABLE ROW LEVEL SECURITY;

-- Policy for authenticated users (admins)
CREATE POLICY "Admins can manage blocks" ON blocks FOR ALL USING (auth.role() = 'authenticated');

-- Indexes for performance
CREATE INDEX idx_blocks_page_id ON blocks(page_id);
CREATE INDEX idx_blocks_type ON blocks(block_type);
CREATE INDEX idx_blocks_order ON blocks(page_id, order_index);
CREATE INDEX idx_blocks_visibility ON blocks(page_id, is_visible);

-- Trigger for updated_at
CREATE TRIGGER set_blocks_timestamp
    BEFORE UPDATE ON blocks
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();