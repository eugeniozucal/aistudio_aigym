CREATE TABLE content_client_assignments (
    content_item_id UUID NOT NULL,
    client_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (content_item_id,
    client_id)
);