CREATE TABLE content_user_assignments (
    content_item_id UUID NOT NULL,
    user_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (content_item_id,
    user_id)
);