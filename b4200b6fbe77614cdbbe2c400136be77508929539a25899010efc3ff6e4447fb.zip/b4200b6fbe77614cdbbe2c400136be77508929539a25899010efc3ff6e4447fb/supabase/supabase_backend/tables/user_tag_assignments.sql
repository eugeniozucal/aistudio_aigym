CREATE TABLE user_tag_assignments (
    user_id UUID NOT NULL,
    tag_id UUID NOT NULL,
    PRIMARY KEY (user_id,
    tag_id)
);