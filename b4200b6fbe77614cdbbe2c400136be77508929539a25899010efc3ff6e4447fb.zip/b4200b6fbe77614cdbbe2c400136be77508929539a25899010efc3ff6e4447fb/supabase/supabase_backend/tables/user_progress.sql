-- Progress tracking for user progress through missions and courses
CREATE TABLE user_progress (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,
    mission_id UUID,
    course_id UUID,
    page_id UUID,
    block_id UUID,
    progress_type TEXT NOT NULL CHECK (progress_type IN (
        'page_started',
        'page_completed', 
        'block_interacted',
        'quiz_attempted',
        'quiz_completed',
        'submission_made',
        'mission_completed',
        'course_completed'
    )),
    progress_data JSONB DEFAULT '{}', -- Additional progress data
    completion_percentage DECIMAL(5,2) DEFAULT 0.00,
    time_spent_seconds INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Ensure progress belongs to appropriate parent
    CONSTRAINT check_progress_parent CHECK (
        (mission_id IS NOT NULL OR course_id IS NOT NULL)
    )
);

-- RLS policies
ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;

-- Policy for authenticated users (admins can see all, users can see their own)
CREATE POLICY "Users can manage their own progress" ON user_progress 
    FOR ALL USING (
        auth.role() = 'authenticated' AND 
        (auth.uid() = user_id OR auth.role() = 'service_role')
    );

-- Indexes for performance
CREATE INDEX idx_user_progress_user_id ON user_progress(user_id);
CREATE INDEX idx_user_progress_mission_id ON user_progress(mission_id);
CREATE INDEX idx_user_progress_course_id ON user_progress(course_id);
CREATE INDEX idx_user_progress_page_id ON user_progress(page_id);
CREATE INDEX idx_user_progress_type ON user_progress(progress_type);

-- Trigger for updated_at
CREATE TRIGGER set_user_progress_timestamp
    BEFORE UPDATE ON user_progress
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();