-- Assignment tables for missions and courses to clients/users/tags
CREATE TABLE mission_client_assignments (
    mission_id UUID NOT NULL,
    client_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (mission_id, client_id)
);

CREATE TABLE mission_user_assignments (
    mission_id UUID NOT NULL,
    user_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (mission_id, user_id)
);

CREATE TABLE mission_tag_assignments (
    mission_id UUID NOT NULL,
    tag_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (mission_id, tag_id)
);

CREATE TABLE course_client_assignments (
    course_id UUID NOT NULL,
    client_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (course_id, client_id)
);

CREATE TABLE course_user_assignments (
    course_id UUID NOT NULL,
    user_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (course_id, user_id)
);

CREATE TABLE course_tag_assignments (
    course_id UUID NOT NULL,
    tag_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (course_id, tag_id)
);

-- RLS policies for all assignment tables
ALTER TABLE mission_client_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE mission_user_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE mission_tag_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_client_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_user_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_tag_assignments ENABLE ROW LEVEL SECURITY;

-- Policies for authenticated users (admins)
CREATE POLICY "Admins can manage mission client assignments" ON mission_client_assignments FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage mission user assignments" ON mission_user_assignments FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage mission tag assignments" ON mission_tag_assignments FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage course client assignments" ON course_client_assignments FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage course user assignments" ON course_user_assignments FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage course tag assignments" ON course_tag_assignments FOR ALL USING (auth.role() = 'authenticated');