CREATE TABLE automations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_item_id UUID NOT NULL REFERENCES content_items(id) ON DELETE CASCADE,
    automation_url TEXT NOT NULL,
    required_tools TEXT[] DEFAULT '{}',
    tool_description TEXT,
    setup_instructions TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- RLS policies
ALTER TABLE automations ENABLE ROW LEVEL SECURITY;

-- Policy for authenticated users (admins)
CREATE POLICY "Admins can manage automations" ON automations FOR ALL USING (auth.role() = 'authenticated');

-- Trigger for updated_at
CREATE TRIGGER set_automations_timestamp
    BEFORE UPDATE ON automations
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();