CREATE TABLE content_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    thumbnail_url TEXT,
    content_type TEXT NOT NULL CHECK (content_type IN ('ai_agent',
    'video',
    'document',
    'prompt',
    'automation')),
    status TEXT NOT NULL CHECK (status IN ('draft',
    'published')) DEFAULT 'draft',
    created_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);