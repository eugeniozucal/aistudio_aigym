-- Assignment tables for content management

-- Client assignments
CREATE TABLE IF NOT EXISTS content_client_assignments (
    content_item_id UUID NOT NULL REFERENCES content_items(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (content_item_id, client_id)
);

-- User assignments
CREATE TABLE IF NOT EXISTS content_user_assignments (
    content_item_id UUID NOT NULL REFERENCES content_items(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (content_item_id, user_id)
);

-- Tag assignments
CREATE TABLE IF NOT EXISTS content_tag_assignments (
    content_item_id UUID NOT NULL REFERENCES content_items(id) ON DELETE CASCADE,
    tag_id UUID NOT NULL REFERENCES user_tags(id) ON DELETE CASCADE,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (content_item_id, tag_id)
);

-- RLS policies
ALTER TABLE content_client_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_user_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_tag_assignments ENABLE ROW LEVEL SECURITY;

-- Policies for authenticated users (admins)
CREATE POLICY "Admins can manage client assignments" ON content_client_assignments FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage user assignments" ON content_user_assignments FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage tag assignments" ON content_tag_assignments FOR ALL USING (auth.role() = 'authenticated');