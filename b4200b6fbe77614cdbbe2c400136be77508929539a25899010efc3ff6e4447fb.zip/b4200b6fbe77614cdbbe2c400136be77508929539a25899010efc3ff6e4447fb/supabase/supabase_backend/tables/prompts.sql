CREATE TABLE prompts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_item_id UUID NOT NULL REFERENCES content_items(id) ON DELETE CASCADE,
    prompt_text TEXT NOT NULL,
    prompt_category TEXT,
    usage_count INTEGER DEFAULT 0,
    last_copied_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- RLS policies
ALTER TABLE prompts ENABLE ROW LEVEL SECURITY;

-- Policy for authenticated users (admins)
CREATE POLICY "Admins can manage prompts" ON prompts FOR ALL USING (auth.role() = 'authenticated');

-- Trigger for updated_at
CREATE TRIGGER set_prompts_timestamp
    BEFORE UPDATE ON prompts
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();