CREATE TABLE community_api_assignments (
    community_id UUID NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
    api_key_id UUID NOT NULL REFERENCES api_keys(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    PRIMARY KEY (community_id,
    api_key_id)
);