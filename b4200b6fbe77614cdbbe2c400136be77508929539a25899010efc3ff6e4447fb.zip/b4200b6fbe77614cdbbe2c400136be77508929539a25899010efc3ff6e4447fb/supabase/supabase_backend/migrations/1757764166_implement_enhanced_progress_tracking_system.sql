-- Migration: implement_enhanced_progress_tracking_system
-- Created at: 1757764166

-- Enhanced Progress Tracking Granularity System (Phase 7 - Step 3)
-- Comprehensive granular learning state persistence with detailed completion tracking

-- 1. Block-Level Completion Tracking Table
CREATE TABLE "public"."block_completions" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "user_id" UUID NOT NULL,
  "block_id" UUID NOT NULL,
  "page_id" UUID NOT NULL,
  "course_id" UUID,
  "wod_id" UUID,
  "client_id" UUID NOT NULL,
  
  -- Completion State Management
  "completion_status" TEXT NOT NULL DEFAULT 'not_started', -- not_started, in_progress, completed, mastered
  "completion_percentage" NUMERIC(5,2) DEFAULT 0.00,
  "mastery_score" NUMERIC(5,2) DEFAULT NULL,
  "is_mastered" BOOLEAN DEFAULT false,
  
  -- Detailed Timing Information
  "started_at" TIMESTAMPTZ DEFAULT NULL,
  "completed_at" TIMESTAMPTZ DEFAULT NULL,
  "last_accessed_at" TIMESTAMPTZ DEFAULT NOW(),
  "total_time_spent_seconds" INTEGER DEFAULT 0,
  "focused_time_seconds" INTEGER DEFAULT 0,
  "idle_time_seconds" INTEGER DEFAULT 0,
  
  -- Interaction Metrics
  "interaction_count" INTEGER DEFAULT 0,
  "click_count" INTEGER DEFAULT 0,
  "scroll_depth_percentage" NUMERIC(5,2) DEFAULT 0.00,
  "content_engagement_score" NUMERIC(5,2) DEFAULT 0.00,
  
  -- Attempt and Performance Tracking
  "attempts_count" INTEGER DEFAULT 0,
  "max_attempts" INTEGER DEFAULT NULL,
  "best_score" NUMERIC(5,2) DEFAULT NULL,
  "latest_score" NUMERIC(5,2) DEFAULT NULL,
  "performance_trend" TEXT DEFAULT NULL, -- improving, declining, stable
  
  -- Content-Specific Completion Criteria
  "completion_criteria" JSONB NOT NULL DEFAULT '{}',
  "completion_data" JSONB DEFAULT '{}',
  "block_type_specific_data" JSONB DEFAULT '{}',
  
  -- Learning Analytics Data
  "learning_velocity_score" NUMERIC(5,2) DEFAULT NULL,
  "difficulty_rating_user" INTEGER DEFAULT NULL, -- 1-5 user rating
  "confidence_level" INTEGER DEFAULT NULL, -- 1-5 user confidence
  "help_requests_count" INTEGER DEFAULT 0,
  
  -- Session and Context Information
  "current_session_id" UUID DEFAULT NULL,
  "device_type" TEXT DEFAULT NULL,
  "learning_context" TEXT DEFAULT NULL, -- focused, distracted, mobile, etc.
  
  -- Metadata
  "metadata" JSONB DEFAULT '{}',
  "created_at" TIMESTAMPTZ DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ DEFAULT NOW(),
  
  PRIMARY KEY ("id"),
  UNIQUE ("user_id", "block_id")
);

-- 2. Learning Sessions Management Table  
CREATE TABLE "public"."learning_sessions" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "user_id" UUID NOT NULL,
  "client_id" UUID NOT NULL,
  
  -- Session Basic Information
  "session_type" TEXT NOT NULL DEFAULT 'learning', -- learning, review, practice, assessment
  "session_status" TEXT DEFAULT 'active', -- active, paused, completed, abandoned
  
  -- Timing Information
  "started_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "ended_at" TIMESTAMPTZ DEFAULT NULL,
  "last_activity_at" TIMESTAMPTZ DEFAULT NOW(),
  "total_duration_seconds" INTEGER DEFAULT 0,
  "active_duration_seconds" INTEGER DEFAULT 0,
  "break_duration_seconds" INTEGER DEFAULT 0,
  
  -- Content Coverage During Session
  "content_items_accessed" JSONB DEFAULT '[]', -- Array of accessed content
  "blocks_completed" JSONB DEFAULT '[]',
  "pages_visited" JSONB DEFAULT '[]',
  "courses_progressed" JSONB DEFAULT '[]',
  "wods_progressed" JSONB DEFAULT '[]',
  
  -- Engagement and Focus Metrics
  "focus_score" NUMERIC(5,2) DEFAULT NULL, -- 0-100 focus rating
  "engagement_score" NUMERIC(5,2) DEFAULT NULL, -- 0-100 engagement rating
  "interaction_intensity" NUMERIC(5,2) DEFAULT NULL, -- interactions per minute
  "attention_span_minutes" INTEGER DEFAULT NULL,
  
  -- Learning Performance
  "learning_velocity" NUMERIC(5,2) DEFAULT NULL, -- content units per hour
  "comprehension_score" NUMERIC(5,2) DEFAULT NULL, -- avg performance in session
  "retention_score" NUMERIC(5,2) DEFAULT NULL, -- retention from previous sessions
  "progress_made_percentage" NUMERIC(5,2) DEFAULT 0.00,
  
  -- User Experience Data
  "difficulty_encountered" BOOLEAN DEFAULT false,
  "help_requests_count" INTEGER DEFAULT 0,
  "user_satisfaction_rating" INTEGER DEFAULT NULL, -- 1-5 rating
  "frustration_indicators" JSONB DEFAULT '[]',
  
  -- Technical Session Data
  "device_info" JSONB DEFAULT '{}',
  "browser_info" JSONB DEFAULT '{}',
  "connection_quality" TEXT DEFAULT NULL,
  "performance_metrics" JSONB DEFAULT '{}',
  
  -- Break and Interruption Tracking
  "break_count" INTEGER DEFAULT 0,
  "interruption_count" INTEGER DEFAULT 0,
  "multitasking_detected" BOOLEAN DEFAULT false,
  
  -- Session Goals and Outcomes
  "planned_duration_minutes" INTEGER DEFAULT NULL,
  "planned_objectives" JSONB DEFAULT '[]',
  "achieved_objectives" JSONB DEFAULT '[]',
  "next_session_recommendations" JSONB DEFAULT '{}',
  
  -- Resumption and Continuity
  "resume_point" JSONB DEFAULT '{}', -- bookmark data for resumption
  "previous_session_id" UUID DEFAULT NULL,
  "is_continuation" BOOLEAN DEFAULT false,
  
  -- Cross-Device Learning
  "device_continuity_data" JSONB DEFAULT '{}',
  "sync_status" TEXT DEFAULT 'synced', -- synced, pending, error
  
  -- Metadata and Notes
  "session_notes" TEXT DEFAULT NULL,
  "metadata" JSONB DEFAULT '{}',
  "created_at" TIMESTAMPTZ DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ DEFAULT NOW(),
  
  PRIMARY KEY ("id")
);

-- 3. Enhance User Progress Table with Learning Metrics
ALTER TABLE "public"."user_progress" 
ADD COLUMN IF NOT EXISTS "learning_velocity_score" NUMERIC(5,2) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS "engagement_quality_score" NUMERIC(5,2) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS "interaction_depth_score" NUMERIC(5,2) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS "return_frequency_score" NUMERIC(5,2) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS "learning_pattern_data" JSONB DEFAULT '{}',
ADD COLUMN IF NOT EXISTS "preferred_content_types" JSONB DEFAULT '[]',
ADD COLUMN IF NOT EXISTS "adaptive_difficulty_level" NUMERIC(3,1) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS "personalization_data" JSONB DEFAULT '{}',
ADD COLUMN IF NOT EXISTS "mastery_prediction_score" NUMERIC(5,2) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS "estimated_completion_time" INTERVAL DEFAULT NULL,
ADD COLUMN IF NOT EXISTS "learning_efficiency_score" NUMERIC(5,2) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS "knowledge_retention_score" NUMERIC(5,2) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS "skill_degradation_risk" NUMERIC(5,2) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS "last_mastery_check_at" TIMESTAMPTZ DEFAULT NULL,
ADD COLUMN IF NOT EXISTS "session_metrics" JSONB DEFAULT '{}',
ADD COLUMN IF NOT EXISTS "performance_analytics" JSONB DEFAULT '{}';

-- 4. Create indexes for optimal performance
CREATE INDEX IF NOT EXISTS "idx_block_completions_user_id" ON "public"."block_completions" ("user_id");
CREATE INDEX IF NOT EXISTS "idx_block_completions_block_id" ON "public"."block_completions" ("block_id");
CREATE INDEX IF NOT EXISTS "idx_block_completions_client_id" ON "public"."block_completions" ("client_id");
CREATE INDEX IF NOT EXISTS "idx_block_completions_status" ON "public"."block_completions" ("completion_status");
CREATE INDEX IF NOT EXISTS "idx_block_completions_last_accessed" ON "public"."block_completions" ("last_accessed_at");
CREATE INDEX IF NOT EXISTS "idx_block_completions_course_id" ON "public"."block_completions" ("course_id");

CREATE INDEX IF NOT EXISTS "idx_learning_sessions_user_id" ON "public"."learning_sessions" ("user_id");
CREATE INDEX IF NOT EXISTS "idx_learning_sessions_client_id" ON "public"."learning_sessions" ("client_id");
CREATE INDEX IF NOT EXISTS "idx_learning_sessions_status" ON "public"."learning_sessions" ("session_status");
CREATE INDEX IF NOT EXISTS "idx_learning_sessions_started_at" ON "public"."learning_sessions" ("started_at");
CREATE INDEX IF NOT EXISTS "idx_learning_sessions_last_activity" ON "public"."learning_sessions" ("last_activity_at");

CREATE INDEX IF NOT EXISTS "idx_user_progress_enhanced" ON "public"."user_progress" ("user_id", "client_id", "progress_type");

-- 5. Row Level Security Policies for Block Completions
ALTER TABLE "public"."block_completions" ENABLE ROW LEVEL SECURITY;

-- Users can only see their own block completions
CREATE POLICY "block_completions_select_policy" ON "public"."block_completions"
  FOR SELECT USING (
    user_id = auth.uid() OR
    (client_id IN (SELECT client_id FROM users WHERE id = auth.uid()))
  );

-- Users can insert their own block completions
CREATE POLICY "block_completions_insert_policy" ON "public"."block_completions"
  FOR INSERT WITH CHECK (
    user_id = auth.uid() AND 
    client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
  );

-- Users can update their own block completions
CREATE POLICY "block_completions_update_policy" ON "public"."block_completions"
  FOR UPDATE USING (
    user_id = auth.uid() OR
    (client_id IN (SELECT client_id FROM users WHERE id = auth.uid()))
  )
  WITH CHECK (
    user_id = auth.uid() AND
    client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
  );

-- Users can delete their own block completions (or admins can delete for their clients)
CREATE POLICY "block_completions_delete_policy" ON "public"."block_completions"
  FOR DELETE USING (
    user_id = auth.uid() OR
    (client_id IN (SELECT client_id FROM users WHERE id = auth.uid()))
  );

-- 6. Row Level Security Policies for Learning Sessions
ALTER TABLE "public"."learning_sessions" ENABLE ROW LEVEL SECURITY;

-- Users can only see their own learning sessions
CREATE POLICY "learning_sessions_select_policy" ON "public"."learning_sessions"
  FOR SELECT USING (
    user_id = auth.uid() OR
    (client_id IN (SELECT client_id FROM users WHERE id = auth.uid()))
  );

-- Users can insert their own learning sessions
CREATE POLICY "learning_sessions_insert_policy" ON "public"."learning_sessions"
  FOR INSERT WITH CHECK (
    user_id = auth.uid() AND 
    client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
  );

-- Users can update their own learning sessions
CREATE POLICY "learning_sessions_update_policy" ON "public"."learning_sessions"
  FOR UPDATE USING (
    user_id = auth.uid() OR
    (client_id IN (SELECT client_id FROM users WHERE id = auth.uid()))
  )
  WITH CHECK (
    user_id = auth.uid() AND
    client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
  );

-- Users can delete their own learning sessions (or admins can delete for their clients)
CREATE POLICY "learning_sessions_delete_policy" ON "public"."learning_sessions"
  FOR DELETE USING (
    user_id = auth.uid() OR
    (client_id IN (SELECT client_id FROM users WHERE id = auth.uid()))
  );

-- 7. Create helpful views for aggregated progress data
CREATE OR REPLACE VIEW "public"."user_learning_analytics" AS
SELECT 
  up.user_id,
  up.client_id,
  up.progress_type,
  COUNT(bc.id) as total_blocks_started,
  COUNT(CASE WHEN bc.completion_status = 'completed' THEN 1 END) as blocks_completed,
  COUNT(CASE WHEN bc.completion_status = 'mastered' THEN 1 END) as blocks_mastered,
  AVG(bc.completion_percentage) as avg_block_completion,
  AVG(bc.total_time_spent_seconds) as avg_time_per_block,
  AVG(bc.content_engagement_score) as avg_engagement_score,
  COUNT(ls.id) as total_learning_sessions,
  AVG(ls.focus_score) as avg_focus_score,
  AVG(ls.learning_velocity) as avg_learning_velocity,
  SUM(ls.total_duration_seconds) as total_learning_time,
  up.learning_velocity_score,
  up.engagement_quality_score,
  up.knowledge_retention_score
FROM user_progress up
LEFT JOIN block_completions bc ON bc.user_id = up.user_id
LEFT JOIN learning_sessions ls ON ls.user_id = up.user_id
GROUP BY up.user_id, up.client_id, up.progress_type, 
         up.learning_velocity_score, up.engagement_quality_score, up.knowledge_retention_score;

-- 8. Create trigger to automatically update user_progress when block completions change
CREATE OR REPLACE FUNCTION update_progress_from_block_completions()
RETURNS TRIGGER AS $$
BEGIN
  -- Update the corresponding user_progress record with aggregated data from block_completions
  UPDATE user_progress 
  SET 
    completion_percentage = (
      SELECT AVG(completion_percentage) 
      FROM block_completions bc2 
      WHERE bc2.user_id = NEW.user_id 
      AND (
        (bc2.course_id = user_progress.course_id AND user_progress.course_id IS NOT NULL) OR
        (bc2.wod_id = user_progress.wod_id AND user_progress.wod_id IS NOT NULL) OR
        (bc2.page_id = user_progress.page_id AND user_progress.page_id IS NOT NULL)
      )
    ),
    time_spent_seconds = (
      SELECT SUM(total_time_spent_seconds) 
      FROM block_completions bc2 
      WHERE bc2.user_id = NEW.user_id 
      AND (
        (bc2.course_id = user_progress.course_id AND user_progress.course_id IS NOT NULL) OR
        (bc2.wod_id = user_progress.wod_id AND user_progress.wod_id IS NOT NULL) OR
        (bc2.page_id = user_progress.page_id AND user_progress.page_id IS NOT NULL)
      )
    ),
    engagement_quality_score = (
      SELECT AVG(content_engagement_score) 
      FROM block_completions bc2 
      WHERE bc2.user_id = NEW.user_id 
      AND (
        (bc2.course_id = user_progress.course_id AND user_progress.course_id IS NOT NULL) OR
        (bc2.wod_id = user_progress.wod_id AND user_progress.wod_id IS NOT NULL) OR
        (bc2.page_id = user_progress.page_id AND user_progress.page_id IS NOT NULL)
      )
    ),
    updated_at = NOW()
  WHERE user_progress.user_id = NEW.user_id
  AND (
    (NEW.course_id = user_progress.course_id AND user_progress.course_id IS NOT NULL) OR
    (NEW.wod_id = user_progress.wod_id AND user_progress.wod_id IS NOT NULL) OR
    (NEW.page_id = user_progress.page_id AND user_progress.page_id IS NOT NULL)
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_progress_from_blocks
  AFTER INSERT OR UPDATE ON block_completions
  FOR EACH ROW EXECUTE FUNCTION update_progress_from_block_completions();

-- 9. Comments for documentation
COMMENT ON TABLE "public"."block_completions" IS 'Granular tracking of individual content block completion states with detailed learning metrics';
COMMENT ON TABLE "public"."learning_sessions" IS 'Comprehensive learning session management with focus, engagement, and performance tracking';
COMMENT ON VIEW "public"."user_learning_analytics" IS 'Aggregated view of user learning analytics combining progress, block completions, and session data';;