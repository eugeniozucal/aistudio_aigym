-- Migration: create_communities_table
-- Created at: 1758031850

-- Create communities table as replacement for clients table
CREATE TABLE communities (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  project_name text,
  logo_url text,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  status text DEFAULT 'active'::text,
  template_source_id uuid,
  api_key_id uuid,
  brand_color character varying(255) DEFAULT '#3B82F6'::character varying,
  forum_enabled boolean DEFAULT true,
  is_template boolean DEFAULT false
);

-- Add foreign key constraint for template_source_id to reference communities table
ALTER TABLE communities ADD CONSTRAINT communities_template_source_id_fkey 
  FOREIGN KEY (template_source_id) REFERENCES communities(id);

-- Create indexes similar to clients table
CREATE INDEX IF NOT EXISTS communities_name_idx ON communities(name);
CREATE INDEX IF NOT EXISTS communities_status_idx ON communities(status);
CREATE INDEX IF NOT EXISTS communities_created_at_idx ON communities(created_at);;