-- Migration: create_folders_and_update_tables
-- Created at: 1758087906

-- Create folders table for organizing WODs and BLOCKS
CREATE TABLE folders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR NOT NULL,
  parent_folder_id UUID REFERENCES folders(id),
  repository_type VARCHAR NOT NULL CHECK (repository_type IN ('wods', 'blocks')),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Add folder_id to existing tables
ALTER TABLE wods ADD COLUMN folder_id UUID REFERENCES folders(id);
ALTER TABLE workout_blocks ADD COLUMN folder_id UUID REFERENCES folders(id);

-- Add is_favorite column for favoriting functionality
ALTER TABLE wods ADD COLUMN is_favorite BOOLEAN DEFAULT FALSE;
ALTER TABLE workout_blocks ADD COLUMN is_favorite BOOLEAN DEFAULT FALSE;

-- Create indexes for better performance
CREATE INDEX idx_folders_repository_type ON folders(repository_type);
CREATE INDEX idx_folders_parent_folder_id ON folders(parent_folder_id);
CREATE INDEX idx_wods_folder_id ON wods(folder_id);
CREATE INDEX idx_workout_blocks_folder_id ON workout_blocks(folder_id);
CREATE INDEX idx_wods_is_favorite ON wods(is_favorite);
CREATE INDEX idx_workout_blocks_is_favorite ON workout_blocks(is_favorite);

-- Update updated_at timestamp automatically
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_folders_updated_at BEFORE UPDATE ON folders
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();;