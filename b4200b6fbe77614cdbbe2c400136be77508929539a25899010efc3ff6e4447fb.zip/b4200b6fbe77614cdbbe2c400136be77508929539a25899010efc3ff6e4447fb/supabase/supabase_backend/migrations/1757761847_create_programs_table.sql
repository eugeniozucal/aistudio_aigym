-- Migration: create_programs_table
-- Created at: 1757761847

-- Create programs table with comprehensive metadata
CREATE TABLE IF NOT EXISTS programs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    thumbnail_url TEXT,
    program_type TEXT NOT NULL DEFAULT 'training', -- 'certification', 'training', 'assessment', 'pathway'
    status TEXT NOT NULL DEFAULT 'draft', -- 'draft', 'published', 'archived'
    
    -- Course sequencing and structure
    course_sequence JSONB DEFAULT '[]'::jsonb, -- array of course IDs in order
    prerequisites JSONB DEFAULT '[]'::jsonb, -- prerequisite program IDs or conditions
    is_sequential BOOLEAN DEFAULT true, -- true = linear progression, false = flexible order
    
    -- Program metadata
    estimated_duration_hours INTEGER, -- total estimated hours
    difficulty_level TEXT, -- 'beginner', 'intermediate', 'advanced', 'expert'
    target_audience JSONB DEFAULT '{}'::jsonb, -- audience specifications
    
    -- Program settings
    enrollment_capacity INTEGER, -- max enrollments (null = unlimited)
    enrollment_deadline DATE,
    start_date DATE,
    end_date DATE,
    is_self_paced BOOLEAN DEFAULT true,
    
    -- Completion and certification
    completion_criteria JSONB DEFAULT '{}'::jsonb, -- completion requirements
    certificate_template TEXT, -- certificate template
    certificate_available BOOLEAN DEFAULT false,
    completion_badge_url TEXT,
    
    -- Program categorization
    category TEXT, -- 'fitness', 'nutrition', 'wellness', etc.
    tags TEXT[] DEFAULT '{}',
    keywords TEXT[], -- for search
    
    -- Pricing and access
    price NUMERIC DEFAULT 0,
    access_level TEXT DEFAULT 'public', -- 'public', 'private', 'premium'
    
    -- Multi-tenant support
    client_id UUID,
    created_by UUID NOT NULL,
    instructor_ids UUID[] DEFAULT '{}', -- array of instructor user IDs
    
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    published_at TIMESTAMPTZ,
    
    -- Indexes for performance
    CONSTRAINT programs_title_check CHECK (length(title) > 0),
    CONSTRAINT programs_status_check CHECK (status IN ('draft', 'published', 'archived')),
    CONSTRAINT programs_type_check CHECK (program_type IN ('certification', 'training', 'assessment', 'pathway')),
    CONSTRAINT programs_difficulty_check CHECK (difficulty_level IN ('beginner', 'intermediate', 'advanced', 'expert') OR difficulty_level IS NULL),
    CONSTRAINT programs_access_check CHECK (access_level IN ('public', 'private', 'premium'))
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS programs_status_idx ON programs(status);
CREATE INDEX IF NOT EXISTS programs_type_idx ON programs(program_type);
CREATE INDEX IF NOT EXISTS programs_difficulty_idx ON programs(difficulty_level);
CREATE INDEX IF NOT EXISTS programs_category_idx ON programs(category);
CREATE INDEX IF NOT EXISTS programs_client_id_idx ON programs(client_id);
CREATE INDEX IF NOT EXISTS programs_created_by_idx ON programs(created_by);
CREATE INDEX IF NOT EXISTS programs_updated_at_idx ON programs(updated_at DESC);

-- Full text search index
CREATE INDEX IF NOT EXISTS programs_search_idx ON programs USING gin(to_tsvector('english', title || ' ' || COALESCE(description, '')));;