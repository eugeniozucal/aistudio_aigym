-- Migration: cleanup_orphaned_community_references
-- Created at: 1758032140

-- Clean up orphaned records that reference non-existent communities
-- This removes data that was already inconsistent in the original database

-- Find and remove orphaned course_enrollments
DELETE FROM course_enrollments 
WHERE community_id NOT IN (SELECT id FROM communities);

-- Check for orphaned records in other tables and clean them up
DELETE FROM content_engagements 
WHERE community_id NOT IN (SELECT id FROM communities);

DELETE FROM learning_analytics 
WHERE community_id NOT IN (SELECT id FROM communities);

DELETE FROM learning_sessions 
WHERE community_id NOT IN (SELECT id FROM communities);

DELETE FROM performance_history 
WHERE community_id NOT IN (SELECT id FROM communities);

DELETE FROM program_enrollments 
WHERE community_id NOT IN (SELECT id FROM communities);

-- Report how many records were cleaned up
SELECT 'Orphaned data cleanup completed' as status;;