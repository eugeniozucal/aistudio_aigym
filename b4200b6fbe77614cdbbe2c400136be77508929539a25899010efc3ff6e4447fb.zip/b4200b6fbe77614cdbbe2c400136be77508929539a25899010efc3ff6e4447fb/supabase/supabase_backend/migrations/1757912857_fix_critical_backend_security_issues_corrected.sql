-- Migration: fix_critical_backend_security_issues_corrected
-- Created at: 1757912857

-- Critical Backend Security Fixes Migration (Corrected)
-- Based on backend audit findings

-- 1. Fix overly permissive admin policy
DROP POLICY IF EXISTS "Allow authenticated users to read admin records" ON admins;
CREATE POLICY "Admins can read own record" ON admins 
FOR SELECT USING (id = auth.uid());

-- 2. Add missing RLS policies for tables that lack them
ALTER TABLE user_activities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "User activities scoped to client" ON user_activities
FOR ALL USING (client_id = (SELECT client_id FROM users WHERE id = auth.uid()));

ALTER TABLE content_engagements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Content engagements scoped to client" ON content_engagements
FOR ALL USING (client_id = (SELECT client_id FROM users WHERE id = auth.uid()));

ALTER TABLE agent_conversations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Agent conversations scoped to client" ON agent_conversations
FOR ALL USING (
    user_id IN (
        SELECT id FROM users 
        WHERE client_id = (SELECT client_id FROM users WHERE id = auth.uid())
    )
);

ALTER TABLE platform_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform settings admin only" ON platform_settings
FOR ALL USING (
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);

ALTER TABLE bulk_uploads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Bulk uploads admin only" ON bulk_uploads
FOR ALL USING (
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);

ALTER TABLE uploaded_files ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Uploaded files scoped to uploader or admin" ON uploaded_files
FOR ALL USING (
    uploaded_by = auth.uid() OR 
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);

-- 3. Create missing audit logging table
CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    admin_id UUID NOT NULL,
    action_type TEXT NOT NULL,
    table_name TEXT,
    record_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address TEXT,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Audit logs admin read only" ON audit_logs
FOR SELECT USING (
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);

-- 4. Create system notifications table
CREATE TABLE IF NOT EXISTS system_notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recipient_type TEXT NOT NULL CHECK (recipient_type IN ('admin', 'client', 'user')),
    recipient_id UUID NOT NULL,
    notification_type TEXT NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    priority TEXT DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
    is_read BOOLEAN DEFAULT false,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    read_at TIMESTAMPTZ
);

ALTER TABLE system_notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Notifications for recipient" ON system_notifications
FOR ALL USING (
    (recipient_type = 'admin' AND recipient_id = auth.uid()) OR
    (recipient_type = 'user' AND recipient_id = auth.uid()) OR
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);

-- 5. Create admin user with proper credentials
INSERT INTO admins (id, email, password_hash, role) 
VALUES (
    'a0000000-0000-0000-0000-000000000001',
    'ez@aiworkify.com',
    crypt('EzU8264!', gen_salt('bf')),
    'super_admin'
) ON CONFLICT (email) DO UPDATE SET
    password_hash = crypt('EzU8264!', gen_salt('bf')),
    role = 'super_admin';

-- 6. Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_audit_logs_admin_id ON audit_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action_type ON audit_logs(action_type);

CREATE INDEX IF NOT EXISTS idx_system_notifications_recipient ON system_notifications(recipient_type, recipient_id);
CREATE INDEX IF NOT EXISTS idx_system_notifications_unread ON system_notifications(is_read) WHERE is_read = false;

CREATE INDEX IF NOT EXISTS idx_content_items_type_status ON content_items(content_type, status);
CREATE INDEX IF NOT EXISTS idx_users_client_active ON users(client_id, last_active);
CREATE INDEX IF NOT EXISTS idx_blocks_type_visible ON blocks(block_type, is_visible);;