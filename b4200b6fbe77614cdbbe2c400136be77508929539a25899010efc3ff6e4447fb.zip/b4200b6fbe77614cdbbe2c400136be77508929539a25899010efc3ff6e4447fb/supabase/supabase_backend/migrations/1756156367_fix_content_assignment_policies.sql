-- Migration: fix_content_assignment_policies
-- Created at: 1756156367

-- Ensure proper RLS policies for content assignment tables

-- Content client assignments
DROP POLICY IF EXISTS "Admin access to content_client_assignments" ON content_client_assignments;

CREATE POLICY "Admins can manage content_client_assignments"
ON content_client_assignments
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admins 
    WHERE admins.id = auth.uid()
  )
);

CREATE POLICY "Service role full access to content_client_assignments"
ON content_client_assignments
FOR ALL
TO service_role
USING (true);

-- Content user assignments
DROP POLICY IF EXISTS "Admin access to content_user_assignments" ON content_user_assignments;

CREATE POLICY "Admins can manage content_user_assignments"
ON content_user_assignments
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admins 
    WHERE admins.id = auth.uid()
  )
);

CREATE POLICY "Service role full access to content_user_assignments"
ON content_user_assignments
FOR ALL
TO service_role
USING (true);;