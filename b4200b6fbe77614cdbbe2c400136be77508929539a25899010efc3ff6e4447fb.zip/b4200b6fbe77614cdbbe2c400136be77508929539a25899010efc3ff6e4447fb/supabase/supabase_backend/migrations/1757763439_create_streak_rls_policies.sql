-- Migration: create_streak_rls_policies
-- Created at: 1757763439

-- Migration: create_streak_rls_policies
-- Created at: 1757762400

-- Enable RLS on streak and performance tracking tables
ALTER TABLE user_streaks ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_daily_activity ENABLE ROW LEVEL SECURITY;
ALTER TABLE performance_history ENABLE ROW LEVEL SECURITY;

-- User streaks table policies
CREATE POLICY user_streaks_select_policy ON user_streaks
    FOR SELECT USING (
        -- Users can see their own streaks
        user_id = auth.uid()
        OR
        -- Client admin access within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = auth.uid() 
                AND u.client_id = user_streaks.client_id
            )
        )
    );

CREATE POLICY user_streaks_insert_policy ON user_streaks
    FOR INSERT WITH CHECK (
        user_id = auth.uid()
        AND client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
    );

CREATE POLICY user_streaks_update_policy ON user_streaks
    FOR UPDATE USING (
        user_id = auth.uid()
        OR
        -- Client admin access within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = auth.uid() 
                AND u.client_id = user_streaks.client_id
            )
        )
    ) WITH CHECK (
        user_id = auth.uid()
        OR
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = user_id 
                AND u.client_id = user_streaks.client_id
            )
        )
    );

CREATE POLICY user_streaks_delete_policy ON user_streaks
    FOR DELETE USING (
        -- Client admin can delete streak records within same client
        client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
        AND EXISTS (
            SELECT 1 FROM users u 
            WHERE u.id = auth.uid() 
            AND u.client_id = user_streaks.client_id
        )
    );

-- User daily activity table policies
CREATE POLICY user_daily_activity_select_policy ON user_daily_activity
    FOR SELECT USING (
        -- Users can see their own daily activity
        user_id = auth.uid()
        OR
        -- Client admin access within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = auth.uid() 
                AND u.client_id = user_daily_activity.client_id
            )
        )
    );

CREATE POLICY user_daily_activity_insert_policy ON user_daily_activity
    FOR INSERT WITH CHECK (
        user_id = auth.uid()
        AND client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
    );

CREATE POLICY user_daily_activity_update_policy ON user_daily_activity
    FOR UPDATE USING (
        user_id = auth.uid()
        OR
        -- Client admin access within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = auth.uid() 
                AND u.client_id = user_daily_activity.client_id
            )
        )
    ) WITH CHECK (
        user_id = auth.uid()
        OR
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = user_id 
                AND u.client_id = user_daily_activity.client_id
            )
        )
    );

CREATE POLICY user_daily_activity_delete_policy ON user_daily_activity
    FOR DELETE USING (
        -- Client admin can delete activity records within same client
        client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
        AND EXISTS (
            SELECT 1 FROM users u 
            WHERE u.id = auth.uid() 
            AND u.client_id = user_daily_activity.client_id
        )
    );

-- Performance history table policies
CREATE POLICY performance_history_select_policy ON performance_history
    FOR SELECT USING (
        -- Users can see their own performance history
        user_id = auth.uid()
        OR
        -- Client admin access within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = auth.uid() 
                AND u.client_id = performance_history.client_id
            )
        )
    );

CREATE POLICY performance_history_insert_policy ON performance_history
    FOR INSERT WITH CHECK (
        user_id = auth.uid()
        AND client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
    );

CREATE POLICY performance_history_update_policy ON performance_history
    FOR UPDATE USING (
        user_id = auth.uid()
        OR
        -- Client admin access within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = auth.uid() 
                AND u.client_id = performance_history.client_id
            )
        )
    ) WITH CHECK (
        user_id = auth.uid()
        OR
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = user_id 
                AND u.client_id = performance_history.client_id
            )
        )
    );

CREATE POLICY performance_history_delete_policy ON performance_history
    FOR DELETE USING (
        -- Client admin can delete performance records within same client
        client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
        AND EXISTS (
            SELECT 1 FROM users u 
            WHERE u.id = auth.uid() 
            AND u.client_id = performance_history.client_id
        )
    );;