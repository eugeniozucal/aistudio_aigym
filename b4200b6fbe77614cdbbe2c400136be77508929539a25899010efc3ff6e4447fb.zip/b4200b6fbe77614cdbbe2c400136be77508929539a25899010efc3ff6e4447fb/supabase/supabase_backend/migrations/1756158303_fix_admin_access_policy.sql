-- Migration: fix_admin_access_policy
-- Created at: 1756158303

-- Temporarily allow all authenticated users to read admin records
DROP POLICY IF EXISTS "Allow authenticated users to read own admin record" ON admins;

CREATE POLICY "Allow authenticated users to read admin records"
ON admins FOR SELECT
TO authenticated
USING (true);;