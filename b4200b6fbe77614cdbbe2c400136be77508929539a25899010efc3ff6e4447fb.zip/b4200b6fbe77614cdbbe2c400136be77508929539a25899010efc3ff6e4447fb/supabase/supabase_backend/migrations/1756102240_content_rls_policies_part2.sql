-- Migration: content_rls_policies_part2
-- Created at: 1756102240

-- Prompts: Similar pattern
CREATE POLICY "Admin full access to prompts" 
ON prompts
FOR ALL
TO authenticated
USING (
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);

CREATE POLICY "Users see assigned prompts" 
ON prompts
FOR SELECT
TO authenticated
USING (
    NOT EXISTS (SELECT 1 FROM admins WHERE id = auth.uid()) 
    AND content_item_id IN (
        SELECT id FROM content_items WHERE 
        id IN (
            SELECT content_item_id FROM content_client_assignments 
            WHERE client_id = (SELECT client_id FROM users WHERE id = auth.uid() LIMIT 1)
        )
        OR id IN (
            SELECT content_item_id FROM content_user_assignments 
            WHERE user_id = auth.uid()
        )
        OR id IN (
            SELECT content_item_id FROM content_tag_assignments 
            WHERE tag_id IN (
                SELECT tag_id FROM user_tag_assignments 
                WHERE user_id = auth.uid()
            )
        )
    )
);

-- Automations: Similar pattern
CREATE POLICY "Admin full access to automations" 
ON automations
FOR ALL
TO authenticated
USING (
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);

CREATE POLICY "Users see assigned automations" 
ON automations
FOR SELECT
TO authenticated
USING (
    NOT EXISTS (SELECT 1 FROM admins WHERE id = auth.uid()) 
    AND content_item_id IN (
        SELECT id FROM content_items WHERE 
        id IN (
            SELECT content_item_id FROM content_client_assignments 
            WHERE client_id = (SELECT client_id FROM users WHERE id = auth.uid() LIMIT 1)
        )
        OR id IN (
            SELECT content_item_id FROM content_user_assignments 
            WHERE user_id = auth.uid()
        )
        OR id IN (
            SELECT content_item_id FROM content_tag_assignments 
            WHERE tag_id IN (
                SELECT tag_id FROM user_tag_assignments 
                WHERE user_id = auth.uid()
            )
        )
    )
);

-- Assignment tables: Admin access only (they control assignments)
CREATE POLICY "Admin manages content client assignments" 
ON content_client_assignments
FOR ALL
TO authenticated
USING (
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);

CREATE POLICY "Admin manages content user assignments" 
ON content_user_assignments
FOR ALL
TO authenticated
USING (
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);

CREATE POLICY "Admin manages content tag assignments" 
ON content_tag_assignments
FOR ALL
TO authenticated
USING (
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);;