-- Migration: add_community_foreign_key_constraints_batch3
-- Created at: 1758032087

-- Add foreign key constraints for community_id columns (batch 3)
-- Mandatory relationships
ALTER TABLE content_engagements 
  ALTER COLUMN community_id SET NOT NULL,
  ADD CONSTRAINT content_engagements_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE CASCADE;

ALTER TABLE course_enrollments 
  ALTER COLUMN community_id SET NOT NULL,
  ADD CONSTRAINT course_enrollments_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE CASCADE;

ALTER TABLE learning_analytics 
  ALTER COLUMN community_id SET NOT NULL,
  ADD CONSTRAINT learning_analytics_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE CASCADE;

ALTER TABLE learning_sessions 
  ALTER COLUMN community_id SET NOT NULL,
  ADD CONSTRAINT learning_sessions_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE CASCADE;

ALTER TABLE performance_history 
  ALTER COLUMN community_id SET NOT NULL,
  ADD CONSTRAINT performance_history_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE CASCADE;

ALTER TABLE program_enrollments 
  ALTER COLUMN community_id SET NOT NULL,
  ADD CONSTRAINT program_enrollments_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE CASCADE;;