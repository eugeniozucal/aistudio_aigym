-- Migration: create_comprehensive_learning_analytics_system_fixed
-- Created at: 1757765514

-- Create learning_analytics table for periodic metric computation and advanced analytics
CREATE TABLE "public"."learning_analytics" (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL PRIMARY KEY,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    analytics_period text NOT NULL, -- daily, weekly, monthly, quarterly
    period_start_date timestamp with time zone NOT NULL,
    period_end_date timestamp with time zone NOT NULL,
    
    -- Performance Metrics
    total_learning_time_minutes integer DEFAULT 0,
    active_learning_time_minutes integer DEFAULT 0,
    learning_sessions_count integer DEFAULT 0,
    blocks_attempted integer DEFAULT 0,
    blocks_completed integer DEFAULT 0,
    blocks_mastered integer DEFAULT 0,
    
    -- Learning Velocity Metrics
    avg_learning_velocity numeric(8,4) DEFAULT 0,
    learning_velocity_trend text, -- improving, declining, stable
    content_consumption_rate numeric(8,4) DEFAULT 0, -- blocks per hour
    
    -- Engagement Quality Metrics
    avg_engagement_score numeric(5,2) DEFAULT 0,
    avg_focus_score numeric(5,2) DEFAULT 0,
    interaction_intensity numeric(5,2) DEFAULT 0,
    attention_span_minutes integer DEFAULT 0,
    break_frequency numeric(5,2) DEFAULT 0, -- breaks per hour
    
    -- Performance Analysis
    avg_completion_percentage numeric(5,2) DEFAULT 0,
    avg_mastery_score numeric(5,2) DEFAULT 0,
    performance_consistency_score numeric(5,2) DEFAULT 0,
    improvement_rate numeric(5,2) DEFAULT 0, -- percentage improvement
    
    -- Knowledge Retention
    retention_score numeric(5,2) DEFAULT 0,
    skill_degradation_risk numeric(5,2) DEFAULT 0,
    knowledge_decay_rate numeric(5,2) DEFAULT 0,
    
    -- Learning Patterns
    preferred_session_duration_minutes integer DEFAULT 0,
    optimal_learning_times jsonb DEFAULT '[]', -- hours when most productive
    content_type_preferences jsonb DEFAULT '{}', -- performance by content type
    device_usage_patterns jsonb DEFAULT '{}', -- performance by device
    
    -- Predictive Metrics
    completion_prediction_score numeric(5,2) DEFAULT 0,
    at_risk_indicator boolean DEFAULT false,
    estimated_time_to_mastery_hours numeric(8,2) DEFAULT 0,
    success_probability numeric(5,2) DEFAULT 0,
    
    -- Comparative Analytics
    peer_ranking_percentile numeric(5,2) DEFAULT 0,
    cohort_comparison_score numeric(5,2) DEFAULT 0,
    organizational_benchmark_score numeric(5,2) DEFAULT 0,
    
    -- Learning Efficiency
    time_efficiency_score numeric(5,2) DEFAULT 0, -- progress per time invested
    effort_efficiency_score numeric(5,2) DEFAULT 0, -- mastery per attempts
    help_seeking_frequency numeric(5,2) DEFAULT 0,
    self_sufficiency_score numeric(5,2) DEFAULT 0,
    
    -- Engagement Patterns
    return_frequency numeric(5,2) DEFAULT 0, -- sessions per period
    session_completion_rate numeric(5,2) DEFAULT 0,
    content_abandonment_rate numeric(5,2) DEFAULT 0,
    goal_achievement_rate numeric(5,2) DEFAULT 0,
    
    -- Advanced Insights
    learning_style_indicators jsonb DEFAULT '{}',
    strength_areas jsonb DEFAULT '[]',
    improvement_areas jsonb DEFAULT '[]',
    recommended_interventions jsonb DEFAULT '[]',
    personalized_recommendations jsonb DEFAULT '[]',
    
    -- Metadata
    computation_timestamp timestamp with time zone DEFAULT NOW(),
    last_updated timestamp with time zone DEFAULT NOW(),
    data_quality_score numeric(5,2) DEFAULT 100, -- reliability of computed metrics
    metadata jsonb DEFAULT '{}',
    
    created_at timestamp with time zone DEFAULT NOW(),
    updated_at timestamp with time zone DEFAULT NOW()
);

-- Create indexes for efficient querying
CREATE INDEX idx_learning_analytics_user_period ON learning_analytics (user_id, analytics_period, period_start_date);
CREATE INDEX idx_learning_analytics_client_period ON learning_analytics (client_id, analytics_period, period_start_date);
CREATE INDEX idx_learning_analytics_at_risk ON learning_analytics (at_risk_indicator) WHERE at_risk_indicator = true;
CREATE INDEX idx_learning_analytics_ranking ON learning_analytics (peer_ranking_percentile, analytics_period);

-- Row Level Security Policy
ALTER TABLE learning_analytics ENABLE ROW LEVEL SECURITY;

-- Policy for user access to their own analytics
CREATE POLICY "Users can access their own learning analytics" ON learning_analytics
FOR SELECT USING (auth.uid() = user_id);

-- Policy for client-scoped access (simplified without role check)
CREATE POLICY "Client users can access client learning analytics" ON learning_analytics
FOR SELECT USING (
  client_id IN (
    SELECT client_id FROM users WHERE users.id = auth.uid()
  )
);

-- Create performance benchmarks table for comparative analytics
CREATE TABLE "public"."performance_benchmarks" (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL PRIMARY KEY,
    benchmark_type text NOT NULL, -- industry, organizational, cohort, course
    benchmark_scope text NOT NULL, -- global, client, program, course
    scope_id uuid, -- client_id, program_id, course_id for scoped benchmarks
    
    content_type text, -- course, wod, program
    difficulty_level text,
    
    -- Benchmark Metrics
    avg_completion_time_hours numeric(8,2) DEFAULT 0,
    avg_mastery_score numeric(5,2) DEFAULT 0,
    avg_engagement_score numeric(5,2) DEFAULT 0,
    median_attempts integer DEFAULT 0,
    success_rate_percentage numeric(5,2) DEFAULT 0,
    
    -- Percentile Data for Rankings
    performance_percentiles jsonb DEFAULT '{}', -- P10, P25, P50, P75, P90
    velocity_percentiles jsonb DEFAULT '{}',
    engagement_percentiles jsonb DEFAULT '{}',
    
    sample_size integer DEFAULT 0,
    last_computed timestamp with time zone DEFAULT NOW(),
    computation_period_days integer DEFAULT 30,
    
    metadata jsonb DEFAULT '{}',
    created_at timestamp with time zone DEFAULT NOW(),
    updated_at timestamp with time zone DEFAULT NOW()
);

-- Index for benchmark queries
CREATE INDEX idx_performance_benchmarks_type_scope ON performance_benchmarks (benchmark_type, benchmark_scope, scope_id);

-- Enable RLS for benchmarks
ALTER TABLE performance_benchmarks ENABLE ROW LEVEL SECURITY;

-- Policy for benchmark access
CREATE POLICY "Users can access relevant benchmarks" ON performance_benchmarks
FOR SELECT USING (
  benchmark_scope = 'global' OR
  (benchmark_scope = 'client' AND scope_id IN (
    SELECT client_id FROM users WHERE users.id = auth.uid()
  ))
);

-- Create analytics computation log for tracking batch processes
CREATE TABLE "public"."analytics_computation_log" (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL PRIMARY KEY,
    computation_type text NOT NULL, -- daily, weekly, monthly, benchmarks
    computation_scope text NOT NULL, -- user, client, global
    scope_id uuid, -- user_id or client_id
    
    status text NOT NULL DEFAULT 'pending', -- pending, running, completed, failed
    started_at timestamp with time zone DEFAULT NOW(),
    completed_at timestamp with time zone,
    
    records_processed integer DEFAULT 0,
    records_updated integer DEFAULT 0,
    errors_count integer DEFAULT 0,
    error_details jsonb DEFAULT '{}',
    
    computation_duration_seconds integer,
    performance_metrics jsonb DEFAULT '{}',
    
    created_at timestamp with time zone DEFAULT NOW()
);

-- Index for computation log
CREATE INDEX idx_analytics_computation_log_type_status ON analytics_computation_log (computation_type, status, started_at);

-- Enable RLS for computation log
ALTER TABLE analytics_computation_log ENABLE ROW LEVEL SECURITY;

-- Policy for computation log access (only authenticated users can see their own client's logs)
CREATE POLICY "Users can access client computation logs" ON analytics_computation_log
FOR SELECT USING (
  scope_id IN (
    SELECT client_id FROM users WHERE users.id = auth.uid()
  ) OR
  scope_id = auth.uid()
);

-- Create function to compute learning analytics for a user and period
CREATE OR REPLACE FUNCTION compute_user_learning_analytics(
    p_user_id uuid,
    p_client_id uuid,
    p_period text,
    p_start_date timestamp with time zone,
    p_end_date timestamp with time zone
) RETURNS jsonb AS $$
DECLARE
    result jsonb;
    block_stats jsonb;
    session_stats jsonb;
    performance_stats jsonb;
BEGIN
    -- Get block completion statistics
    SELECT jsonb_build_object(
        'total_blocks', COALESCE(COUNT(*), 0),
        'completed_blocks', COALESCE(COUNT(*) FILTER (WHERE completion_status IN ('completed', 'mastered')), 0),
        'mastered_blocks', COALESCE(COUNT(*) FILTER (WHERE completion_status = 'mastered'), 0),
        'avg_completion_percentage', COALESCE(AVG(completion_percentage), 0),
        'avg_mastery_score', COALESCE(AVG(mastery_score), 0),
        'avg_time_per_block', COALESCE(AVG(total_time_spent_seconds), 0),
        'avg_engagement_score', COALESCE(AVG(content_engagement_score), 0)
    ) INTO block_stats
    FROM block_completions
    WHERE user_id = p_user_id 
    AND client_id = p_client_id
    AND created_at >= p_start_date 
    AND created_at <= p_end_date;
    
    -- Get learning session statistics
    SELECT jsonb_build_object(
        'session_count', COALESCE(COUNT(*), 0),
        'total_duration', COALESCE(SUM(total_duration_seconds), 0),
        'active_duration', COALESCE(SUM(active_duration_seconds), 0),
        'avg_focus_score', COALESCE(AVG(focus_score), 0),
        'avg_engagement_score', COALESCE(AVG(engagement_score), 0),
        'avg_learning_velocity', COALESCE(AVG(learning_velocity), 0),
        'avg_attention_span', COALESCE(AVG(attention_span_minutes), 0),
        'total_breaks', COALESCE(SUM(break_count), 0)
    ) INTO session_stats
    FROM learning_sessions
    WHERE user_id = p_user_id 
    AND client_id = p_client_id
    AND started_at >= p_start_date 
    AND started_at <= p_end_date;
    
    -- Get performance history statistics
    SELECT jsonb_build_object(
        'avg_score', COALESCE(AVG(score), 0),
        'performance_improvements', COALESCE(COUNT(*) FILTER (WHERE is_improvement = true), 0),
        'avg_completion_time', COALESCE(AVG(EXTRACT(EPOCH FROM completion_time)), 0),
        'performance_consistency', COALESCE(1.0 - (STDDEV(score) / NULLIF(AVG(score), 0)), 0)
    ) INTO performance_stats
    FROM performance_history
    WHERE user_id = p_user_id 
    AND client_id = p_client_id
    AND completed_at >= p_start_date 
    AND completed_at <= p_end_date;
    
    -- Combine all statistics
    result := jsonb_build_object(
        'block_stats', block_stats,
        'session_stats', session_stats,
        'performance_stats', performance_stats,
        'computed_at', NOW()
    );
    
    RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;