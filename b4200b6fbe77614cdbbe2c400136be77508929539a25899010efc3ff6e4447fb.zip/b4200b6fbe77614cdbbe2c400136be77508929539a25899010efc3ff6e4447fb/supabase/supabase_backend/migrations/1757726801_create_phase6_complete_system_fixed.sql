-- Migration: create_phase6_complete_system_fixed
-- Created at: 1757726801

-- Phase 6: Complete Learning Journey Orchestration System
-- Add missing fields to existing missions table
ALTER TABLE missions ADD COLUMN IF NOT EXISTS client_id uuid;
ALTER TABLE missions ADD COLUMN IF NOT EXISTS wod_sequence jsonb DEFAULT '[]';
ALTER TABLE missions ADD COLUMN IF NOT EXISTS prerequisites jsonb DEFAULT '[]';
ALTER TABLE missions ADD COLUMN IF NOT EXISTS completion_criteria jsonb DEFAULT '{}';
ALTER TABLE missions ADD COLUMN IF NOT EXISTS is_published boolean DEFAULT false;

-- Add missing fields to existing courses table  
ALTER TABLE courses ADD COLUMN IF NOT EXISTS client_id uuid;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS mission_sequence jsonb DEFAULT '[]';
ALTER TABLE courses ADD COLUMN IF NOT EXISTS instructor_id uuid;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS enrollment_capacity integer;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS start_date date;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS end_date date;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS enrollment_deadline date;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS is_published boolean DEFAULT false;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS price decimal(10,2) DEFAULT 0;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS certificate_template text;

-- Create course_enrollments table
CREATE TABLE IF NOT EXISTS course_enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL,
  user_id uuid NOT NULL,
  client_id uuid NOT NULL,
  enrolled_at timestamptz DEFAULT now(),
  status varchar(20) DEFAULT 'active' CHECK (status IN ('active', 'completed', 'dropped', 'suspended')),
  completion_percentage decimal(5,2) DEFAULT 0,
  completed_at timestamptz,
  certificate_issued_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(course_id, user_id)
);

-- Enhance user_progress table with missing fields
ALTER TABLE user_progress ADD COLUMN IF NOT EXISTS client_id uuid;
ALTER TABLE user_progress ADD COLUMN IF NOT EXISTS wod_id uuid;
ALTER TABLE user_progress ADD COLUMN IF NOT EXISTS status varchar(20) DEFAULT 'not_started';
ALTER TABLE user_progress ADD COLUMN IF NOT EXISTS started_at timestamptz;
ALTER TABLE user_progress ADD COLUMN IF NOT EXISTS completed_at timestamptz;
ALTER TABLE user_progress ADD COLUMN IF NOT EXISTS time_spent interval DEFAULT '0 seconds';
ALTER TABLE user_progress ADD COLUMN IF NOT EXISTS score decimal(5,2);
ALTER TABLE user_progress ADD COLUMN IF NOT EXISTS notes text;;