-- Migration: fix_rls_policies
-- Created at: 1756101588

-- Drop the problematic policies and recreate them with proper admin handling

-- Fix users table policies
DROP POLICY IF EXISTS "Users can only access their own client data" ON users;
DROP POLICY IF EXISTS "Admins can manage all users" ON users;

-- Create improved policies that handle admin users properly
CREATE POLICY "Users access own client data" 
ON users
FOR ALL
USING (
    -- First check if user is an admin
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid()) 
    OR 
    -- Otherwise, user must be accessing their own client data
    (auth.uid() IN (SELECT id FROM users) AND client_id = (SELECT client_id FROM users WHERE id = auth.uid()))
);

-- Fix user_tags table policies  
DROP POLICY IF EXISTS "User tags scoped to client" ON user_tags;
DROP POLICY IF EXISTS "Admins can manage all user tags" ON user_tags;

CREATE POLICY "User tags access control" 
ON user_tags
FOR ALL
USING (
    -- First check if user is an admin
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid()) 
    OR 
    -- Otherwise, user must be accessing tags from their own client
    (auth.uid() IN (SELECT id FROM users) AND client_id = (SELECT client_id FROM users WHERE id = auth.uid()))
);

-- Fix user_tag_assignments table policies
DROP POLICY IF EXISTS "User tag assignments scoped to client" ON user_tag_assignments;
DROP POLICY IF EXISTS "Admins can manage all user tag assignments" ON user_tag_assignments;

CREATE POLICY "User tag assignments access control" 
ON user_tag_assignments
FOR ALL
USING (
    -- First check if user is an admin
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid()) 
    OR 
    -- Otherwise, user must be accessing assignments from their own client
    (auth.uid() IN (SELECT id FROM users) AND 
     user_id IN (
        SELECT id FROM users 
        WHERE client_id = (SELECT client_id FROM users WHERE id = auth.uid())
     ))
);

-- Ensure client_api_assignments policy is also fixed
DROP POLICY IF EXISTS "Client API assignments scoped to client" ON client_api_assignments;
DROP POLICY IF EXISTS "Admins can manage client API assignments" ON client_api_assignments;

CREATE POLICY "Client API assignments access control" 
ON client_api_assignments
FOR ALL
USING (
    -- First check if user is an admin
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid()) 
    OR 
    -- Otherwise, user must be accessing assignments from their own client
    (auth.uid() IN (SELECT id FROM users) AND client_id = (SELECT client_id FROM users WHERE id = auth.uid()))
);;