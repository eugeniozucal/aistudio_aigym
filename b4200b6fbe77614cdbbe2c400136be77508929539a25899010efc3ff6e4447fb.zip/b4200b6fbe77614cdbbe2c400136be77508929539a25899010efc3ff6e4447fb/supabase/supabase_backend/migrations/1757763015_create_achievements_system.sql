-- Migration: create_achievements_system
-- Created at: 1757763015

-- Migration: create_achievements_system
-- Created at: 1757762000

-- Create achievements table for badge definitions and criteria
CREATE TABLE IF NOT EXISTS achievements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Basic information
    title TEXT NOT NULL,
    description TEXT,
    icon_url TEXT,
    badge_color TEXT DEFAULT '#3B82F6',
    
    -- Achievement classification
    achievement_type TEXT NOT NULL CHECK (achievement_type IN ('completion', 'streak', 'mastery', 'participation', 'social', 'special')),
    category TEXT NOT NULL CHECK (category IN ('wod', 'course', 'program', 'community', 'general')),
    difficulty_level TEXT DEFAULT 'bronze' CHECK (difficulty_level IN ('bronze', 'silver', 'gold', 'platinum', 'diamond')),
    
    -- Point system
    point_value INTEGER DEFAULT 0,
    
    -- Achievement criteria (JSON structure)
    criteria JSONB DEFAULT '{}' NOT NULL,
    unlock_criteria JSONB DEFAULT '{}',
    
    -- Status and settings
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'hidden')),
    is_hidden BOOLEAN DEFAULT false,
    is_rare BOOLEAN DEFAULT false,
    max_awards INTEGER, -- null means unlimited
    
    -- Ordering and display
    sort_order INTEGER DEFAULT 0,
    display_priority INTEGER DEFAULT 0,
    
    -- Multi-tenancy
    client_id UUID,
    
    -- Metadata
    created_by UUID,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    
    -- Indexes for performance
    CONSTRAINT achievements_point_value_valid CHECK (point_value >= 0)
);

-- Create user_achievements table for tracking earned achievements
CREATE TABLE IF NOT EXISTS user_achievements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Core relationship
    user_id UUID NOT NULL,
    achievement_id UUID NOT NULL REFERENCES achievements(id) ON DELETE CASCADE,
    
    -- Achievement context
    context_type TEXT CHECK (context_type IN ('wod', 'course', 'program', 'milestone', 'manual')),
    context_id UUID, -- ID of the WOD/Course/Program that triggered this
    context_data JSONB DEFAULT '{}',
    
    -- Progress tracking
    progress_data JSONB DEFAULT '{}',
    current_progress NUMERIC DEFAULT 0,
    required_progress NUMERIC DEFAULT 1,
    is_completed BOOLEAN DEFAULT false,
    
    -- Achievement details
    earned_at TIMESTAMPTZ,
    awarded_by UUID, -- for manual awards
    award_reason TEXT,
    
    -- Sharing and visibility
    is_public BOOLEAN DEFAULT true,
    is_featured BOOLEAN DEFAULT false,
    shared_at TIMESTAMPTZ,
    
    -- Multi-tenancy
    client_id UUID NOT NULL,
    
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    
    -- Constraints
    UNIQUE(user_id, achievement_id, context_type, context_id),
    CONSTRAINT user_achievements_progress_valid CHECK (current_progress >= 0 AND required_progress > 0)
);

-- Create course_milestones table for structured progression validation
CREATE TABLE IF NOT EXISTS course_milestones (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Course relationship
    course_id UUID NOT NULL,
    
    -- Milestone definition
    title TEXT NOT NULL,
    description TEXT,
    milestone_type TEXT NOT NULL CHECK (milestone_type IN ('knowledge_check', 'skill_demonstration', 'completion', 'assessment', 'project')),
    
    -- Position and ordering
    sequence_order INTEGER NOT NULL DEFAULT 0,
    estimated_duration_minutes INTEGER,
    
    -- Validation criteria
    validation_criteria JSONB DEFAULT '{}' NOT NULL,
    auto_validation BOOLEAN DEFAULT false,
    required_score NUMERIC,
    
    -- Prerequisites and dependencies
    prerequisite_milestones JSONB DEFAULT '[]', -- array of milestone IDs
    unlock_criteria JSONB DEFAULT '{}',
    
    -- Content and resources
    content_blocks JSONB DEFAULT '[]',
    resource_links JSONB DEFAULT '[]',
    
    -- Status and settings
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'draft')),
    is_required BOOLEAN DEFAULT true,
    is_locked BOOLEAN DEFAULT false,
    
    -- Achievement integration
    completion_achievement_id UUID REFERENCES achievements(id),
    point_value INTEGER DEFAULT 0,
    
    -- Multi-tenancy
    client_id UUID,
    
    -- Metadata
    created_by UUID,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    
    -- Constraints
    CONSTRAINT course_milestones_sequence_valid CHECK (sequence_order >= 0),
    CONSTRAINT course_milestones_score_valid CHECK (required_score IS NULL OR (required_score >= 0 AND required_score <= 100))
);

-- Create program_milestones table for program-level progression
CREATE TABLE IF NOT EXISTS program_milestones (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Program relationship
    program_id UUID NOT NULL,
    
    -- Milestone definition
    title TEXT NOT NULL,
    description TEXT,
    milestone_type TEXT NOT NULL CHECK (milestone_type IN ('course_completion', 'skill_mastery', 'certification', 'capstone', 'assessment')),
    
    -- Position and ordering
    sequence_order INTEGER NOT NULL DEFAULT 0,
    estimated_duration_hours INTEGER,
    
    -- Cross-course requirements
    required_courses JSONB DEFAULT '[]', -- array of course IDs that must be completed
    required_course_milestones JSONB DEFAULT '[]', -- specific course milestones required
    
    -- Validation criteria
    validation_criteria JSONB DEFAULT '{}' NOT NULL,
    auto_validation BOOLEAN DEFAULT true,
    minimum_completion_percentage NUMERIC DEFAULT 100,
    required_average_score NUMERIC,
    
    -- Prerequisites and dependencies
    prerequisite_milestones JSONB DEFAULT '[]',
    dependency_chains JSONB DEFAULT '[]',
    
    -- Certification and credentials
    certificate_template TEXT,
    credential_type TEXT,
    certification_requirements JSONB DEFAULT '{}',
    
    -- Status and settings
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'draft')),
    is_required BOOLEAN DEFAULT true,
    is_final_milestone BOOLEAN DEFAULT false,
    
    -- Achievement integration
    completion_achievement_id UUID REFERENCES achievements(id),
    point_value INTEGER DEFAULT 0,
    
    -- Multi-tenancy
    client_id UUID,
    
    -- Metadata
    created_by UUID,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    
    -- Constraints
    CONSTRAINT program_milestones_sequence_valid CHECK (sequence_order >= 0),
    CONSTRAINT program_milestones_completion_valid CHECK (minimum_completion_percentage >= 0 AND minimum_completion_percentage <= 100)
);

-- Create user_milestone_progress table for tracking milestone completion
CREATE TABLE IF NOT EXISTS user_milestone_progress (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Core relationships
    user_id UUID NOT NULL,
    milestone_id UUID NOT NULL,
    milestone_type TEXT NOT NULL CHECK (milestone_type IN ('course', 'program')),
    
    -- Progress tracking
    status TEXT DEFAULT 'not_started' CHECK (status IN ('not_started', 'in_progress', 'completed', 'validated', 'failed')),
    progress_percentage NUMERIC DEFAULT 0,
    current_score NUMERIC,
    
    -- Validation data
    validation_data JSONB DEFAULT '{}',
    validation_method TEXT,
    validated_by UUID,
    validated_at TIMESTAMPTZ,
    
    -- Attempt tracking
    attempts_count INTEGER DEFAULT 0,
    max_attempts INTEGER,
    
    -- Timing
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    time_spent INTERVAL DEFAULT '0 minutes',
    
    -- Feedback and notes
    feedback TEXT,
    notes TEXT,
    
    -- Multi-tenancy
    client_id UUID NOT NULL,
    
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    
    -- Constraints
    UNIQUE(user_id, milestone_id, milestone_type),
    CONSTRAINT user_milestone_progress_valid CHECK (progress_percentage >= 0 AND progress_percentage <= 100)
);

-- Create indexes for performance optimization
CREATE INDEX IF NOT EXISTS achievements_type_category_idx ON achievements(achievement_type, category);
CREATE INDEX IF NOT EXISTS achievements_client_status_idx ON achievements(client_id, status);
CREATE INDEX IF NOT EXISTS achievements_difficulty_points_idx ON achievements(difficulty_level, point_value);

CREATE INDEX IF NOT EXISTS user_achievements_user_id_idx ON user_achievements(user_id);
CREATE INDEX IF NOT EXISTS user_achievements_achievement_id_idx ON user_achievements(achievement_id);
CREATE INDEX IF NOT EXISTS user_achievements_client_context_idx ON user_achievements(client_id, context_type, context_id);
CREATE INDEX IF NOT EXISTS user_achievements_earned_at_idx ON user_achievements(earned_at);
CREATE INDEX IF NOT EXISTS user_achievements_completed_idx ON user_achievements(is_completed, earned_at);

CREATE INDEX IF NOT EXISTS course_milestones_course_id_idx ON course_milestones(course_id);
CREATE INDEX IF NOT EXISTS course_milestones_sequence_idx ON course_milestones(course_id, sequence_order);
CREATE INDEX IF NOT EXISTS course_milestones_status_idx ON course_milestones(status, is_required);

CREATE INDEX IF NOT EXISTS program_milestones_program_id_idx ON program_milestones(program_id);
CREATE INDEX IF NOT EXISTS program_milestones_sequence_idx ON program_milestones(program_id, sequence_order);
CREATE INDEX IF NOT EXISTS program_milestones_status_idx ON program_milestones(status, is_required);

CREATE INDEX IF NOT EXISTS user_milestone_progress_user_id_idx ON user_milestone_progress(user_id);
CREATE INDEX IF NOT EXISTS user_milestone_progress_milestone_idx ON user_milestone_progress(milestone_id, milestone_type);
CREATE INDEX IF NOT EXISTS user_milestone_progress_status_idx ON user_milestone_progress(status, completed_at);
CREATE INDEX IF NOT EXISTS user_milestone_progress_client_idx ON user_milestone_progress(client_id, user_id);

-- Create triggers for updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_achievements_updated_at BEFORE UPDATE ON achievements FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_user_achievements_updated_at BEFORE UPDATE ON user_achievements FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_course_milestones_updated_at BEFORE UPDATE ON course_milestones FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_program_milestones_updated_at BEFORE UPDATE ON program_milestones FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_user_milestone_progress_updated_at BEFORE UPDATE ON user_milestone_progress FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();;