-- Migration: create_phase6_complete_system
-- Created at: 1757726781

-- Phase 6: Complete Learning Journey Orchestration System
-- Add missing fields to existing missions table
ALTER TABLE missions ADD COLUMN IF NOT EXISTS client_id uuid REFERENCES clients(id);
ALTER TABLE missions ADD COLUMN IF NOT EXISTS wod_sequence jsonb DEFAULT '[]';
ALTER TABLE missions ADD COLUMN IF NOT EXISTS prerequisites jsonb DEFAULT '[]';
ALTER TABLE missions ADD COLUMN IF NOT EXISTS completion_criteria jsonb DEFAULT '{}';
ALTER TABLE missions ADD COLUMN IF NOT EXISTS is_published boolean DEFAULT false;

-- Add missing fields to existing courses table  
ALTER TABLE courses ADD COLUMN IF NOT EXISTS client_id uuid REFERENCES clients(id);
ALTER TABLE courses ADD COLUMN IF NOT EXISTS mission_sequence jsonb DEFAULT '[]';
ALTER TABLE courses ADD COLUMN IF NOT EXISTS instructor_id uuid REFERENCES auth.users(id);
ALTER TABLE courses ADD COLUMN IF NOT EXISTS enrollment_capacity integer;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS start_date date;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS end_date date;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS enrollment_deadline date;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS is_published boolean DEFAULT false;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS price decimal(10,2) DEFAULT 0;
ALTER TABLE courses ADD COLUMN IF NOT EXISTS certificate_template text;

-- Create course_enrollments table
CREATE TABLE IF NOT EXISTS course_enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  client_id uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  enrolled_at timestamptz DEFAULT now(),
  status varchar(20) DEFAULT 'active' CHECK (status IN ('active', 'completed', 'dropped', 'suspended')),
  completion_percentage decimal(5,2) DEFAULT 0,
  completed_at timestamptz,
  certificate_issued_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(course_id, user_id)
);

-- Enhance user_progress table with missing fields
ALTER TABLE user_progress ADD COLUMN IF NOT EXISTS client_id uuid REFERENCES clients(id);
ALTER TABLE user_progress ADD COLUMN IF NOT EXISTS wod_id uuid;
ALTER TABLE user_progress ADD COLUMN IF NOT EXISTS status varchar(20) DEFAULT 'not_started' CHECK (status IN ('not_started', 'in_progress', 'completed', 'skipped'));
ALTER TABLE user_progress ADD COLUMN IF NOT EXISTS started_at timestamptz;
ALTER TABLE user_progress ADD COLUMN IF NOT EXISTS completed_at timestamptz;
ALTER TABLE user_progress ADD COLUMN IF NOT EXISTS time_spent interval DEFAULT '0 seconds';
ALTER TABLE user_progress ADD COLUMN IF NOT EXISTS score decimal(5,2);
ALTER TABLE user_progress ADD COLUMN IF NOT EXISTS notes text;

-- Create comprehensive indexes for performance
CREATE INDEX IF NOT EXISTS idx_missions_client_id ON missions(client_id);
CREATE INDEX IF NOT EXISTS idx_missions_created_by ON missions(created_by);
CREATE INDEX IF NOT EXISTS idx_missions_published ON missions(is_published) WHERE is_published = true;

CREATE INDEX IF NOT EXISTS idx_courses_client_id ON courses(client_id);
CREATE INDEX IF NOT EXISTS idx_courses_instructor ON courses(instructor_id);
CREATE INDEX IF NOT EXISTS idx_courses_published ON courses(is_published) WHERE is_published = true;

CREATE INDEX IF NOT EXISTS idx_enrollments_course_user ON course_enrollments(course_id, user_id);
CREATE INDEX IF NOT EXISTS idx_enrollments_user_status ON course_enrollments(user_id, status);
CREATE INDEX IF NOT EXISTS idx_enrollments_client ON course_enrollments(client_id);

CREATE INDEX IF NOT EXISTS idx_progress_user_course ON user_progress(user_id, course_id);
CREATE INDEX IF NOT EXISTS idx_progress_user_mission ON user_progress(user_id, mission_id);
CREATE INDEX IF NOT EXISTS idx_progress_user_wod ON user_progress(user_id, wod_id);
CREATE INDEX IF NOT EXISTS idx_progress_status ON user_progress(status);
CREATE INDEX IF NOT EXISTS idx_progress_client ON user_progress(client_id);

-- Enable Row Level Security
ALTER TABLE course_enrollments ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for course_enrollments
CREATE POLICY IF NOT EXISTS "course_enrollments_client_isolation" ON course_enrollments 
FOR ALL USING (client_id IN (
  SELECT id FROM clients WHERE id IN (
    SELECT unnest(string_to_array(current_setting('app.current_client_id', true), ','))::uuid
  )
));

-- Update existing RLS policies to include client_id filtering for enhanced tables
DROP POLICY IF EXISTS "missions_access_policy" ON missions;
CREATE POLICY "missions_client_isolation" ON missions 
FOR ALL USING (client_id IN (
  SELECT id FROM clients WHERE id IN (
    SELECT unnest(string_to_array(current_setting('app.current_client_id', true), ','))::uuid
  )
));

DROP POLICY IF EXISTS "courses_access_policy" ON courses;
CREATE POLICY "courses_client_isolation" ON courses 
FOR ALL USING (client_id IN (
  SELECT id FROM clients WHERE id IN (
    SELECT unnest(string_to_array(current_setting('app.current_client_id', true), ','))::uuid
  )
));

DROP POLICY IF EXISTS "user_progress_access_policy" ON user_progress;
CREATE POLICY "user_progress_client_isolation" ON user_progress 
FOR ALL USING (client_id IN (
  SELECT id FROM clients WHERE id IN (
    SELECT unnest(string_to_array(current_setting('app.current_client_id', true), ','))::uuid
  )
));;