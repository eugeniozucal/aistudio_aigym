-- Migration: create_program_course_assignments_table
-- Created at: 1757761907

-- Create junction table for program-course relationships
CREATE TABLE IF NOT EXISTS program_course_assignments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Core relationship
    program_id UUID NOT NULL REFERENCES programs(id) ON DELETE CASCADE,
    course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    
    -- Sequencing and structure
    order_index INTEGER NOT NULL DEFAULT 0, -- position in program sequence
    is_required BOOLEAN DEFAULT true, -- required vs optional course
    is_prerequisite_for JSONB DEFAULT '[]'::jsonb, -- course IDs that require this course
    
    -- Course-specific program settings
    estimated_duration_override INTEGER, -- override course duration for this program
    difficulty_override TEXT, -- override difficulty level for this program context
    custom_instructions TEXT, -- program-specific instructions for this course
    
    -- Completion requirements
    completion_criteria JSONB DEFAULT '{}'::jsonb, -- specific completion criteria for this course in this program
    minimum_score NUMERIC, -- minimum score required (if applicable)
    required_activities JSONB DEFAULT '[]'::jsonb, -- specific activities that must be completed
    
    -- Access control
    unlock_conditions JSONB DEFAULT '{}'::jsonb, -- conditions to unlock this course
    is_locked BOOLEAN DEFAULT false, -- whether course is initially locked
    
    -- Administrative
    assigned_at TIMESTAMPTZ DEFAULT now(),
    assigned_by UUID NOT NULL,
    
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    
    -- Unique constraint - each course can only be in a program once
    UNIQUE(program_id, course_id),
    
    -- Check constraints
    CONSTRAINT program_course_order_valid CHECK (order_index >= 0),
    CONSTRAINT program_course_score_valid CHECK (minimum_score IS NULL OR (minimum_score >= 0 AND minimum_score <= 100))
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS program_course_assignments_program_id_idx ON program_course_assignments(program_id);
CREATE INDEX IF NOT EXISTS program_course_assignments_course_id_idx ON program_course_assignments(course_id);
CREATE INDEX IF NOT EXISTS program_course_assignments_order_idx ON program_course_assignments(program_id, order_index);
CREATE INDEX IF NOT EXISTS program_course_assignments_required_idx ON program_course_assignments(program_id, is_required);

-- Create trigger to automatically update programs.course_sequence when assignments change
CREATE OR REPLACE FUNCTION update_program_course_sequence()
RETURNS TRIGGER AS $$
BEGIN
    -- Update the course_sequence in programs table
    UPDATE programs 
    SET course_sequence = (
        SELECT jsonb_agg(course_id ORDER BY order_index)
        FROM program_course_assignments 
        WHERE program_id = COALESCE(NEW.program_id, OLD.program_id)
    ),
    updated_at = now()
    WHERE id = COALESCE(NEW.program_id, OLD.program_id);
    
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

-- Create triggers for INSERT, UPDATE, DELETE on program_course_assignments
CREATE TRIGGER update_program_course_sequence_insert
    AFTER INSERT ON program_course_assignments
    FOR EACH ROW EXECUTE FUNCTION update_program_course_sequence();

CREATE TRIGGER update_program_course_sequence_update
    AFTER UPDATE ON program_course_assignments
    FOR EACH ROW EXECUTE FUNCTION update_program_course_sequence();

CREATE TRIGGER update_program_course_sequence_delete
    AFTER DELETE ON program_course_assignments
    FOR EACH ROW EXECUTE FUNCTION update_program_course_sequence();;