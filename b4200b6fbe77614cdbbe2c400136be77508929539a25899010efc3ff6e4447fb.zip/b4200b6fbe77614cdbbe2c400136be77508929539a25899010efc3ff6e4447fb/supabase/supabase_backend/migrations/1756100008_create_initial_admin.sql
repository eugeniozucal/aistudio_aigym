-- Migration: create_initial_admin
-- Created at: 1756100008

-- Create the initial admin account
INSERT INTO admins (email, password_hash, role) 
VALUES ('ez@aiworkify.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'super_admin')
ON CONFLICT (email) DO NOTHING;

-- Create some sample clients for testing
INSERT INTO clients (name, project_name, color_hex, has_forum) VALUES 
('TechCorp Solutions', 'AI Training Initiative', '#1E40AF', true),
('Global Enterprises', 'Executive AI Program', '#7C2D12', false),
('StartUp Accelerator', 'Founder AI Bootcamp', '#166534', true)
ON CONFLICT DO NOTHING;;