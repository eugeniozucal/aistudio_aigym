-- Migration: 08_mission_to_wod_update_rls_policies
-- Created at: 1757757799

-- Step 8: Update RLS policies for new table names

BEGIN;

-- Update RLS policies for wods table (formerly missions)
DROP POLICY IF EXISTS "Admin users can manage all missions" ON wods;
DROP POLICY IF EXISTS "Admins can manage missions" ON wods;

CREATE POLICY "Admin users can manage all wods" ON wods
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM admins 
            WHERE admins.id = auth.uid()
        )
    )
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM admins 
            WHERE admins.id = auth.uid()
        )
    );

CREATE POLICY "Admins can manage wods" ON wods 
    FOR ALL USING (auth.role() = 'authenticated'::text);

-- Update RLS policies for assignment tables
DROP POLICY IF EXISTS "Admins can manage mission client assignments" ON wod_client_assignments;
CREATE POLICY "Admins can manage wod client assignments" ON wod_client_assignments
    FOR ALL USING (auth.role() = 'authenticated'::text);

DROP POLICY IF EXISTS "Admins can manage mission tag assignments" ON wod_tag_assignments;
CREATE POLICY "Admins can manage wod tag assignments" ON wod_tag_assignments
    FOR ALL USING (auth.role() = 'authenticated'::text);

DROP POLICY IF EXISTS "Admins can manage mission user assignments" ON wod_user_assignments;
CREATE POLICY "Admins can manage wod user assignments" ON wod_user_assignments
    FOR ALL USING (auth.role() = 'authenticated'::text);

COMMIT;;