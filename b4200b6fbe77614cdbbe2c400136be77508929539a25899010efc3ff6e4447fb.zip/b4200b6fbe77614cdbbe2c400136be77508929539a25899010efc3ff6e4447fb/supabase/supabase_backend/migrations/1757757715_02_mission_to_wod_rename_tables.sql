-- Migration: 02_mission_to_wod_rename_tables
-- Created at: 1757757715

-- Step 2: Rename all mission tables to wod equivalents
-- This maintains all data while updating table names

BEGIN;

-- Rename main missions table to wods
ALTER TABLE missions RENAME TO wods;

-- Rename mission assignment tables to wod equivalents  
ALTER TABLE mission_client_assignments RENAME TO wod_client_assignments;
ALTER TABLE mission_tag_assignments RENAME TO wod_tag_assignments;
ALTER TABLE mission_user_assignments RENAME TO wod_user_assignments;

-- Update foreign key constraint names to reflect new table names
ALTER TABLE wods RENAME CONSTRAINT missions_category_id_fkey TO wods_category_id_fkey;
ALTER TABLE wods RENAME CONSTRAINT missions_difficulty_level_check TO wods_difficulty_level_check;
ALTER TABLE wods RENAME CONSTRAINT missions_status_check TO wods_status_check;

COMMIT;;