-- Migration: update_api_keys_structure
-- Created at: 1756104936

-- Add missing columns to api_keys table
ALTER TABLE public.api_keys 
ADD COLUMN IF NOT EXISTS key_type VARCHAR(50),
ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'active',
ADD COLUMN IF NOT EXISTS created_by UUID,
ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- Update key_type from provider column if needed
UPDATE public.api_keys 
SET key_type = provider 
WHERE key_type IS NULL;

-- Add missing columns to clients table
ALTER TABLE public.clients 
ADD COLUMN IF NOT EXISTS brand_color VARCHAR(7) DEFAULT '#3B82F6',
ADD COLUMN IF NOT EXISTS forum_enabled BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS is_template BOOLEAN DEFAULT false;

-- Update existing client data
UPDATE public.clients 
SET 
    brand_color = COALESCE(color_hex, '#3B82F6'),
    forum_enabled = COALESCE(has_forum, true)
WHERE brand_color IS NULL OR forum_enabled IS NULL;;