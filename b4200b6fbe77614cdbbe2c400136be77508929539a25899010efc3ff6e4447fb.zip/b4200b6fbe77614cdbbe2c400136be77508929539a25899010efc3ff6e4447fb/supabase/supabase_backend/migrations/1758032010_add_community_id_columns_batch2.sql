-- Migration: add_community_id_columns_batch2
-- Created at: 1758032010

-- Add community_id columns to more tables (batch 2)
ALTER TABLE achievements ADD COLUMN community_id UUID;
ALTER TABLE agent_conversations ADD COLUMN community_id UUID;
ALTER TABLE block_completions ADD COLUMN community_id UUID;
ALTER TABLE content_engagements ADD COLUMN community_id UUID;
ALTER TABLE course_enrollments ADD COLUMN community_id UUID;
ALTER TABLE course_milestones ADD COLUMN community_id UUID;
ALTER TABLE learning_analytics ADD COLUMN community_id UUID;
ALTER TABLE learning_sessions ADD COLUMN community_id UUID;

-- Copy data from client_id to community_id columns
UPDATE achievements SET community_id = client_id;
UPDATE agent_conversations SET community_id = client_id;
UPDATE block_completions SET community_id = client_id;
UPDATE content_engagements SET community_id = client_id;
UPDATE course_enrollments SET community_id = client_id;
UPDATE course_milestones SET community_id = client_id;
UPDATE learning_analytics SET community_id = client_id;
UPDATE learning_sessions SET community_id = client_id;;