-- Create folders table for organizing WODs and BLOCKS
CREATE TABLE IF NOT EXISTS folders (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    parent_folder_id UUID REFERENCES folders(id) ON DELETE CASCADE,
    repository_type VARCHAR(20) NOT NULL CHECK (repository_type IN ('wods', 'blocks')),
    color VARCHAR(7) DEFAULT '#6B7280', -- hex color for folder display
    created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add folder associations to existing tables
ALTER TABLE wods ADD COLUMN IF NOT EXISTS folder_id UUID REFERENCES folders(id) ON DELETE SET NULL;
ALTER TABLE workout_blocks ADD COLUMN IF NOT EXISTS folder_id UUID REFERENCES folders(id) ON DELETE SET NULL;

-- Add favorites functionality
ALTER TABLE wods ADD COLUMN IF NOT EXISTS is_favorited BOOLEAN DEFAULT FALSE;
ALTER TABLE workout_blocks ADD COLUMN IF NOT EXISTS is_favorited BOOLEAN DEFAULT FALSE;

-- Create folder hierarchy path materialized view for efficient queries
CREATE OR REPLACE VIEW folder_paths AS
WITH RECURSIVE folder_tree AS (
    -- Base case: root folders
    SELECT 
        id,
        name,
        parent_folder_id,
        repository_type,
        color,
        name as path,
        0 as depth,
        ARRAY[id] as path_ids
    FROM folders 
    WHERE parent_folder_id IS NULL
    
    UNION ALL
    
    -- Recursive case: child folders
    SELECT 
        f.id,
        f.name,
        f.parent_folder_id,
        f.repository_type,
        f.color,
        ft.path || ' / ' || f.name as path,
        ft.depth + 1,
        ft.path_ids || f.id
    FROM folders f
    INNER JOIN folder_tree ft ON f.parent_folder_id = ft.id
)
SELECT * FROM folder_tree;

-- Create updated_at trigger for folders
CREATE OR REPLACE FUNCTION update_folders_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_folders_updated_at
    BEFORE UPDATE ON folders
    FOR EACH ROW
    EXECUTE FUNCTION update_folders_updated_at_column();

-- Enable Row Level Security for folders
ALTER TABLE folders ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for folders
-- Policy for admins to have full access
CREATE POLICY "Admins can manage folders" ON folders
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM profiles 
            WHERE profiles.id = auth.uid() 
            AND profiles.role = 'admin'
        )
    );

-- Policy for authenticated users to read folders
CREATE POLICY "Users can view folders" ON folders
    FOR SELECT USING (
        auth.role() = 'authenticated'
    );

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_folders_repository_type ON folders(repository_type);
CREATE INDEX IF NOT EXISTS idx_folders_parent_folder_id ON folders(parent_folder_id);
CREATE INDEX IF NOT EXISTS idx_folders_created_by ON folders(created_by);
CREATE INDEX IF NOT EXISTS idx_wods_folder_id ON wods(folder_id);
CREATE INDEX IF NOT EXISTS idx_workout_blocks_folder_id ON workout_blocks(folder_id);
CREATE INDEX IF NOT EXISTS idx_wods_is_favorited ON wods(is_favorited);
CREATE INDEX IF NOT EXISTS idx_workout_blocks_is_favorited ON workout_blocks(is_favorited);

-- Add comments for documentation
COMMENT ON TABLE folders IS 'Hierarchical folder system for organizing WODs and BLOCKS content';
COMMENT ON COLUMN folders.repository_type IS 'Specifies whether folder is for wods or blocks repository';
COMMENT ON COLUMN folders.color IS 'Hex color code for folder display in UI';
COMMENT ON VIEW folder_paths IS 'Materialized view showing complete folder hierarchy paths for efficient navigation';