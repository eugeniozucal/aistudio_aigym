-- Migration: fix_admin_access_policies
-- Created at: 1756153712

-- Enable RLS on admins table
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;

-- Policy to allow authenticated users to read their own admin record
CREATE POLICY "Allow authenticated users to read own admin record"
ON admins
FOR SELECT
TO authenticated
USING (auth.uid() = id);

-- Policy to allow service role to manage all admin records
CREATE POLICY "Allow service role full access"
ON admins
FOR ALL
TO service_role
USING (true);;