-- Migration: phase2_admin_panel_tables
-- Created at: 1756103864

-- Phase 2: Admin Panel Core - Database Schema Enhancement

-- Enhanced clients table with additional Phase 2 fields
ALTER TABLE clients ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'active' CHECK (status IN ('active', 'archived'));
ALTER TABLE clients ADD COLUMN IF NOT EXISTS template_source_id UUID REFERENCES clients(id);
ALTER TABLE clients ADD COLUMN IF NOT EXISTS api_key_id UUID REFERENCES api_keys(id);

-- Client feature toggles
CREATE TABLE IF NOT EXISTS client_features (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    feature_name TEXT NOT NULL,
    enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(client_id, feature_name)
);

-- User activity tracking
CREATE TABLE IF NOT EXISTS user_activities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    activity_type TEXT NOT NULL,
    activity_data JSONB,
    content_item_id UUID REFERENCES content_items(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Content engagement tracking
CREATE TABLE IF NOT EXISTS content_engagements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_item_id UUID NOT NULL REFERENCES content_items(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    engagement_type TEXT NOT NULL,
    engagement_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(content_item_id, user_id, engagement_type)
);

-- Agent conversations and usage tracking
CREATE TABLE IF NOT EXISTS agent_conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id UUID NOT NULL REFERENCES content_items(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    conversation_data JSONB NOT NULL,
    message_count INTEGER DEFAULT 0,
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_message_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Bulk upload processing logs
CREATE TABLE IF NOT EXISTS bulk_uploads (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    upload_type TEXT NOT NULL,
    file_name TEXT NOT NULL,
    total_rows INTEGER NOT NULL,
    successful_rows INTEGER DEFAULT 0,
    failed_rows INTEGER DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'processing' CHECK (status IN ('processing', 'completed', 'failed')),
    error_report JSONB,
    created_by UUID NOT NULL REFERENCES admins(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE
);

-- Global platform settings
CREATE TABLE IF NOT EXISTS platform_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    setting_key TEXT NOT NULL UNIQUE,
    setting_value JSONB NOT NULL,
    setting_type TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create performance indexes
CREATE INDEX IF NOT EXISTS idx_user_activities_user_id ON user_activities(user_id);
CREATE INDEX IF NOT EXISTS idx_user_activities_client_id ON user_activities(client_id);
CREATE INDEX IF NOT EXISTS idx_user_activities_created_at ON user_activities(created_at);
CREATE INDEX IF NOT EXISTS idx_user_activities_type ON user_activities(activity_type);

CREATE INDEX IF NOT EXISTS idx_content_engagements_content_id ON content_engagements(content_item_id);
CREATE INDEX IF NOT EXISTS idx_content_engagements_user_id ON content_engagements(user_id);
CREATE INDEX IF NOT EXISTS idx_content_engagements_client_id ON content_engagements(client_id);
CREATE INDEX IF NOT EXISTS idx_content_engagements_type ON content_engagements(engagement_type);

CREATE INDEX IF NOT EXISTS idx_agent_conversations_agent_id ON agent_conversations(agent_id);
CREATE INDEX IF NOT EXISTS idx_agent_conversations_user_id ON agent_conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_agent_conversations_client_id ON agent_conversations(client_id);
CREATE INDEX IF NOT EXISTS idx_agent_conversations_started_at ON agent_conversations(started_at);

CREATE INDEX IF NOT EXISTS idx_bulk_uploads_client_id ON bulk_uploads(client_id);
CREATE INDEX IF NOT EXISTS idx_bulk_uploads_status ON bulk_uploads(status);
CREATE INDEX IF NOT EXISTS idx_bulk_uploads_created_at ON bulk_uploads(created_at);

-- Insert default platform settings
INSERT INTO platform_settings (setting_key, setting_value, setting_type, description) VALUES
('available_features', '["agents_marketplace", "courses", "missions", "forums", "documents", "prompts", "automations"]'::jsonb, 'array', 'List of all available platform features'),
('default_user_password_length', '12'::jsonb, 'number', 'Default length for auto-generated user passwords'),
('max_bulk_upload_rows', '1000'::jsonb, 'number', 'Maximum rows allowed in bulk uploads'),
('analytics_retention_days', '365'::jsonb, 'number', 'Number of days to retain analytics data')
ON CONFLICT (setting_key) DO NOTHING;

-- Insert default features for existing clients
INSERT INTO client_features (client_id, feature_name, enabled)
SELECT c.id, feature.name, true
FROM clients c
CROSS JOIN (
    VALUES 
    ('agents_marketplace'),
    ('courses'),
    ('missions'),
    ('forums'),
    ('documents'),
    ('prompts'),
    ('automations')
) AS feature(name)
ON CONFLICT (client_id, feature_name) DO NOTHING;;