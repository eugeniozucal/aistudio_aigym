-- Migration: add_community_foreign_key_constraints_batch2
-- Created at: 1758032073

-- Add foreign key constraints for community_id columns (batch 2)
-- Optional relationships (can be NULL)
ALTER TABLE courses 
  ADD CONSTRAINT courses_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE SET NULL;

ALTER TABLE wods 
  ADD CONSTRAINT wods_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE SET NULL;

ALTER TABLE programs 
  ADD CONSTRAINT programs_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE SET NULL;

ALTER TABLE achievements 
  ADD CONSTRAINT achievements_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE SET NULL;

-- Mandatory relationships  
ALTER TABLE agent_conversations 
  ALTER COLUMN community_id SET NOT NULL,
  ADD CONSTRAINT agent_conversations_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE CASCADE;

ALTER TABLE block_completions 
  ALTER COLUMN community_id SET NOT NULL,
  ADD CONSTRAINT block_completions_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE CASCADE;;