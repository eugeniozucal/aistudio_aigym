-- Migration: create_training_programs_table
-- Created at: 1758510337

-- Create training_programs table for hierarchical training programs
CREATE TABLE IF NOT EXISTS training_programs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
    difficulty_level VARCHAR(20) DEFAULT 'beginner' CHECK (difficulty_level IN ('beginner', 'intermediate', 'advanced')),
    estimated_duration_weeks INTEGER DEFAULT 8,
    program_type VARCHAR(30) DEFAULT 'strength' CHECK (program_type IN ('strength', 'cardio', 'weight-loss', 'muscle-gain', 'endurance', 'flexibility')),
    tags TEXT[],
    sections JSONB DEFAULT '[]'::jsonb,
    settings JSONB DEFAULT '{}'::jsonb,
    thumbnail_url TEXT,
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_training_programs_status ON training_programs(status);
CREATE INDEX IF NOT EXISTS idx_training_programs_difficulty ON training_programs(difficulty_level);
CREATE INDEX IF NOT EXISTS idx_training_programs_type ON training_programs(program_type);
CREATE INDEX IF NOT EXISTS idx_training_programs_created_by ON training_programs(created_by);
CREATE INDEX IF NOT EXISTS idx_training_programs_created_at ON training_programs(created_at);
CREATE INDEX IF NOT EXISTS idx_training_programs_updated_at ON training_programs(updated_at);

-- Create RLS policies
ALTER TABLE training_programs ENABLE ROW LEVEL SECURITY;

-- Policy for authenticated users to read published programs
CREATE POLICY "Users can view published training programs" ON training_programs
    FOR SELECT
    USING (status = 'published');

-- Policy for program creators to manage their own programs
CREATE POLICY "Users can manage their own training programs" ON training_programs
    FOR ALL
    USING (auth.uid() = created_by);

-- Policy for admins to manage all programs (using auth.email())
CREATE POLICY "Admins can manage all training programs" ON training_programs
    FOR ALL
    USING (
        EXISTS (
            SELECT 1 FROM admins 
            WHERE email = auth.email()
        )
    );

-- Update trigger for updated_at
CREATE OR REPLACE FUNCTION update_training_programs_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_training_programs_updated_at
    BEFORE UPDATE ON training_programs
    FOR EACH ROW
    EXECUTE FUNCTION update_training_programs_updated_at();;