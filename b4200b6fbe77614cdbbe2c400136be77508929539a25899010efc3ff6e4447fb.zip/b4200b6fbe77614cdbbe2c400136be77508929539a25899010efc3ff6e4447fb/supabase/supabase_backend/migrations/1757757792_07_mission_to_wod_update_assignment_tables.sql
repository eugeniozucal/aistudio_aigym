-- Migration: 07_mission_to_wod_update_assignment_tables
-- Created at: 1757757792

-- Step 7: Update assignment tables to use wod_id instead of mission_id

BEGIN;

-- Update wod_client_assignments table
ALTER TABLE wod_client_assignments RENAME COLUMN mission_id TO wod_id;

-- Update wod_tag_assignments table  
ALTER TABLE wod_tag_assignments RENAME COLUMN mission_id TO wod_id;

-- Update wod_user_assignments table
ALTER TABLE wod_user_assignments RENAME COLUMN mission_id TO wod_id;

-- Add foreign key constraints for the renamed columns
ALTER TABLE wod_client_assignments ADD CONSTRAINT wod_client_assignments_wod_id_fkey 
    FOREIGN KEY (wod_id) REFERENCES wods(id) ON DELETE CASCADE;

ALTER TABLE wod_tag_assignments ADD CONSTRAINT wod_tag_assignments_wod_id_fkey 
    FOREIGN KEY (wod_id) REFERENCES wods(id) ON DELETE CASCADE;

ALTER TABLE wod_user_assignments ADD CONSTRAINT wod_user_assignments_wod_id_fkey 
    FOREIGN KEY (wod_id) REFERENCES wods(id) ON DELETE CASCADE;

COMMIT;;