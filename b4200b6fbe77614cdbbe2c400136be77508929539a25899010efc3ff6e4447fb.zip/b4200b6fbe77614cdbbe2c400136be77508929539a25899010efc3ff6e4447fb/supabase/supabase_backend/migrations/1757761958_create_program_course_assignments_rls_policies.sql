-- Migration: create_program_course_assignments_rls_policies
-- Created at: 1757761958

-- Enable RLS on program_course_assignments table
ALTER TABLE program_course_assignments ENABLE ROW LEVEL SECURITY;

-- Program course assignments policies
CREATE POLICY program_course_assignments_select_policy ON program_course_assignments
    FOR SELECT USING (
        -- Users can see assignments for programs they can see
        EXISTS (
            SELECT 1 FROM programs p 
            WHERE p.id = program_id 
            AND (
                -- Public programs
                (p.status = 'published' AND p.access_level = 'public')
                OR
                -- Client-specific programs
                (p.client_id IS NOT NULL AND p.client_id IN (
                    SELECT client_id FROM users WHERE id = auth.uid()
                ))
                OR
                -- Programs visible to creators and instructors
                (p.created_by = auth.uid() OR auth.uid() = ANY(p.instructor_ids))
            )
        )
    );

CREATE POLICY program_course_assignments_insert_policy ON program_course_assignments
    FOR INSERT WITH CHECK (
        assigned_by = auth.uid()
        AND EXISTS (
            SELECT 1 FROM programs p 
            WHERE p.id = program_id 
            AND (
                p.created_by = auth.uid() 
                OR auth.uid() = ANY(p.instructor_ids)
            )
        )
    );

CREATE POLICY program_course_assignments_update_policy ON program_course_assignments
    FOR UPDATE USING (
        EXISTS (
            SELECT 1 FROM programs p 
            WHERE p.id = program_id 
            AND (
                p.created_by = auth.uid() 
                OR auth.uid() = ANY(p.instructor_ids)
            )
        )
    ) WITH CHECK (
        EXISTS (
            SELECT 1 FROM programs p 
            WHERE p.id = program_id 
            AND (
                p.created_by = auth.uid() 
                OR auth.uid() = ANY(p.instructor_ids)
            )
        )
    );

CREATE POLICY program_course_assignments_delete_policy ON program_course_assignments
    FOR DELETE USING (
        EXISTS (
            SELECT 1 FROM programs p 
            WHERE p.id = program_id 
            AND (
                p.created_by = auth.uid() 
                OR auth.uid() = ANY(p.instructor_ids)
            )
        )
    );;