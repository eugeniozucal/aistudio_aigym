-- Migration: create_programs_rls_policies
-- Created at: 1757761925

-- Enable RLS on programs table
ALTER TABLE programs ENABLE ROW LEVEL SECURITY;

-- Programs policies
CREATE POLICY programs_select_policy ON programs
    FOR SELECT USING (
        -- Public programs visible to all
        (status = 'published' AND access_level = 'public')
        OR
        -- Client-specific programs visible to client members
        (client_id IS NOT NULL AND client_id IN (
            SELECT client_id FROM users WHERE id = auth.uid()
        ))
        OR
        -- Programs visible to creators and instructors
        (created_by = auth.uid() OR auth.uid() = ANY(instructor_ids))
    );

CREATE POLICY programs_insert_policy ON programs
    FOR INSERT WITH CHECK (
        created_by = auth.uid()
        AND (
            client_id IS NULL 
            OR client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
        )
    );

CREATE POLICY programs_update_policy ON programs
    FOR UPDATE USING (
        created_by = auth.uid() 
        OR auth.uid() = ANY(instructor_ids)
        OR (
            client_id IS NOT NULL 
            AND client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
        )
    ) WITH CHECK (
        created_by = auth.uid() 
        OR auth.uid() = ANY(instructor_ids)
        OR (
            client_id IS NOT NULL 
            AND client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
        )
    );

CREATE POLICY programs_delete_policy ON programs
    FOR DELETE USING (
        created_by = auth.uid()
        OR (
            client_id IS NOT NULL 
            AND client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
        )
    );;