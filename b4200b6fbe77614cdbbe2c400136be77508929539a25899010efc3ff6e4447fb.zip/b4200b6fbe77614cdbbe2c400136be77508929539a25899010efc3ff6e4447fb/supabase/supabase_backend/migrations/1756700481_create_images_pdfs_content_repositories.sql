-- Migration: create_images_pdfs_content_repositories
-- Created at: 1756700481

-- Images Repository Table
CREATE TABLE IF NOT EXISTS content_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  image_url text NOT NULL,
  file_size bigint,
  mime_type text,
  alt_text text,
  width integer,
  height integer,
  status text DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- PDFs Repository Table  
CREATE TABLE IF NOT EXISTS content_pdfs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  pdf_url text NOT NULL,
  file_size bigint,
  page_count integer,
  status text DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE content_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_pdfs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for Images
CREATE POLICY "Enable read access for all users" ON content_images FOR SELECT USING (true);
CREATE POLICY "Enable insert for authenticated users only" ON content_images FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Enable update for owners only" ON content_images FOR UPDATE USING (auth.uid() = created_by);
CREATE POLICY "Enable delete for owners only" ON content_images FOR DELETE USING (auth.uid() = created_by);

-- RLS Policies for PDFs
CREATE POLICY "Enable read access for all users" ON content_pdfs FOR SELECT USING (true);
CREATE POLICY "Enable insert for authenticated users only" ON content_pdfs FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Enable update for owners only" ON content_pdfs FOR UPDATE USING (auth.uid() = created_by);
CREATE POLICY "Enable delete for owners only" ON content_pdfs FOR DELETE USING (auth.uid() = created_by);

-- Create indexes for performance
CREATE INDEX idx_content_images_status ON content_images(status);
CREATE INDEX idx_content_images_created_by ON content_images(created_by);
CREATE INDEX idx_content_images_created_at ON content_images(created_at DESC);

CREATE INDEX idx_content_pdfs_status ON content_pdfs(status);
CREATE INDEX idx_content_pdfs_created_by ON content_pdfs(created_by);
CREATE INDEX idx_content_pdfs_created_at ON content_pdfs(created_at DESC);;