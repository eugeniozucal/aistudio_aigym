-- Migration: create_streak_tracking_system
-- Created at: 1757763420

-- Migration: create_streak_tracking_system
-- Created at: 1757762300

-- Create user_streaks table for tracking various user streaks
CREATE TABLE IF NOT EXISTS user_streaks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Core relationship
    user_id UUID NOT NULL,
    client_id UUID NOT NULL,
    
    -- Streak type and identification
    streak_type TEXT NOT NULL CHECK (streak_type IN ('login', 'daily_wod', 'daily_course', 'weekly_activity', 'assessment')),
    
    -- Current streak data
    current_streak INTEGER DEFAULT 0,
    longest_streak INTEGER DEFAULT 0,
    
    -- Streak timing
    streak_start_date DATE,
    last_activity_date DATE,
    last_activity_timestamp TIMESTAMPTZ,
    
    -- Streak validation
    is_active BOOLEAN DEFAULT true,
    broken_date DATE,
    
    -- Streak metadata
    total_activities INTEGER DEFAULT 0,
    streak_data JSONB DEFAULT '{}', -- Additional streak-specific data
    
    -- Performance tracking for mastery
    performance_data JSONB DEFAULT '{}', -- Scores, times, etc.
    average_performance NUMERIC,
    best_performance NUMERIC,
    
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    
    -- Constraints
    UNIQUE(user_id, client_id, streak_type),
    CONSTRAINT user_streaks_valid CHECK (current_streak >= 0 AND longest_streak >= 0)
);

-- Create user_daily_activity table for detailed daily tracking
CREATE TABLE IF NOT EXISTS user_daily_activity (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Core relationship
    user_id UUID NOT NULL,
    client_id UUID NOT NULL,
    activity_date DATE NOT NULL,
    
    -- Activity tracking
    login_count INTEGER DEFAULT 0,
    wod_completions INTEGER DEFAULT 0,
    course_activities INTEGER DEFAULT 0,
    assessment_attempts INTEGER DEFAULT 0,
    milestone_completions INTEGER DEFAULT 0,
    
    -- Performance metrics
    total_time_spent INTERVAL DEFAULT '0 minutes',
    average_score NUMERIC,
    activities_completed INTEGER DEFAULT 0,
    
    -- Activity details
    activity_data JSONB DEFAULT '{}',
    performance_summary JSONB DEFAULT '{}',
    
    -- Session tracking
    first_login_at TIMESTAMPTZ,
    last_activity_at TIMESTAMPTZ,
    session_count INTEGER DEFAULT 0,
    
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    
    -- Constraints
    UNIQUE(user_id, client_id, activity_date)
);

-- Create performance_history table for mastery tracking
CREATE TABLE IF NOT EXISTS performance_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Core relationship
    user_id UUID NOT NULL,
    client_id UUID NOT NULL,
    
    -- Performance context
    activity_type TEXT NOT NULL CHECK (activity_type IN ('wod', 'course', 'assessment', 'milestone', 'quiz')),
    activity_id UUID NOT NULL,
    activity_name TEXT,
    
    -- Performance metrics
    score NUMERIC,
    completion_time INTERVAL,
    attempts_used INTEGER DEFAULT 1,
    max_possible_score NUMERIC,
    
    -- Performance classification
    performance_level TEXT CHECK (performance_level IN ('poor', 'below_average', 'average', 'above_average', 'excellent', 'perfect')),
    is_improvement BOOLEAN DEFAULT false,
    
    -- Context data
    difficulty_level TEXT,
    estimated_duration INTERVAL,
    actual_vs_estimated_ratio NUMERIC,
    
    -- Metadata
    performance_data JSONB DEFAULT '{}',
    feedback_data JSONB DEFAULT '{}',
    
    -- Timestamps
    completed_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now(),
    
    -- Indexes for performance
    CONSTRAINT performance_history_score_valid CHECK (score IS NULL OR score >= 0)
);

-- Create indexes for performance optimization
CREATE INDEX IF NOT EXISTS user_streaks_user_client_idx ON user_streaks(user_id, client_id);
CREATE INDEX IF NOT EXISTS user_streaks_type_active_idx ON user_streaks(streak_type, is_active);
CREATE INDEX IF NOT EXISTS user_streaks_current_streak_idx ON user_streaks(current_streak DESC);
CREATE INDEX IF NOT EXISTS user_streaks_last_activity_idx ON user_streaks(last_activity_date DESC);

CREATE INDEX IF NOT EXISTS user_daily_activity_user_date_idx ON user_daily_activity(user_id, activity_date DESC);
CREATE INDEX IF NOT EXISTS user_daily_activity_client_date_idx ON user_daily_activity(client_id, activity_date DESC);
CREATE INDEX IF NOT EXISTS user_daily_activity_date_idx ON user_daily_activity(activity_date DESC);

CREATE INDEX IF NOT EXISTS performance_history_user_activity_idx ON performance_history(user_id, activity_type, completed_at DESC);
CREATE INDEX IF NOT EXISTS performance_history_score_idx ON performance_history(score DESC, completed_at DESC);
CREATE INDEX IF NOT EXISTS performance_history_performance_level_idx ON performance_history(performance_level, completed_at DESC);
CREATE INDEX IF NOT EXISTS performance_history_activity_idx ON performance_history(activity_id, activity_type);

-- Create triggers for updated_at timestamps
CREATE TRIGGER update_user_streaks_updated_at BEFORE UPDATE ON user_streaks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_user_daily_activity_updated_at BEFORE UPDATE ON user_daily_activity FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Create function to update user streaks automatically
CREATE OR REPLACE FUNCTION update_user_streak(
    p_user_id UUID,
    p_client_id UUID,
    p_streak_type TEXT,
    p_activity_date DATE DEFAULT CURRENT_DATE,
    p_performance_score NUMERIC DEFAULT NULL
)
RETURNS JSONB AS $$
DECLARE
    v_streak_record user_streaks%ROWTYPE;
    v_previous_date DATE;
    v_is_consecutive BOOLEAN;
    v_result JSONB;
BEGIN
    -- Get existing streak record
    SELECT * INTO v_streak_record 
    FROM user_streaks 
    WHERE user_id = p_user_id 
    AND client_id = p_client_id 
    AND streak_type = p_streak_type;
    
    -- Calculate if this activity is consecutive
    IF v_streak_record.last_activity_date IS NOT NULL THEN
        v_previous_date := v_streak_record.last_activity_date;
        v_is_consecutive := (p_activity_date = v_previous_date + INTERVAL '1 day')::DATE = p_activity_date;
    ELSE
        v_is_consecutive := true;
    END IF;
    
    -- Update or create streak record
    INSERT INTO user_streaks (
        user_id, client_id, streak_type, current_streak, longest_streak,
        streak_start_date, last_activity_date, last_activity_timestamp,
        is_active, total_activities, average_performance, best_performance
    ) VALUES (
        p_user_id, p_client_id, p_streak_type, 
        CASE WHEN v_is_consecutive THEN 1 ELSE 1 END,
        1,
        p_activity_date, p_activity_date, now(),
        true, 1,
        p_performance_score, p_performance_score
    )
    ON CONFLICT (user_id, client_id, streak_type) DO UPDATE SET
        current_streak = CASE 
            WHEN v_is_consecutive THEN user_streaks.current_streak + 1
            ELSE 1
        END,
        longest_streak = GREATEST(
            user_streaks.longest_streak,
            CASE WHEN v_is_consecutive THEN user_streaks.current_streak + 1 ELSE 1 END
        ),
        streak_start_date = CASE 
            WHEN v_is_consecutive THEN user_streaks.streak_start_date
            ELSE p_activity_date
        END,
        last_activity_date = p_activity_date,
        last_activity_timestamp = now(),
        is_active = true,
        total_activities = user_streaks.total_activities + 1,
        average_performance = CASE 
            WHEN p_performance_score IS NOT NULL THEN 
                COALESCE(
                    (COALESCE(user_streaks.average_performance, 0) * (user_streaks.total_activities - 1) + p_performance_score) / user_streaks.total_activities,
                    p_performance_score
                )
            ELSE user_streaks.average_performance
        END,
        best_performance = CASE 
            WHEN p_performance_score IS NOT NULL THEN 
                GREATEST(COALESCE(user_streaks.best_performance, 0), p_performance_score)
            ELSE user_streaks.best_performance
        END,
        updated_at = now()
    RETURNING * INTO v_streak_record;
    
    -- Build result
    v_result := jsonb_build_object(
        'streak_type', v_streak_record.streak_type,
        'current_streak', v_streak_record.current_streak,
        'longest_streak', v_streak_record.longest_streak,
        'is_consecutive', v_is_consecutive,
        'total_activities', v_streak_record.total_activities,
        'average_performance', v_streak_record.average_performance,
        'best_performance', v_streak_record.best_performance
    );
    
    RETURN v_result;
END;
$$ LANGUAGE plpgsql;

-- Create function to update daily activity
CREATE OR REPLACE FUNCTION update_daily_activity(
    p_user_id UUID,
    p_client_id UUID,
    p_activity_type TEXT,
    p_score NUMERIC DEFAULT NULL,
    p_time_spent INTERVAL DEFAULT NULL,
    p_activity_date DATE DEFAULT CURRENT_DATE
)
RETURNS VOID AS $$
BEGIN
    INSERT INTO user_daily_activity (
        user_id, client_id, activity_date,
        login_count, wod_completions, course_activities, assessment_attempts, milestone_completions,
        total_time_spent, activities_completed, last_activity_at
    ) VALUES (
        p_user_id, p_client_id, p_activity_date,
        CASE WHEN p_activity_type = 'login' THEN 1 ELSE 0 END,
        CASE WHEN p_activity_type = 'wod' THEN 1 ELSE 0 END,
        CASE WHEN p_activity_type = 'course' THEN 1 ELSE 0 END,
        CASE WHEN p_activity_type = 'assessment' THEN 1 ELSE 0 END,
        CASE WHEN p_activity_type = 'milestone' THEN 1 ELSE 0 END,
        COALESCE(p_time_spent, '0 minutes'::INTERVAL),
        1, now()
    )
    ON CONFLICT (user_id, client_id, activity_date) DO UPDATE SET
        login_count = user_daily_activity.login_count + CASE WHEN p_activity_type = 'login' THEN 1 ELSE 0 END,
        wod_completions = user_daily_activity.wod_completions + CASE WHEN p_activity_type = 'wod' THEN 1 ELSE 0 END,
        course_activities = user_daily_activity.course_activities + CASE WHEN p_activity_type = 'course' THEN 1 ELSE 0 END,
        assessment_attempts = user_daily_activity.assessment_attempts + CASE WHEN p_activity_type = 'assessment' THEN 1 ELSE 0 END,
        milestone_completions = user_daily_activity.milestone_completions + CASE WHEN p_activity_type = 'milestone' THEN 1 ELSE 0 END,
        total_time_spent = user_daily_activity.total_time_spent + COALESCE(p_time_spent, '0 minutes'::INTERVAL),
        activities_completed = user_daily_activity.activities_completed + 1,
        average_score = CASE 
            WHEN p_score IS NOT NULL THEN 
                COALESCE(
                    (COALESCE(user_daily_activity.average_score, 0) * (user_daily_activity.activities_completed - 1) + p_score) / user_daily_activity.activities_completed,
                    p_score
                )
            ELSE user_daily_activity.average_score
        END,
        last_activity_at = now(),
        updated_at = now();
END;
$$ LANGUAGE plpgsql;;