-- Migration: add_wod_categories_support
-- Created at: 1756732560

-- Add WOD Categories Support
-- Migration to add category support for WODs (missions and courses)

-- Create WOD categories table
CREATE TABLE wod_categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    color TEXT DEFAULT '#3B82F6', -- Default blue color
    icon TEXT, -- Optional icon name
    order_index INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(name)
);

-- Add category fields to missions table
ALTER TABLE missions ADD COLUMN category_id UUID REFERENCES wod_categories(id) ON DELETE SET NULL;
ALTER TABLE missions ADD COLUMN workout_type TEXT; -- Strength, Cardio, HIIT, etc.
ALTER TABLE missions ADD COLUMN target_muscle_groups TEXT[]; -- Array of muscle groups
ALTER TABLE missions ADD COLUMN equipment_needed TEXT[]; -- Array of required equipment

-- Add category fields to courses table  
ALTER TABLE courses ADD COLUMN category_id UUID REFERENCES wod_categories(id) ON DELETE SET NULL;
ALTER TABLE courses ADD COLUMN workout_type TEXT;
ALTER TABLE courses ADD COLUMN target_muscle_groups TEXT[];
ALTER TABLE courses ADD COLUMN equipment_needed TEXT[];

-- Enable RLS on wod_categories
ALTER TABLE wod_categories ENABLE ROW LEVEL SECURITY;

-- RLS policy for wod_categories
CREATE POLICY "Authenticated users can manage wod_categories" ON wod_categories
    FOR ALL USING (auth.role() = 'authenticated');

-- Create indexes for performance
CREATE INDEX idx_missions_category_id ON missions(category_id);
CREATE INDEX idx_courses_category_id ON courses(category_id);
CREATE INDEX idx_wod_categories_active ON wod_categories(is_active, order_index);

-- Insert default WOD categories
INSERT INTO wod_categories (name, description, color, icon, order_index) VALUES
    ('Strength Training', 'Focus on building muscle strength and power', '#EF4444', 'Dumbbell', 1),
    ('Cardiovascular', 'Improve heart health and endurance', '#10B981', 'Heart', 2),
    ('HIIT', 'High-Intensity Interval Training', '#F59E0B', 'Timer', 3),
    ('Flexibility & Mobility', 'Improve range of motion and flexibility', '#8B5CF6', 'Stretch', 4),
    ('Functional Fitness', 'Real-world movement patterns', '#06B6D4', 'Activity', 5),
    ('Olympic Lifting', 'Technical barbell movements', '#DC2626', 'Weight', 6),
    ('Bodyweight', 'No equipment needed workouts', '#059669', 'User', 7),
    ('CrossFit Style', 'Varied functional movements', '#7C2D12', 'Target', 8);

-- Update timestamp trigger for wod_categories
CREATE TRIGGER set_wod_categories_timestamp
    BEFORE UPDATE ON wod_categories
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();

-- Grant necessary permissions
GRANT ALL ON wod_categories TO authenticated;
GRANT ALL ON wod_categories TO service_role;;