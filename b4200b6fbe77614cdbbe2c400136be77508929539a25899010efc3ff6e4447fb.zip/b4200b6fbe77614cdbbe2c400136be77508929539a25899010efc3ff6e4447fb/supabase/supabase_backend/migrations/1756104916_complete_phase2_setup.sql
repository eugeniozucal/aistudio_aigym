-- Migration: complete_phase2_setup
-- Created at: 1756104916

-- Create api_keys table if it doesn't exist
CREATE TABLE IF NOT EXISTS public.api_keys (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    key_type VARCHAR(50) NOT NULL DEFAULT 'openai',
    encrypted_key TEXT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    created_by UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add missing columns to clients table
ALTER TABLE public.clients 
ADD COLUMN IF NOT EXISTS brand_color VARCHAR(7) DEFAULT '#3B82F6',
ADD COLUMN IF NOT EXISTS forum_enabled BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS is_template BOOLEAN DEFAULT false;

-- Update existing data
UPDATE public.clients 
SET 
    brand_color = COALESCE(color_hex, '#3B82F6'),
    forum_enabled = COALESCE(has_forum, true)
WHERE brand_color IS NULL OR forum_enabled IS NULL;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_api_keys_status ON public.api_keys(status);
CREATE INDEX IF NOT EXISTS idx_clients_is_template ON public.clients(is_template);

-- Enable RLS on api_keys if not already enabled
ALTER TABLE public.api_keys ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist and recreate
DROP POLICY IF EXISTS "Admins can view all API keys" ON public.api_keys;
DROP POLICY IF EXISTS "Admins can manage API keys" ON public.api_keys;

CREATE POLICY "Admins can view all API keys" ON public.api_keys
    FOR SELECT USING (true);

CREATE POLICY "Admins can manage API keys" ON public.api_keys
    FOR ALL USING (true);

-- Insert sample API keys
INSERT INTO public.api_keys (name, key_type, encrypted_key, status) VALUES 
('OpenAI GPT-4', 'openai', 'sk-test-key-placeholder-1', 'active'),
('Anthropic Claude', 'anthropic', 'sk-ant-test-placeholder-2', 'active'),
('OpenAI GPT-3.5', 'openai', 'sk-test-key-placeholder-3', 'active')
ON CONFLICT DO NOTHING;;