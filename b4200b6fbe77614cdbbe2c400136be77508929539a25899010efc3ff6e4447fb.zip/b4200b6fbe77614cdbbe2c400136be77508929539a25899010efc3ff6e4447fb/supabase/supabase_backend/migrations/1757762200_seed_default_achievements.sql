-- Migration: seed_default_achievements
-- Created at: 1757762200

-- Insert default system-wide achievements
-- These will be available across all clients

-- WOD Completion Achievements
INSERT INTO achievements (title, description, icon_url, badge_color, achievement_type, category, difficulty_level, point_value, criteria) VALUES
('First Steps', 'Complete your first WOD', '/images/badges/first-steps.png', '#10B981', 'completion', 'wod', 'bronze', 10, '{"wod_completions": 1}'),
('WOD Warrior', 'Complete 10 WODs', '/images/badges/wod-warrior.png', '#3B82F6', 'completion', 'wod', 'silver', 50, '{"wod_completions": 10}'),
('WOD Master', 'Complete 50 WODs', '/images/badges/wod-master.png', '#8B5CF6', 'completion', 'wod', 'gold', 200, '{"wod_completions": 50}'),
('WOD Legend', 'Complete 100 WODs', '/images/badges/wod-legend.png', '#F59E0B', 'completion', 'wod', 'platinum', 500, '{"wod_completions": 100}');

-- Course Completion Achievements
INSERT INTO achievements (title, description, icon_url, badge_color, achievement_type, category, difficulty_level, point_value, criteria) VALUES
('Course Starter', 'Complete your first Course', '/images/badges/course-starter.png', '#10B981', 'completion', 'course', 'bronze', 25, '{"course_completions": 1}'),
('Knowledge Seeker', 'Complete 5 Courses', '/images/badges/knowledge-seeker.png', '#3B82F6', 'completion', 'course', 'silver', 100, '{"course_completions": 5}'),
('Course Expert', 'Complete 20 Courses', '/images/badges/course-expert.png', '#8B5CF6', 'completion', 'course', 'gold', 400, '{"course_completions": 20}'),
('Learning Master', 'Complete 50 Courses', '/images/badges/learning-master.png', '#F59E0B', 'completion', 'course', 'platinum', 1000, '{"course_completions": 50}');

-- Program Completion Achievements
INSERT INTO achievements (title, description, icon_url, badge_color, achievement_type, category, difficulty_level, point_value, criteria) VALUES
('Program Graduate', 'Complete your first Program', '/images/badges/program-graduate.png', '#10B981', 'completion', 'program', 'bronze', 100, '{"program_completions": 1}'),
('Certification Seeker', 'Complete 3 Programs', '/images/badges/certification-seeker.png', '#3B82F6', 'completion', 'program', 'silver', 300, '{"program_completions": 3}'),
('Program Expert', 'Complete 10 Programs', '/images/badges/program-expert.png', '#8B5CF6', 'completion', 'program', 'gold', 1000, '{"program_completions": 10}');

-- Streak Achievements
INSERT INTO achievements (title, description, icon_url, badge_color, achievement_type, category, difficulty_level, point_value, criteria) VALUES
('Consistent Learner', 'Log in for 7 consecutive days', '/images/badges/consistent-learner.png', '#06B6D4', 'streak', 'general', 'bronze', 25, '{"login_streak": 7}'),
('Dedicated Student', 'Log in for 30 consecutive days', '/images/badges/dedicated-student.png', '#06B6D4', 'streak', 'general', 'silver', 100, '{"login_streak": 30}'),
('Learning Devotee', 'Log in for 100 consecutive days', '/images/badges/learning-devotee.png', '#06B6D4', 'streak', 'general', 'gold', 500, '{"login_streak": 100}'),
('Weekly Warrior', 'Complete WODs for 7 consecutive days', '/images/badges/weekly-warrior.png', '#EF4444', 'streak', 'wod', 'silver', 75, '{"daily_wod_streak": 7}'),
('Monthly Master', 'Complete WODs for 30 consecutive days', '/images/badges/monthly-master.png', '#EF4444', 'streak', 'wod', 'gold', 300, '{"daily_wod_streak": 30}');

-- Mastery Achievements
INSERT INTO achievements (title, description, icon_url, badge_color, achievement_type, category, difficulty_level, point_value, criteria) VALUES
('Perfect Score', 'Achieve 100% score on any assessment', '/images/badges/perfect-score.png', '#F59E0B', 'mastery', 'general', 'silver', 50, '{"perfect_scores": 1}'),
('High Achiever', 'Maintain 90%+ average across 10 assessments', '/images/badges/high-achiever.png', '#F59E0B', 'mastery', 'general', 'gold', 200, '{"high_average_assessments": 10, "minimum_average": 90}'),
('Excellence Seeker', 'Achieve 95%+ on 5 consecutive assessments', '/images/badges/excellence-seeker.png', '#F59E0B', 'mastery', 'general', 'platinum', 400, '{"consecutive_high_scores": 5, "minimum_score": 95}'),
('Speed Learner', 'Complete a WOD in under 50% of estimated time', '/images/badges/speed-learner.png', '#10B981', 'mastery', 'wod', 'silver', 30, '{"fast_completion_percentage": 50}'),
('Time Master', 'Complete 10 WODs in under 60% of estimated time', '/images/badges/time-master.png', '#10B981', 'mastery', 'wod', 'gold', 150, '{"fast_completions": 10, "time_percentage": 60}');

-- Social and Participation Achievements
INSERT INTO achievements (title, description, icon_url, badge_color, achievement_type, category, difficulty_level, point_value, criteria) VALUES
('Community Member', 'Join your first learning community', '/images/badges/community-member.png', '#8B5CF6', 'social', 'community', 'bronze', 15, '{"community_joins": 1}'),
('Helpful Peer', 'Help 5 other learners', '/images/badges/helpful-peer.png', '#8B5CF6', 'social', 'community', 'silver', 75, '{"peer_helps": 5}'),
('Mentor', 'Help 20 other learners', '/images/badges/mentor.png', '#8B5CF6', 'social', 'community', 'gold', 250, '{"peer_helps": 20}'),
('Content Creator', 'Share 10 learning resources', '/images/badges/content-creator.png', '#F97316', 'social', 'community', 'silver', 100, '{"content_shares": 10}'),
('Knowledge Sharer', 'Share 50 learning insights', '/images/badges/knowledge-sharer.png', '#F97316', 'social', 'community', 'gold', 400, '{"knowledge_shares": 50}');

-- Special Recognition Achievements
INSERT INTO achievements (title, description, icon_url, badge_color, achievement_type, category, difficulty_level, point_value, criteria, is_rare) VALUES
('Pioneer', 'Among the first 100 users on the platform', '/images/badges/pioneer.png', '#DC2626', 'special', 'general', 'diamond', 1000, '{"user_rank": 100}', true),
('Beta Tester', 'Provided feedback during beta testing', '/images/badges/beta-tester.png', '#7C3AED', 'special', 'general', 'platinum', 500, '{"beta_participation": true}', true),
('Milestone Achiever', 'Reached a major platform milestone', '/images/badges/milestone-achiever.png', '#059669', 'special', 'general', 'gold', 300, '{"milestone_participation": true}', true),
('Early Adopter', 'Joined within the first month', '/images/badges/early-adopter.png', '#0891B2', 'special', 'general', 'gold', 200, '{"early_adoption": true}', true);

-- Learning Milestone Achievements
INSERT INTO achievements (title, description, icon_url, badge_color, achievement_type, category, difficulty_level, point_value, criteria) VALUES
('Milestone Starter', 'Complete your first learning milestone', '/images/badges/milestone-starter.png', '#10B981', 'completion', 'general', 'bronze', 20, '{"milestones_completed": 1}'),
('Progress Tracker', 'Complete 10 learning milestones', '/images/badges/progress-tracker.png', '#3B82F6', 'completion', 'general', 'silver', 100, '{"milestones_completed": 10}'),
('Achievement Hunter', 'Complete 25 learning milestones', '/images/badges/achievement-hunter.png', '#8B5CF6', 'completion', 'general', 'gold', 250, '{"milestones_completed": 25}'),
('Milestone Master', 'Complete 50 learning milestones', '/images/badges/milestone-master.png', '#F59E0B', 'completion', 'general', 'platinum', 600, '{"milestones_completed": 50}');