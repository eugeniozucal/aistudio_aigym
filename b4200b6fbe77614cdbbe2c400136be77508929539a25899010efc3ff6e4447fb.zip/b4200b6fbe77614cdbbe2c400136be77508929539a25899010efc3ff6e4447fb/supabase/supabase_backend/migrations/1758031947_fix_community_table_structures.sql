-- Migration: fix_community_table_structures
-- Created at: 1758031947

-- Drop and recreate tables with correct structure
DROP TABLE community_api_assignments;
DROP TABLE community_features;
DROP TABLE content_community_assignments;
DROP TABLE course_community_assignments;
DROP TABLE wod_community_assignments;

-- Recreate with correct structures
CREATE TABLE community_api_assignments (
  community_id UUID NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
  api_key_id UUID NOT NULL REFERENCES api_keys(id) ON DELETE CASCADE,
  PRIMARY KEY (community_id, api_key_id)
);

CREATE TABLE community_features (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  community_id UUID NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
  feature_name TEXT NOT NULL,
  enabled BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(community_id, feature_name)
);

CREATE TABLE content_community_assignments (
  content_item_id UUID NOT NULL,
  community_id UUID NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
  assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  assigned_by UUID,
  PRIMARY KEY (content_item_id, community_id)
);

CREATE TABLE course_community_assignments (
  course_id UUID NOT NULL,
  community_id UUID NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
  assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  assigned_by UUID,
  PRIMARY KEY (course_id, community_id)
);

CREATE TABLE wod_community_assignments (
  wod_id UUID NOT NULL,
  community_id UUID NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
  assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  assigned_by UUID,
  PRIMARY KEY (wod_id, community_id)
);;