-- Migration: 01_mission_to_wod_data_migration
-- Created at: 1757757707

-- Step 1: Data Migration - Copy mission progress to wod references
-- This ensures no data loss during the migration

BEGIN;

-- First, update user_progress to copy mission_id to wod_id where wod_id is null
UPDATE user_progress 
SET wod_id = mission_id 
WHERE mission_id IS NOT NULL AND wod_id IS NULL;

-- Verify the migration worked
DO $$
DECLARE
    mission_count INT;
    wod_count INT;
BEGIN
    SELECT COUNT(*) INTO mission_count FROM user_progress WHERE mission_id IS NOT NULL;
    SELECT COUNT(*) INTO wod_count FROM user_progress WHERE wod_id IS NOT NULL;
    
    IF mission_count != wod_count THEN
        RAISE EXCEPTION 'Data migration verification failed: mission_count=%, wod_count=%', mission_count, wod_count;
    END IF;
    
    RAISE NOTICE 'Data migration successful: % progress entries migrated', mission_count;
END $$;

COMMIT;;