-- Migration: enable_rls_and_policies
-- Created at: 1756100008

-- Enable RLS on all multi-tenant tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_tag_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE client_api_assignments ENABLE ROW LEVEL SECURITY;

-- RLS Policy for users table - users can only access data from their own client
CREATE POLICY "Users can only access their own client data" 
ON users
FOR ALL
USING (client_id = (SELECT client_id FROM users WHERE id = auth.uid()));

-- RLS Policy for user_tags table - tags are scoped to client
CREATE POLICY "User tags scoped to client" 
ON user_tags
FOR ALL
USING (client_id = (SELECT client_id FROM users WHERE id = auth.uid()));

-- RLS Policy for user_tag_assignments table - assignments scoped to user's client
CREATE POLICY "User tag assignments scoped to client" 
ON user_tag_assignments
FOR ALL
USING (
    user_id IN (
        SELECT id FROM users 
        WHERE client_id = (SELECT client_id FROM users WHERE id = auth.uid())
    )
);

-- RLS Policy for client_api_assignments table - API assignments scoped to client
CREATE POLICY "Client API assignments scoped to client" 
ON client_api_assignments
FOR ALL
USING (client_id = (SELECT client_id FROM users WHERE id = auth.uid()));

-- Admin policies for managing all data
CREATE POLICY "Admins can manage all users" 
ON users
FOR ALL
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM admins 
        WHERE id = auth.uid() 
        AND role IN ('super_admin', 'manager')
    )
);

CREATE POLICY "Admins can manage all user tags" 
ON user_tags
FOR ALL
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM admins 
        WHERE id = auth.uid() 
        AND role IN ('super_admin', 'manager')
    )
);

CREATE POLICY "Admins can manage all user tag assignments" 
ON user_tag_assignments
FOR ALL
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM admins 
        WHERE id = auth.uid() 
        AND role IN ('super_admin', 'manager')
    )
);

-- Allow public read access to clients table for admin interface
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read access to clients" 
ON clients
FOR SELECT
TO authenticated
USING (true);

-- Only admins can modify clients
CREATE POLICY "Admins can manage clients" 
ON clients
FOR ALL
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM admins 
        WHERE id = auth.uid() 
        AND role IN ('super_admin', 'manager')
    )
);

-- API keys and assignments are admin-only
ALTER TABLE api_keys ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage API keys" 
ON api_keys
FOR ALL
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM admins 
        WHERE id = auth.uid() 
        AND role = 'super_admin'
    )
);

CREATE POLICY "Admins can manage client API assignments" 
ON client_api_assignments
FOR ALL
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM admins 
        WHERE id = auth.uid() 
        AND role IN ('super_admin', 'manager')
    )
);;