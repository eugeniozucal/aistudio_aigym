-- Migration: create_uploaded_files_table_fixed
-- Created at: 1756435381

CREATE TABLE IF NOT EXISTS public.uploaded_files (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    filename text NOT NULL,
    original_filename text NOT NULL,
    file_path text NOT NULL,
    file_url text NOT NULL,
    file_size integer NOT NULL DEFAULT 0,
    mime_type text NOT NULL,
    folder text DEFAULT 'uploads',
    uploaded_by uuid,
    is_public boolean DEFAULT true,
    metadata jsonb DEFAULT '{}',
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS uploaded_files_uploaded_by_idx ON public.uploaded_files(uploaded_by);
CREATE INDEX IF NOT EXISTS uploaded_files_folder_idx ON public.uploaded_files(folder);
CREATE INDEX IF NOT EXISTS uploaded_files_mime_type_idx ON public.uploaded_files(mime_type);
CREATE INDEX IF NOT EXISTS uploaded_files_created_at_idx ON public.uploaded_files(created_at DESC);

-- Enable RLS
ALTER TABLE public.uploaded_files ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Allow admins full access to uploaded_files" ON public.uploaded_files
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.admins 
            WHERE id = auth.uid()
        )
    );

CREATE POLICY "Allow public read access to public uploaded_files" ON public.uploaded_files
    FOR SELECT USING (is_public = true);;