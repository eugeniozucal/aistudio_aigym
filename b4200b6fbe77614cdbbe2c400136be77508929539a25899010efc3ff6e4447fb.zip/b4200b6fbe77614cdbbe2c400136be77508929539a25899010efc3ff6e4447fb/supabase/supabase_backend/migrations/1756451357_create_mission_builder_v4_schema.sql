-- Migration: create_mission_builder_v4_schema
-- Created at: 1756451357

-- Mission Builder v4 Complete Schema
-- Create missions table
CREATE TABLE IF NOT EXISTS missions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  thumbnail_url TEXT,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  estimated_duration_minutes INTEGER,
  difficulty_level TEXT CHECK (difficulty_level IN ('beginner', 'intermediate', 'advanced')),
  tags TEXT[] DEFAULT '{}',
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create pages table
CREATE TABLE IF NOT EXISTS pages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  mission_id UUID REFERENCES missions(id) ON DELETE CASCADE,
  order_index INTEGER NOT NULL DEFAULT 0,
  is_locked BOOLEAN DEFAULT false,
  unlock_conditions JSONB DEFAULT '{}',
  page_config JSONB DEFAULT '{}',
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create blocks table
CREATE TABLE IF NOT EXISTS blocks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  page_id UUID REFERENCES pages(id) ON DELETE CASCADE,
  block_type TEXT NOT NULL,
  order_index INTEGER NOT NULL DEFAULT 0,
  config JSONB DEFAULT '{}',
  style JSONB DEFAULT '{}',
  content JSONB DEFAULT '{}',
  visibility_conditions JSONB DEFAULT '{}',
  is_visible BOOLEAN DEFAULT true,
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_missions_organization ON missions(organization_id);
CREATE INDEX IF NOT EXISTS idx_missions_created_by ON missions(created_by);
CREATE INDEX IF NOT EXISTS idx_missions_status ON missions(status);

CREATE INDEX IF NOT EXISTS idx_pages_mission ON pages(mission_id);
CREATE INDEX IF NOT EXISTS idx_pages_organization ON pages(organization_id);
CREATE INDEX IF NOT EXISTS idx_pages_order ON pages(mission_id, order_index);

CREATE INDEX IF NOT EXISTS idx_blocks_page ON blocks(page_id);
CREATE INDEX IF NOT EXISTS idx_blocks_organization ON blocks(organization_id);
CREATE INDEX IF NOT EXISTS idx_blocks_order ON blocks(page_id, order_index);
CREATE INDEX IF NOT EXISTS idx_blocks_type ON blocks(block_type);

-- Enable RLS
ALTER TABLE missions ENABLE ROW LEVEL SECURITY;
ALTER TABLE pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE blocks ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view missions from their organization" ON missions
  FOR SELECT USING (organization_id IN (
    SELECT organization_id FROM users WHERE id = auth.uid()
  ));

CREATE POLICY "Users can create missions in their organization" ON missions
  FOR INSERT WITH CHECK (organization_id IN (
    SELECT organization_id FROM users WHERE id = auth.uid()
  ));

CREATE POLICY "Users can update missions in their organization" ON missions
  FOR UPDATE USING (organization_id IN (
    SELECT organization_id FROM users WHERE id = auth.uid()
  ));

CREATE POLICY "Users can delete missions in their organization" ON missions
  FOR DELETE USING (organization_id IN (
    SELECT organization_id FROM users WHERE id = auth.uid()
  ));

-- Pages policies
CREATE POLICY "Users can view pages from their organization" ON pages
  FOR SELECT USING (organization_id IN (
    SELECT organization_id FROM users WHERE id = auth.uid()
  ));

CREATE POLICY "Users can create pages in their organization" ON pages
  FOR INSERT WITH CHECK (organization_id IN (
    SELECT organization_id FROM users WHERE id = auth.uid()
  ));

CREATE POLICY "Users can update pages in their organization" ON pages
  FOR UPDATE USING (organization_id IN (
    SELECT organization_id FROM users WHERE id = auth.uid()
  ));

CREATE POLICY "Users can delete pages in their organization" ON pages
  FOR DELETE USING (organization_id IN (
    SELECT organization_id FROM users WHERE id = auth.uid()
  ));

-- Blocks policies  
CREATE POLICY "Users can view blocks from their organization" ON blocks
  FOR SELECT USING (organization_id IN (
    SELECT organization_id FROM users WHERE id = auth.uid()
  ));

CREATE POLICY "Users can create blocks in their organization" ON blocks
  FOR INSERT WITH CHECK (organization_id IN (
    SELECT organization_id FROM users WHERE id = auth.uid()
  ));

CREATE POLICY "Users can update blocks in their organization" ON blocks
  FOR UPDATE USING (organization_id IN (
    SELECT organization_id FROM users WHERE id = auth.uid()
  ));

CREATE POLICY "Users can delete blocks in their organization" ON blocks
  FOR DELETE USING (organization_id IN (
    SELECT organization_id FROM users WHERE id = auth.uid()
  ));;