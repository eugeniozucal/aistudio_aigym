-- Migration: 03_mission_to_wod_cleanup_orphaned_data
-- Created at: 1757757740

-- Step 3A: Clean up orphaned data before updating pages table

BEGIN;

-- First, let's see what we're dealing with - identify and document orphaned pages
CREATE TEMP TABLE orphaned_pages_backup AS
SELECT * FROM pages 
WHERE mission_id IS NOT NULL 
AND mission_id NOT IN (SELECT id FROM wods);

-- Log the cleanup for audit trail
RAISE NOTICE 'Found % orphaned pages referencing non-existent missions', (SELECT COUNT(*) FROM orphaned_pages_backup);

-- Option 1: Delete orphaned pages (safest for data integrity)
-- Note: This removes pages that reference missions that no longer exist
DELETE FROM pages 
WHERE mission_id IS NOT NULL 
AND mission_id NOT IN (SELECT id FROM wods);

-- Alternative Option 2 (commented out): Set orphaned pages to null
-- UPDATE pages SET mission_id = NULL 
-- WHERE mission_id IS NOT NULL 
-- AND mission_id NOT IN (SELECT id FROM wods);

-- Verify cleanup
DO $$
DECLARE
    remaining_orphans INT;
BEGIN
    SELECT COUNT(*) INTO remaining_orphans 
    FROM pages 
    WHERE mission_id IS NOT NULL 
    AND mission_id NOT IN (SELECT id FROM wods);
    
    IF remaining_orphans > 0 THEN
        RAISE EXCEPTION 'Cleanup failed: % orphaned pages remain', remaining_orphans;
    END IF;
    
    RAISE NOTICE 'Cleanup successful: All orphaned pages removed';
END $$;

COMMIT;;