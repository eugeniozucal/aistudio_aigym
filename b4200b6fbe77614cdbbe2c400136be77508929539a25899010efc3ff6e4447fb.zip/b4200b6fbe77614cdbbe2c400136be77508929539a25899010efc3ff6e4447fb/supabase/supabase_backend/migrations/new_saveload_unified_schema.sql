-- Migration: New Save/Load Unified Schema
-- Created at: 2025-09-19 21:48:01
-- Description: Complete schema redesign based on comprehensive research

-- =============================================================================
-- PHASE 1: ENUMS AND TYPES
-- =============================================================================

-- Repository types for different content categories
DO $$ BEGIN
    CREATE TYPE repository_type AS ENUM (
        'wods',
        'blocks', 
        'programs',
        'ai_agents',
        'videos',
        'documents',
        'prompts',
        'automations',
        'images',
        'pdfs'
    );
EXCEPTION
    WHEN duplicate_object THEN 
        -- Drop and recreate if exists
        DROP TYPE IF EXISTS repository_type CASCADE;
        CREATE TYPE repository_type AS ENUM (
            'wods',
            'blocks',
            'programs', 
            'ai_agents',
            'videos',
            'documents',
            'prompts',
            'automations',
            'images',
            'pdfs'
        );
END $$;

-- Content status enumeration
DO $$ BEGIN
    CREATE TYPE content_status AS ENUM ('draft', 'published', 'archived');
EXCEPTION
    WHEN duplicate_object THEN
        DROP TYPE IF EXISTS content_status CASCADE;
        CREATE TYPE content_status AS ENUM ('draft', 'published', 'archived');
END $$;

-- Operation type for audit tracking
DO $$ BEGIN
    CREATE TYPE operation_type AS ENUM ('create', 'update', 'delete', 'auto_save');
EXCEPTION
    WHEN duplicate_object THEN
        DROP TYPE IF EXISTS operation_type CASCADE;
        CREATE TYPE operation_type AS ENUM ('create', 'update', 'delete', 'auto_save');
END $$;

-- =============================================================================
-- PHASE 2: CORE TABLES
-- =============================================================================

-- Enhanced content_items table (unified)
DROP TABLE IF EXISTS content_items_new CASCADE;
CREATE TABLE content_items_new (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
    repository_type repository_type NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    content JSONB NOT NULL DEFAULT '{}',
    metadata JSONB NOT NULL DEFAULT '{}',
    status content_status DEFAULT 'draft',
    folder_id UUID REFERENCES folders(id) ON DELETE SET NULL,
    thumbnail_url TEXT,
    
    -- Audit fields
    created_by UUID NOT NULL,
    updated_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    version INTEGER DEFAULT 1,
    
    -- Additional metadata for specific content types
    estimated_duration_minutes INTEGER,
    difficulty_level VARCHAR(20) CHECK (difficulty_level IN ('beginner', 'intermediate', 'advanced')),
    tags TEXT[] DEFAULT '{}',
    
    -- Constraints
    CONSTRAINT content_title_length CHECK (char_length(title) >= 1 AND char_length(title) <= 255),
    CONSTRAINT content_description_length CHECK (char_length(description) <= 5000),
    CONSTRAINT content_version_positive CHECK (version > 0)
);

-- Content history for versioning and audit
DROP TABLE IF EXISTS content_history CASCADE;
CREATE TABLE content_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_id UUID NOT NULL REFERENCES content_items_new(id) ON DELETE CASCADE,
    version INTEGER NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    content JSONB NOT NULL,
    metadata JSONB NOT NULL DEFAULT '{}',
    status content_status NOT NULL,
    operation_type operation_type NOT NULL,
    created_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(content_id, version)
);

-- Auto-save snapshots for recovery
DROP TABLE IF EXISTS auto_save_snapshots CASCADE;
CREATE TABLE auto_save_snapshots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_id UUID NOT NULL REFERENCES content_items_new(id) ON DELETE CASCADE,
    session_id VARCHAR(255) NOT NULL,
    content JSONB NOT NULL,
    metadata JSONB NOT NULL DEFAULT '{}',
    created_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Index for cleanup operations
    CONSTRAINT unique_session_content UNIQUE(content_id, session_id)
);

-- =============================================================================
-- PHASE 3: INDEXES FOR PERFORMANCE
-- =============================================================================

-- Content items indexes
CREATE INDEX idx_content_items_workspace_repo ON content_items_new(workspace_id, repository_type);
CREATE INDEX idx_content_items_folder ON content_items_new(folder_id);
CREATE INDEX idx_content_items_status ON content_items_new(status);
CREATE INDEX idx_content_items_created_by ON content_items_new(created_by);
CREATE INDEX idx_content_items_updated_at ON content_items_new(updated_at DESC);
CREATE INDEX idx_content_items_tags_gin ON content_items_new USING GIN(tags);

-- Content history indexes
CREATE INDEX idx_content_history_content_id ON content_history(content_id);
CREATE INDEX idx_content_history_version ON content_history(content_id, version DESC);
CREATE INDEX idx_content_history_created_at ON content_history(created_at DESC);

-- Auto-save indexes  
CREATE INDEX idx_auto_save_content_session ON auto_save_snapshots(content_id, session_id);
CREATE INDEX idx_auto_save_created_at ON auto_save_snapshots(created_at DESC);

-- =============================================================================
-- PHASE 4: TRIGGERS AND FUNCTIONS
-- =============================================================================

-- Updated timestamp trigger function
CREATE OR REPLACE FUNCTION fn_set_updated_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    NEW.version = OLD.version + 1;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Content history tracking function
CREATE OR REPLACE FUNCTION fn_track_content_history()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO content_history(
            content_id, version, title, description, content, metadata, 
            status, operation_type, created_by
        ) VALUES (
            NEW.id, NEW.version, NEW.title, NEW.description, NEW.content, 
            NEW.metadata, NEW.status, 'create', NEW.created_by
        );
    ELSIF TG_OP = 'UPDATE' AND (OLD.content != NEW.content OR OLD.title != NEW.title OR OLD.description != NEW.description) THEN
        INSERT INTO content_history(
            content_id, version, title, description, content, metadata, 
            status, operation_type, created_by
        ) VALUES (
            NEW.id, NEW.version, NEW.title, NEW.description, NEW.content, 
            NEW.metadata, NEW.status, 'update', NEW.updated_by
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Auto-save cleanup function
CREATE OR REPLACE FUNCTION fn_cleanup_auto_save()
RETURNS void AS $$
BEGIN
    -- Delete auto-save snapshots older than 24 hours
    DELETE FROM auto_save_snapshots 
    WHERE created_at < CURRENT_TIMESTAMP - INTERVAL '24 hours';
    
    -- Keep only the latest 10 snapshots per content item per session
    DELETE FROM auto_save_snapshots
    WHERE id NOT IN (
        SELECT id FROM (
            SELECT id, 
                   ROW_NUMBER() OVER (PARTITION BY content_id, session_id ORDER BY created_at DESC) as rn
            FROM auto_save_snapshots
        ) ranked
        WHERE rn <= 10
    );
END;
$$ LANGUAGE plpgsql;

-- Create triggers
CREATE TRIGGER tr_content_items_updated_at
    BEFORE UPDATE ON content_items_new
    FOR EACH ROW
    EXECUTE FUNCTION fn_set_updated_timestamp();

CREATE TRIGGER tr_track_content_history
    AFTER INSERT OR UPDATE ON content_items_new
    FOR EACH ROW
    EXECUTE FUNCTION fn_track_content_history();

-- =============================================================================
-- PHASE 5: DATA MIGRATION
-- =============================================================================

-- Ensure default workspace exists
INSERT INTO workspaces (id, name, owner_id) 
SELECT 
    'default-workspace-uuid'::uuid, 
    'Default Workspace',
    (SELECT id FROM users ORDER BY created_at LIMIT 1)
WHERE NOT EXISTS (SELECT 1 FROM workspaces WHERE id = 'default-workspace-uuid'::uuid);

-- Migrate from missions table (WODs)
INSERT INTO content_items_new (
    id, workspace_id, repository_type, title, description, status, 
    created_by, updated_by, created_at, updated_at, thumbnail_url,
    estimated_duration_minutes, difficulty_level, tags, content, metadata
)
SELECT 
    id,
    'default-workspace-uuid'::uuid,
    'wods'::repository_type,
    title,
    description,
    status::content_status,
    created_by,
    created_by, -- Same as created_by for migration
    created_at,
    updated_at,
    thumbnail_url,
    estimated_duration_minutes,
    difficulty_level,
    tags,
    '{}'::jsonb, -- Empty content for now
    '{}'::jsonb   -- Empty metadata for now
FROM missions
WHERE EXISTS (SELECT 1 FROM missions)
ON CONFLICT (id) DO NOTHING;

-- Migrate from workout_blocks table
INSERT INTO content_items_new (
    id, workspace_id, repository_type, title, description, status,
    created_by, updated_by, created_at, updated_at, thumbnail_url,
    estimated_duration_minutes, difficulty_level, tags, content, metadata
)
SELECT 
    id,
    'default-workspace-uuid'::uuid,
    'blocks'::repository_type,
    title,
    description,
    status::content_status,
    (SELECT id FROM users ORDER BY created_at LIMIT 1), -- Default to first user for migration
    (SELECT id FROM users ORDER BY created_at LIMIT 1),
    created_at,
    updated_at,
    thumbnail_url,
    estimated_duration_minutes,
    difficulty_level,
    tags,
    jsonb_build_object(
        'instructions', instructions,
        'equipment_needed', equipment_needed,
        'block_category', block_category
    ),
    '{}'::jsonb
FROM workout_blocks
WHERE EXISTS (SELECT 1 FROM workout_blocks)
ON CONFLICT (id) DO NOTHING;

-- Migrate from existing content_items table
INSERT INTO content_items_new (
    id, workspace_id, repository_type, title, description, status,
    created_by, updated_by, created_at, updated_at, thumbnail_url, content, metadata
)
SELECT 
    id,
    'default-workspace-uuid'::uuid,
    CASE 
        WHEN content_type = 'ai_agent' THEN 'ai_agents'::repository_type
        WHEN content_type = 'video' THEN 'videos'::repository_type
        WHEN content_type = 'document' THEN 'documents'::repository_type
        WHEN content_type = 'prompt' THEN 'prompts'::repository_type
        WHEN content_type = 'automation' THEN 'automations'::repository_type
        ELSE 'documents'::repository_type
    END,
    title,
    description,
    status::content_status,
    created_by,
    created_by,
    created_at,
    updated_at,
    thumbnail_url,
    '{}'::jsonb,
    jsonb_build_object('content_type', content_type)
FROM content_items
WHERE EXISTS (SELECT 1 FROM content_items)
ON CONFLICT (id) DO NOTHING;

-- =============================================================================
-- PHASE 6: REPLACE OLD TABLE
-- =============================================================================

-- Backup old table and replace
ALTER TABLE IF EXISTS content_items RENAME TO content_items_backup;
ALTER TABLE content_items_new RENAME TO content_items;

-- =============================================================================
-- PHASE 7: RLS POLICIES
-- =============================================================================

-- Enable RLS
ALTER TABLE content_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE auto_save_snapshots ENABLE ROW LEVEL SECURITY;

-- Content items policies
CREATE POLICY "Users can manage own workspace content" ON content_items
    FOR ALL USING (
        workspace_id IN (
            SELECT id FROM workspaces WHERE owner_id = auth.uid()
        )
    );

-- Content history policies
CREATE POLICY "Users can view own content history" ON content_history
    FOR SELECT USING (
        content_id IN (
            SELECT id FROM content_items WHERE workspace_id IN (
                SELECT id FROM workspaces WHERE owner_id = auth.uid()
            )
        )
    );

-- Auto-save policies
CREATE POLICY "Users can manage own auto-save snapshots" ON auto_save_snapshots
    FOR ALL USING (
        content_id IN (
            SELECT id FROM content_items WHERE workspace_id IN (
                SELECT id FROM workspaces WHERE owner_id = auth.uid()
            )
        )
    );

-- Create cleanup job (example - would need actual cron setup)
COMMENT ON FUNCTION fn_cleanup_auto_save() IS 'Should be called via cron job every hour: SELECT fn_cleanup_auto_save();';

COMMENT ON TABLE content_items IS 'Unified content storage for all content types (WODs, blocks, programs, etc.)';
COMMENT ON TABLE content_history IS 'Version history and audit trail for all content changes';
COMMENT ON TABLE auto_save_snapshots IS 'Auto-save snapshots for recovery in case of browser crashes';
