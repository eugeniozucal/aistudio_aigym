-- Migration: add_videos_foreign_key_relationship
-- Created at: 1758229373

-- Add foreign key constraint between videos and content_items tables
ALTER TABLE videos 
ADD CONSTRAINT videos_content_item_id_fkey 
FOREIGN KEY (content_item_id) 
REFERENCES content_items(id) 
ON DELETE CASCADE;;