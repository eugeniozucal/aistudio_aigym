-- Migration: add_missing_phase2_tables_fixed
-- Created at: 1756104896

-- Create api_keys table for client API key management
CREATE TABLE IF NOT EXISTS public.api_keys (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    key_type VARCHAR(50) NOT NULL DEFAULT 'openai',
    encrypted_key TEXT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    created_by UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_api_keys_status ON public.api_keys(status);
CREATE INDEX IF NOT EXISTS idx_api_keys_type ON public.api_keys(key_type);

-- Alter clients table to add missing columns
ALTER TABLE public.clients 
ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'active',
ADD COLUMN IF NOT EXISTS brand_color VARCHAR(7) DEFAULT '#3B82F6',
ADD COLUMN IF NOT EXISTS forum_enabled BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS is_template BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS api_key_id UUID REFERENCES public.api_keys(id);

-- Create client templates table
CREATE TABLE IF NOT EXISTS public.client_templates (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    base_client_id UUID NOT NULL REFERENCES public.clients(id),
    template_data JSONB,
    is_active BOOLEAN DEFAULT true,
    created_by UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Update existing clients table structure with proper defaults
UPDATE public.clients 
SET 
    brand_color = COALESCE(color_hex, '#3B82F6'),
    forum_enabled = COALESCE(has_forum, true),
    status = COALESCE(status, 'active')
WHERE brand_color IS NULL OR forum_enabled IS NULL OR status IS NULL;

-- Add indexes for clients table
CREATE INDEX IF NOT EXISTS idx_clients_status ON public.clients(status);
CREATE INDEX IF NOT EXISTS idx_clients_is_template ON public.clients(is_template);

-- Create RLS policies for api_keys
ALTER TABLE public.api_keys ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all API keys" ON public.api_keys
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Admins can manage API keys" ON public.api_keys
    FOR ALL USING (auth.role() = 'authenticated');

-- Create RLS policies for client_templates  
ALTER TABLE public.client_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all templates" ON public.client_templates
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Admins can manage templates" ON public.client_templates
    FOR ALL USING (auth.role() = 'authenticated');

-- Insert some sample API keys for testing
INSERT INTO public.api_keys (name, key_type, encrypted_key, status) VALUES 
('OpenAI GPT-4', 'openai', 'encrypted_key_placeholder_1', 'active'),
('Anthropic Claude', 'anthropic', 'encrypted_key_placeholder_2', 'active'),
('OpenAI GPT-3.5', 'openai', 'encrypted_key_placeholder_3', 'active')
ON CONFLICT DO NOTHING;;