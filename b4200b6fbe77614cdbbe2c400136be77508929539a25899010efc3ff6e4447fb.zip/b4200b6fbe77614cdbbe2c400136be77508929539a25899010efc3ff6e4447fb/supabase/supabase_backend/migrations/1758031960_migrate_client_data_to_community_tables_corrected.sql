-- Migration: migrate_client_data_to_community_tables_corrected
-- Created at: 1758031960

-- Migrate client_api_assignments to community_api_assignments
INSERT INTO community_api_assignments (community_id, api_key_id)
SELECT client_id, api_key_id FROM client_api_assignments;

-- Migrate client_features to community_features
INSERT INTO community_features (id, community_id, feature_name, enabled, created_at, updated_at)
SELECT id, client_id, feature_name, enabled, created_at, updated_at FROM client_features;

-- Migrate content_client_assignments to content_community_assignments
INSERT INTO content_community_assignments (content_item_id, community_id, assigned_at, assigned_by)
SELECT content_item_id, client_id, assigned_at, assigned_by FROM content_client_assignments;

-- Migrate course_client_assignments to course_community_assignments  
INSERT INTO course_community_assignments (course_id, community_id, assigned_at, assigned_by)
SELECT course_id, client_id, assigned_at, assigned_by FROM course_client_assignments;

-- Migrate wod_client_assignments to wod_community_assignments
INSERT INTO wod_community_assignments (wod_id, community_id, assigned_at, assigned_by)
SELECT wod_id, client_id, assigned_at, assigned_by FROM wod_client_assignments;;