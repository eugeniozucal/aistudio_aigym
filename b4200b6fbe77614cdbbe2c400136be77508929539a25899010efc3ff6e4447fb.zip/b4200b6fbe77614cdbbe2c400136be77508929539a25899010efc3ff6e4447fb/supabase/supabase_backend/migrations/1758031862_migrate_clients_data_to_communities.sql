-- Migration: migrate_clients_data_to_communities
-- Created at: 1758031862

-- Migrate all data from clients table to communities table
INSERT INTO communities (id, name, project_name, logo_url, created_at, updated_at, status, template_source_id, api_key_id, brand_color, forum_enabled, is_template)
SELECT id, name, project_name, logo_url, created_at, updated_at, status, template_source_id, api_key_id, brand_color, forum_enabled, is_template
FROM clients;;