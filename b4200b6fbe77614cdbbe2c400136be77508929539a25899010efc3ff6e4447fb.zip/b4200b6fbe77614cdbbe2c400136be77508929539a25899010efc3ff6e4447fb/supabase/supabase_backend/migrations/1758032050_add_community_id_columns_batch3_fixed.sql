-- Migration: add_community_id_columns_batch3_fixed
-- Created at: 1758032050

-- Add community_id columns to remaining tables (batch 3) - excluding views
ALTER TABLE performance_history ADD COLUMN community_id UUID;
ALTER TABLE program_courses ADD COLUMN community_id UUID;
ALTER TABLE program_enrollments ADD COLUMN community_id UUID;
ALTER TABLE program_milestones ADD COLUMN community_id UUID;
ALTER TABLE user_achievements ADD COLUMN community_id UUID;
ALTER TABLE user_courses ADD COLUMN community_id UUID;
ALTER TABLE user_daily_activity ADD COLUMN community_id UUID;
ALTER TABLE user_milestone_progress ADD COLUMN community_id UUID;
ALTER TABLE user_progress ADD COLUMN community_id UUID;
ALTER TABLE user_streaks ADD COLUMN community_id UUID;
ALTER TABLE user_wods ADD COLUMN community_id UUID;

-- Copy data from client_id to community_id columns
UPDATE performance_history SET community_id = client_id;
UPDATE program_courses SET community_id = client_id;
UPDATE program_enrollments SET community_id = client_id;
UPDATE program_milestones SET community_id = client_id;
UPDATE user_achievements SET community_id = client_id;
UPDATE user_courses SET community_id = client_id;
UPDATE user_daily_activity SET community_id = client_id;
UPDATE user_milestone_progress SET community_id = client_id;
UPDATE user_progress SET community_id = client_id;
UPDATE user_streaks SET community_id = client_id;
UPDATE user_wods SET community_id = client_id;;