-- Migration: add_community_foreign_key_constraints_batch1
-- Created at: 1758032061

-- Add foreign key constraints for community_id columns (batch 1)
-- Tables where community_id should be NOT NULL (mandatory relationships)
ALTER TABLE users 
  ALTER COLUMN community_id SET NOT NULL,
  ADD CONSTRAINT users_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE CASCADE;

ALTER TABLE user_activities 
  ALTER COLUMN community_id SET NOT NULL,
  ADD CONSTRAINT user_activities_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE CASCADE;

ALTER TABLE user_tags 
  ALTER COLUMN community_id SET NOT NULL,
  ADD CONSTRAINT user_tags_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE CASCADE;

ALTER TABLE bulk_uploads 
  ALTER COLUMN community_id SET NOT NULL,
  ADD CONSTRAINT bulk_uploads_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE CASCADE;;