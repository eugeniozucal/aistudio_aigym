-- Migration: emergency_rollback_conflicting_auth_tables
-- Created at: 1757184371

-- Emergency Rollback Migration: Remove Conflicting Authentication Tables
-- Created: September 7, 2025
-- Purpose: Fix dual authentication system conflict causing system-wide failures
-- 
-- This migration rolls back the breaking changes from 1756153735_create_conversation_history_tables.sql
-- that introduced auth.users references conflicting with the custom users table system

-- Drop triggers first
DROP TRIGGER IF EXISTS update_conversation_on_message_insert ON conversation_messages;

-- Drop functions
DROP FUNCTION IF EXISTS update_conversation_updated_at();

-- Drop tables (this will also drop the RLS policies)
DROP TABLE IF EXISTS conversation_messages CASCADE;
DROP TABLE IF EXISTS conversations CASCADE;

-- Log the rollback action
INSERT INTO public.platform_settings (setting_key, setting_value, setting_type, description)
VALUES (
    'emergency_rollback_conversation_tables',
    '{"rolled_back_at": "2025-09-07T02:43:29Z", "reason": "dual_auth_system_conflict", "tables_removed": ["conversations", "conversation_messages"]}',
    'emergency_action',
    'Emergency rollback to resolve dual authentication system conflict causing platform failure'
) ON CONFLICT (setting_key) DO UPDATE SET
    setting_value = EXCLUDED.setting_value,
    updated_at = NOW();

-- Success message
DO $$
BEGIN
    RAISE NOTICE 'Emergency rollback completed: Conflicting conversation tables removed';
    RAISE NOTICE 'System should now use single authentication model (custom users table)';
    RAISE NOTICE 'Conversation features will need to be reimplemented with compatible schema';
END $$;;