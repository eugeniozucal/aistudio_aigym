-- Migration: simplify_rls_policies
-- Created at: 1756101976

-- Simplify RLS policies to avoid circular references

-- Drop existing problematic policies
DROP POLICY IF EXISTS "Users access own client data" ON users;
DROP POLICY IF EXISTS "User tags access control" ON user_tags;
DROP POLICY IF EXISTS "User tag assignments access control" ON user_tag_assignments;

-- Create simple admin-first policies
CREATE POLICY "Admin access to users" 
ON users
FOR ALL
TO authenticated
USING (
    -- Admin users get full access
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);

CREATE POLICY "Client user access" 
ON users
FOR ALL
TO authenticated
USING (
    -- Regular users can only see their own client data
    NOT EXISTS (SELECT 1 FROM admins WHERE id = auth.uid()) 
    AND client_id = (SELECT client_id FROM users WHERE id = auth.uid() LIMIT 1)
);

CREATE POLICY "Admin access to user_tags" 
ON user_tags
FOR ALL
TO authenticated
USING (
    -- Admin users get full access
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);

CREATE POLICY "Client user access to tags" 
ON user_tags
FOR ALL
TO authenticated
USING (
    -- Regular users can only see tags from their own client
    NOT EXISTS (SELECT 1 FROM admins WHERE id = auth.uid()) 
    AND client_id = (SELECT client_id FROM users WHERE id = auth.uid() LIMIT 1)
);

CREATE POLICY "Admin access to user_tag_assignments" 
ON user_tag_assignments
FOR ALL
TO authenticated
USING (
    -- Admin users get full access
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);

CREATE POLICY "Client user access to assignments" 
ON user_tag_assignments
FOR ALL
TO authenticated
USING (
    -- Regular users can only see assignments from their own client
    NOT EXISTS (SELECT 1 FROM admins WHERE id = auth.uid()) 
    AND user_id IN (
        SELECT id FROM users 
        WHERE client_id = (SELECT client_id FROM users WHERE id = auth.uid() LIMIT 1)
    )
);;