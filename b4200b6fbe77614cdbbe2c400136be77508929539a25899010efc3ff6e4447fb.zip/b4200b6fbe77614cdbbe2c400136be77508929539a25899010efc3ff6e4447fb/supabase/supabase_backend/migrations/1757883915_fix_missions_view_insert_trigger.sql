-- Migration: fix_missions_view_insert_trigger
-- Created at: 1757883915

-- Fix the missions view insert trigger to properly return the created record

-- Drop and recreate the trigger function with proper RETURNING clause
DROP TRIGGER IF EXISTS insert_mission_trigger ON missions;
DROP FUNCTION IF EXISTS insert_mission_to_wod();

-- Create an improved INSTEAD OF trigger function for INSERT operations
CREATE OR REPLACE FUNCTION insert_mission_to_wod()
RETURNS TRIGGER AS $$
DECLARE
    new_wod_id UUID := gen_random_uuid();
    inserted_wod RECORD;
BEGIN
    INSERT INTO wods (
        id, title, description, thumbnail_url, status, estimated_duration_minutes,
        difficulty_level, tags, category_id, workout_type, target_muscle_groups,
        equipment_needed, client_id, wod_sequence, prerequisites, completion_criteria,
        is_published, created_by, created_at, updated_at
    ) VALUES (
        new_wod_id,
        NEW.title,
        NEW.description,
        NEW.thumbnail_url,
        NEW.status,
        NEW.estimated_duration_minutes,
        NEW.difficulty_level,
        COALESCE(NEW.tags, '{}'),
        NEW.category_id,
        NEW.workout_type,
        NEW.target_muscle_groups,
        NEW.equipment_needed,
        NEW.client_id,
        COALESCE(NEW.wod_sequence, '[]'),
        COALESCE(NEW.prerequisites, '[]'),
        COALESCE(NEW.completion_criteria, '{}'),
        COALESCE(NEW.is_published, false),
        NEW.created_by,
        NOW(),
        NOW()
    ) RETURNING * INTO inserted_wod;
    
    -- Set the NEW record values to match the inserted record
    NEW.id = inserted_wod.id;
    NEW.created_at = inserted_wod.created_at;
    NEW.updated_at = inserted_wod.updated_at;
    NEW.tags = inserted_wod.tags;
    NEW.wod_sequence = inserted_wod.wod_sequence;
    NEW.prerequisites = inserted_wod.prerequisites;
    NEW.completion_criteria = inserted_wod.completion_criteria;
    NEW.is_published = inserted_wod.is_published;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER insert_mission_trigger
    INSTEAD OF INSERT ON missions
    FOR EACH ROW
    EXECUTE FUNCTION insert_mission_to_wod();;