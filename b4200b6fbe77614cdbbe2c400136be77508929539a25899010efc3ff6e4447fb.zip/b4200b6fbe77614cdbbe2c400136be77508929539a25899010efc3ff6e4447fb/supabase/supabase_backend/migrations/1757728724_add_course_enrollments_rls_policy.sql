-- Migration: add_course_enrollments_rls_policy
-- Created at: 1757728724

-- Add RLS policy for course_enrollments table
CREATE POLICY "Users can manage their enrollments" ON course_enrollments
    FOR ALL USING (auth.uid() = user_id OR auth.role() = 'service_role');

-- Update courses to be published so they show up
UPDATE courses SET is_published = true WHERE id IN ('2239854e-aea3-46de-97b6-a149b139389b', '64366b17-8252-405e-8e15-2a6d714794c1');;