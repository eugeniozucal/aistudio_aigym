-- Migration: fix_phase7_database_schema
-- Created at: 1757769157

-- Fix Phase 7 Database Schema Issues
-- Add missing columns to support frontend application

-- Add is_active column to programs table
ALTER TABLE programs ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;

-- Add missing columns to achievements table  
ALTER TABLE achievements ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;
ALTER TABLE achievements ADD COLUMN IF NOT EXISTS name TEXT;
ALTER TABLE achievements ADD COLUMN IF NOT EXISTS badge_icon TEXT;
ALTER TABLE achievements ADD COLUMN IF NOT EXISTS points_value INTEGER DEFAULT 0;

-- Add is_active column to courses table
ALTER TABLE courses ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;

-- Update achievements table structure for frontend compatibility
UPDATE achievements SET name = title WHERE name IS NULL;
UPDATE achievements SET points_value = point_value WHERE points_value = 0 OR points_value IS NULL;

-- Create program_courses table if not exists
CREATE TABLE IF NOT EXISTS program_courses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    program_id UUID REFERENCES programs(id) ON DELETE CASCADE,
    course_id UUID REFERENCES courses(id) ON DELETE CASCADE,
    sequence_order INTEGER NOT NULL DEFAULT 1,
    is_required BOOLEAN DEFAULT true,
    client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(program_id, course_id),
    UNIQUE(program_id, sequence_order)
);

-- Create user_courses table if not exists
CREATE TABLE IF NOT EXISTS user_courses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    course_id UUID REFERENCES courses(id) ON DELETE CASCADE,
    progress_percentage NUMERIC(5,2) DEFAULT 0 CHECK (progress_percentage >= 0 AND progress_percentage <= 100),
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    time_spent_minutes INTEGER DEFAULT 0,
    last_activity_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, course_id)
);

-- Create user_wods table if not exists
CREATE TABLE IF NOT EXISTS user_wods (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    wod_id UUID REFERENCES wods(id) ON DELETE CASCADE,
    completed_at TIMESTAMP WITH TIME ZONE,
    time_to_complete INTEGER, -- in seconds
    attempts INTEGER DEFAULT 1,
    success_rate NUMERIC(5,2),
    client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, wod_id)
);

-- Update existing data to ensure compatibility
UPDATE programs SET is_active = true WHERE is_active IS NULL;
UPDATE achievements SET is_active = true WHERE is_active IS NULL;
UPDATE courses SET is_active = true WHERE is_active IS NULL;;