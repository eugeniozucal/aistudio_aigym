-- Migration: new_saveload_unified_schema
-- Created at: 1758290078

-- Migration: New Save/Load Unified Schema
-- Created at: 2025-09-19 21:48:01
-- Description: Complete schema redesign based on comprehensive research

-- =============================================================================
-- PHASE 1: ENUMS AND TYPES
-- =============================================================================

-- Repository types for different content categories
DO $$ BEGIN
    CREATE TYPE repository_type AS ENUM (
        'wods',
        'blocks', 
        'programs',
        'ai_agents',
        'videos',
        'documents',
        'prompts',
        'automations',
        'images',
        'pdfs'
    );
EXCEPTION
    WHEN duplicate_object THEN 
        -- Drop and recreate if exists
        DROP TYPE IF EXISTS repository_type CASCADE;
        CREATE TYPE repository_type AS ENUM (
            'wods',
            'blocks',
            'programs', 
            'ai_agents',
            'videos',
            'documents',
            'prompts',
            'automations',
            'images',
            'pdfs'
        );
END $$;

-- Content status enumeration
DO $$ BEGIN
    CREATE TYPE content_status AS ENUM ('draft', 'published', 'archived');
EXCEPTION
    WHEN duplicate_object THEN
        DROP TYPE IF EXISTS content_status CASCADE;
        CREATE TYPE content_status AS ENUM ('draft', 'published', 'archived');
END $$;

-- Operation type for audit tracking
DO $$ BEGIN
    CREATE TYPE operation_type AS ENUM ('create', 'update', 'delete', 'auto_save');
EXCEPTION
    WHEN duplicate_object THEN
        DROP TYPE IF EXISTS operation_type CASCADE;
        CREATE TYPE operation_type AS ENUM ('create', 'update', 'delete', 'auto_save');
END $$;

-- =============================================================================
-- PHASE 2: CORE TABLES
-- =============================================================================

-- Enhanced content_items table (unified)
DROP TABLE IF EXISTS content_items_new CASCADE;
CREATE TABLE content_items_new (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
    repository_type repository_type NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    content JSONB NOT NULL DEFAULT '{}',
    metadata JSONB NOT NULL DEFAULT '{}',
    status content_status DEFAULT 'draft',
    folder_id UUID REFERENCES folders(id) ON DELETE SET NULL,
    thumbnail_url TEXT,
    
    -- Audit fields
    created_by UUID NOT NULL,
    updated_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    version INTEGER DEFAULT 1,
    
    -- Additional metadata for specific content types
    estimated_duration_minutes INTEGER,
    difficulty_level VARCHAR(20) CHECK (difficulty_level IN ('beginner', 'intermediate', 'advanced')),
    tags TEXT[] DEFAULT '{}',
    
    -- Constraints
    CONSTRAINT content_title_length CHECK (char_length(title) >= 1 AND char_length(title) <= 255),
    CONSTRAINT content_description_length CHECK (char_length(description) <= 5000),
    CONSTRAINT content_version_positive CHECK (version > 0)
);

-- Content history for versioning and audit
DROP TABLE IF EXISTS content_history CASCADE;
CREATE TABLE content_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_id UUID NOT NULL REFERENCES content_items_new(id) ON DELETE CASCADE,
    version INTEGER NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    content JSONB NOT NULL,
    metadata JSONB NOT NULL DEFAULT '{}',
    status content_status NOT NULL,
    operation_type operation_type NOT NULL,
    created_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(content_id, version)
);

-- Auto-save snapshots for recovery
DROP TABLE IF EXISTS auto_save_snapshots CASCADE;
CREATE TABLE auto_save_snapshots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_id UUID NOT NULL REFERENCES content_items_new(id) ON DELETE CASCADE,
    session_id VARCHAR(255) NOT NULL,
    content JSONB NOT NULL,
    metadata JSONB NOT NULL DEFAULT '{}',
    created_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Index for cleanup operations
    CONSTRAINT unique_session_content UNIQUE(content_id, session_id)
);;