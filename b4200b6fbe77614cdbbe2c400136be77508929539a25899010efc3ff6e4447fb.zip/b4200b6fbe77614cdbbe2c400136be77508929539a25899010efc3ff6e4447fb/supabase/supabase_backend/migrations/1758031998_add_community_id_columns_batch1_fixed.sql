-- Migration: add_community_id_columns_batch1_fixed
-- Created at: 1758031998

-- Add community_id columns to core tables (batch 1) - excluding views
ALTER TABLE users ADD COLUMN community_id UUID;
ALTER TABLE user_activities ADD COLUMN community_id UUID;
ALTER TABLE user_tags ADD COLUMN community_id UUID;
ALTER TABLE courses ADD COLUMN community_id UUID;
ALTER TABLE wods ADD COLUMN community_id UUID;
ALTER TABLE programs ADD COLUMN community_id UUID;
ALTER TABLE bulk_uploads ADD COLUMN community_id UUID;

-- Copy data from client_id to community_id columns
UPDATE users SET community_id = client_id;
UPDATE user_activities SET community_id = client_id;
UPDATE user_tags SET community_id = client_id;
UPDATE courses SET community_id = client_id;
UPDATE wods SET community_id = client_id;
UPDATE programs SET community_id = client_id;
UPDATE bulk_uploads SET community_id = client_id;;