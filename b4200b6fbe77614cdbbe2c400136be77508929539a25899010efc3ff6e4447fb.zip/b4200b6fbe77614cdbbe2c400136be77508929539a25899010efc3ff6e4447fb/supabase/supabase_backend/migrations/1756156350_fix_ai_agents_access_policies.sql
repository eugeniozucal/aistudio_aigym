-- Migration: fix_ai_agents_access_policies
-- Created at: 1756156350

-- Ensure proper RLS policies for ai_agents and content_items tables

-- Drop existing policies and recreate them with better structure
DROP POLICY IF EXISTS "Admin full access to content_items" ON content_items;
DROP POLICY IF EXISTS "Admin full access to ai_agents" ON ai_agents;

-- Create comprehensive policies for content_items
CREATE POLICY "Admins can view content_items"
ON content_items
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admins 
    WHERE admins.id = auth.uid()
  )
);

CREATE POLICY "Admins can manage content_items"
ON content_items
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admins 
    WHERE admins.id = auth.uid()
  )
);

CREATE POLICY "Service role full access to content_items"
ON content_items
FOR ALL
TO service_role
USING (true);

-- Create comprehensive policies for ai_agents
CREATE POLICY "Admins can view ai_agents"
ON ai_agents
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admins 
    WHERE admins.id = auth.uid()
  )
);

CREATE POLICY "Admins can manage ai_agents"
ON ai_agents
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admins 
    WHERE admins.id = auth.uid()
  )
);

CREATE POLICY "Service role full access to ai_agents"
ON ai_agents
FOR ALL
TO service_role
USING (true);;