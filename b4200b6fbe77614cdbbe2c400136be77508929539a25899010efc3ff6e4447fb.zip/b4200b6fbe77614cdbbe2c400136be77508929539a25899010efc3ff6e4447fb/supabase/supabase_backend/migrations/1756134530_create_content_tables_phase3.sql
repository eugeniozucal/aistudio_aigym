-- Migration: create_content_tables_phase3
-- Created at: 1756134530

-- Create trigger function if it doesn't exist
CREATE OR REPLACE FUNCTION trigger_set_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Videos table
CREATE TABLE IF NOT EXISTS videos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_item_id UUID NOT NULL,
    video_url TEXT NOT NULL,
    video_platform TEXT,
    video_id TEXT,
    duration_seconds INTEGER,
    transcription TEXT,
    auto_title TEXT,
    auto_description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Documents table
CREATE TABLE IF NOT EXISTS documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_item_id UUID NOT NULL,
    content_html TEXT NOT NULL,
    content_json JSONB,
    word_count INTEGER DEFAULT 0,
    reading_time_minutes INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Prompts table
CREATE TABLE IF NOT EXISTS prompts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_item_id UUID NOT NULL,
    prompt_text TEXT NOT NULL,
    prompt_category TEXT,
    usage_count INTEGER DEFAULT 0,
    last_copied_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Automations table
CREATE TABLE IF NOT EXISTS automations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_item_id UUID NOT NULL,
    automation_url TEXT NOT NULL,
    required_tools TEXT[] DEFAULT '{}',
    tool_description TEXT,
    setup_instructions TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Assignment tables
CREATE TABLE IF NOT EXISTS content_client_assignments (
    content_item_id UUID NOT NULL,
    client_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (content_item_id, client_id)
);

CREATE TABLE IF NOT EXISTS content_user_assignments (
    content_item_id UUID NOT NULL,
    user_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (content_item_id, user_id)
);

CREATE TABLE IF NOT EXISTS content_tag_assignments (
    content_item_id UUID NOT NULL,
    tag_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (content_item_id, tag_id)
);

-- Enable RLS
ALTER TABLE videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE prompts ENABLE ROW LEVEL SECURITY;
ALTER TABLE automations ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_client_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_user_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_tag_assignments ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Admins can manage videos" ON videos FOR ALL USING (true);
CREATE POLICY "Admins can manage documents" ON documents FOR ALL USING (true);
CREATE POLICY "Admins can manage prompts" ON prompts FOR ALL USING (true);
CREATE POLICY "Admins can manage automations" ON automations FOR ALL USING (true);
CREATE POLICY "Admins can manage client assignments" ON content_client_assignments FOR ALL USING (true);
CREATE POLICY "Admins can manage user assignments" ON content_user_assignments FOR ALL USING (true);
CREATE POLICY "Admins can manage tag assignments" ON content_tag_assignments FOR ALL USING (true);

-- Triggers for updated_at
DROP TRIGGER IF EXISTS set_videos_timestamp ON videos;
CREATE TRIGGER set_videos_timestamp
    BEFORE UPDATE ON videos
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();

DROP TRIGGER IF EXISTS set_documents_timestamp ON documents;
CREATE TRIGGER set_documents_timestamp
    BEFORE UPDATE ON documents
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();

DROP TRIGGER IF EXISTS set_prompts_timestamp ON prompts;
CREATE TRIGGER set_prompts_timestamp
    BEFORE UPDATE ON prompts
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();

DROP TRIGGER IF EXISTS set_automations_timestamp ON automations;
CREATE TRIGGER set_automations_timestamp
    BEFORE UPDATE ON automations
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();;