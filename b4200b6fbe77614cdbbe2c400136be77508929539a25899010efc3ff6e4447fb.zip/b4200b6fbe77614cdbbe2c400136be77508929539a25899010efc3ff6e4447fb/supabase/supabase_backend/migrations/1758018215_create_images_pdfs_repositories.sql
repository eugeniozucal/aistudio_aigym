-- Migration: create_images_pdfs_repositories
-- Created at: 1758018215

-- Fix content_items table to include image and pdf types
ALTER TABLE content_items DROP CONSTRAINT IF EXISTS content_items_content_type_check;
ALTER TABLE content_items ADD CONSTRAINT content_items_content_type_check 
  CHECK (content_type IN ('ai_agent', 'video', 'document', 'prompt', 'automation', 'image', 'pdf'));

-- Create images table following established pattern
CREATE TABLE IF NOT EXISTS images (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_item_id UUID NOT NULL REFERENCES content_items(id) ON DELETE CASCADE,
    image_url TEXT NOT NULL,
    file_size BIGINT,
    mime_type TEXT,
    alt_text TEXT,
    width INTEGER,
    height INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create pdfs table following established pattern  
CREATE TABLE IF NOT EXISTS pdfs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_item_id UUID NOT NULL REFERENCES content_items(id) ON DELETE CASCADE,
    pdf_url TEXT NOT NULL,
    file_size BIGINT,
    page_count INTEGER,
    thumbnail_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE images ENABLE ROW LEVEL SECURITY;
ALTER TABLE pdfs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for Images
CREATE POLICY "Admins can manage images" ON images FOR ALL USING (auth.role() = 'authenticated');

-- RLS Policies for PDFs
CREATE POLICY "Admins can manage pdfs" ON pdfs FOR ALL USING (auth.role() = 'authenticated');

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_images_content_item_id ON images(content_item_id);
CREATE INDEX IF NOT EXISTS idx_images_created_at ON images(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_pdfs_content_item_id ON pdfs(content_item_id);
CREATE INDEX IF NOT EXISTS idx_pdfs_created_at ON pdfs(created_at DESC);

-- Create trigger functions for updated_at
CREATE OR REPLACE FUNCTION trigger_set_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add triggers for updated_at
CREATE TRIGGER set_images_timestamp
    BEFORE UPDATE ON images
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();

CREATE TRIGGER set_pdfs_timestamp
    BEFORE UPDATE ON pdfs
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();;