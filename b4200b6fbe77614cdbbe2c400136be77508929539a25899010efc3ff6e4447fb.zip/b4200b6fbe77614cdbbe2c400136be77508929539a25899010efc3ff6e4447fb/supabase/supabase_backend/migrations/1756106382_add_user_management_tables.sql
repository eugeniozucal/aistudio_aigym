-- Migration: add_user_management_tables
-- Created at: 1756106382

-- Create user_tags table for tag management
CREATE TABLE IF NOT EXISTS public.user_tags (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    color VARCHAR(7) NOT NULL DEFAULT '#3B82F6',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(client_id, name)
);

-- Create user_tag_assignments table for many-to-many relationship
CREATE TABLE IF NOT EXISTS public.user_tag_assignments (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    tag_id UUID NOT NULL REFERENCES public.user_tags(id) ON DELETE CASCADE,
    assigned_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, tag_id)
);

-- Create bulk_uploads table for tracking CSV uploads
CREATE TABLE IF NOT EXISTS public.bulk_uploads (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
    upload_type VARCHAR(50) NOT NULL DEFAULT 'users',
    file_name VARCHAR(255),
    total_rows INTEGER NOT NULL DEFAULT 0,
    successful_rows INTEGER NOT NULL DEFAULT 0,
    failed_rows INTEGER NOT NULL DEFAULT 0,
    status VARCHAR(50) NOT NULL DEFAULT 'processing',
    error_report JSONB,
    created_by UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_user_tags_client_id ON public.user_tags(client_id);
CREATE INDEX IF NOT EXISTS idx_user_tag_assignments_user_id ON public.user_tag_assignments(user_id);
CREATE INDEX IF NOT EXISTS idx_user_tag_assignments_tag_id ON public.user_tag_assignments(tag_id);
CREATE INDEX IF NOT EXISTS idx_bulk_uploads_client_id ON public.bulk_uploads(client_id);
CREATE INDEX IF NOT EXISTS idx_bulk_uploads_status ON public.bulk_uploads(status);

-- Create RLS policies
ALTER TABLE public.user_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_tag_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bulk_uploads ENABLE ROW LEVEL SECURITY;

-- RLS policies for user_tags
CREATE POLICY "Users can view client tags" ON public.user_tags
    FOR SELECT USING (true);

CREATE POLICY "Admins can manage client tags" ON public.user_tags
    FOR ALL USING (true);

-- RLS policies for user_tag_assignments
CREATE POLICY "Users can view tag assignments" ON public.user_tag_assignments
    FOR SELECT USING (true);

CREATE POLICY "Admins can manage tag assignments" ON public.user_tag_assignments
    FOR ALL USING (true);

-- RLS policies for bulk_uploads
CREATE POLICY "Admins can view bulk uploads" ON public.bulk_uploads
    FOR SELECT USING (true);

CREATE POLICY "Admins can manage bulk uploads" ON public.bulk_uploads
    FOR ALL USING (true);;