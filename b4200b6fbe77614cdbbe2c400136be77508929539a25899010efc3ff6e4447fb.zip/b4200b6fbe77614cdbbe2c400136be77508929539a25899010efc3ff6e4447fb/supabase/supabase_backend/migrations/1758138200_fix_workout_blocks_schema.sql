-- Migration: fix_workout_blocks_schema
-- Created at: 1758138200

-- Phase 2.1: Reconcile Database Schemas
-- Fix workout_blocks table created_by field to be UUID instead of TEXT

-- First, backup any existing data with text created_by values
CREATE TABLE IF NOT EXISTS workout_blocks_backup AS 
SELECT * FROM workout_blocks WHERE created_by IS NOT NULL;

-- Drop the conflicting blocks table that was causing conflicts
DROP TABLE IF EXISTS blocks CASCADE;

-- Alter workout_blocks table to fix created_by field
ALTER TABLE workout_blocks 
ALTER COLUMN created_by TYPE UUID USING 
  CASE 
    -- If it's already a valid UUID, keep it
    WHEN created_by ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' 
    THEN created_by::UUID
    -- If it's the admin email, convert to the known admin UUID
    WHEN created_by = 'admin@ai-gym.com' 
    THEN '84ee8814-0acd-48f6-a7ca-b6ec935b0d5e'::UUID
    -- For any other text values, set to the admin UUID as fallback
    ELSE '84ee8814-0acd-48f6-a7ca-b6ec935b0d5e'::UUID
  END;

-- Add foreign key constraint to reference auth.users
ALTER TABLE workout_blocks 
ADD CONSTRAINT workout_blocks_created_by_fkey 
FOREIGN KEY (created_by) REFERENCES auth.users(id) ON DELETE SET NULL;

-- Add columns needed for Page Builder functionality if they don't exist
ALTER TABLE workout_blocks 
ADD COLUMN IF NOT EXISTS pages JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS settings JSONB DEFAULT '{}'::jsonb;

-- Add same columns to wods table for consistency
ALTER TABLE wods 
ADD COLUMN IF NOT EXISTS pages JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS settings JSONB DEFAULT '{}'::jsonb;

-- Add useful indexes for performance
CREATE INDEX IF NOT EXISTS idx_workout_blocks_created_by ON workout_blocks(created_by);
CREATE INDEX IF NOT EXISTS idx_workout_blocks_status ON workout_blocks(status);
CREATE INDEX IF NOT EXISTS idx_workout_blocks_pages ON workout_blocks USING GIN (pages);
CREATE INDEX IF NOT EXISTS idx_wods_created_by ON wods(created_by);
CREATE INDEX IF NOT EXISTS idx_wods_status ON wods(status);
CREATE INDEX IF NOT EXISTS idx_wods_pages ON wods USING GIN (pages);;