-- Migration: create_page_builder_tables
-- Created at: 1756406377

-- Phase 5: Page Builder Engine - Database Schema
-- Missions table for learning missions
CREATE TABLE missions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    thumbnail_url TEXT,
    status TEXT NOT NULL CHECK (status IN ('draft', 'published', 'archived')) DEFAULT 'draft',
    estimated_duration_minutes INTEGER,
    difficulty_level TEXT CHECK (difficulty_level IN ('beginner', 'intermediate', 'advanced')),
    tags TEXT[] DEFAULT '{}',
    created_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Courses table for learning courses
CREATE TABLE courses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    thumbnail_url TEXT,
    status TEXT NOT NULL CHECK (status IN ('draft', 'published', 'archived')) DEFAULT 'draft',
    estimated_duration_minutes INTEGER,
    difficulty_level TEXT CHECK (difficulty_level IN ('beginner', 'intermediate', 'advanced')),
    tags TEXT[] DEFAULT '{}',
    prerequisite_course_ids UUID[] DEFAULT '{}',
    created_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Pages table for individual pages within missions/courses
CREATE TABLE pages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    mission_id UUID,
    course_id UUID,
    order_index INTEGER NOT NULL DEFAULT 0,
    is_locked BOOLEAN DEFAULT false,
    unlock_conditions JSONB DEFAULT '{}',
    page_config JSONB DEFAULT '{}', -- Global page settings
    status TEXT NOT NULL CHECK (status IN ('draft', 'published', 'archived')) DEFAULT 'draft',
    created_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Ensure page belongs to either mission or course, not both
    CONSTRAINT check_page_parent CHECK (
        (mission_id IS NOT NULL AND course_id IS NULL) OR
        (mission_id IS NULL AND course_id IS NOT NULL)
    )
);

-- Blocks table for page content blocks
CREATE TABLE blocks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    page_id UUID NOT NULL,
    block_type TEXT NOT NULL CHECK (block_type IN (
        -- Foundational blocks
        'section_header',
        'rich_text', 
        'image',
        'list',
        'quote',
        'divider',
        -- Embedded content blocks
        'video',
        'agent',
        'document', 
        'prompt',
        'automations_content',
        -- Interactive blocks
        'quiz',
        'user_submission',
        'accordion'
    )),
    order_index INTEGER NOT NULL DEFAULT 0,
    config JSONB NOT NULL DEFAULT '{}', -- Block-specific configuration
    style JSONB DEFAULT '{}', -- Styling configuration
    content JSONB NOT NULL DEFAULT '{}', -- Block content data
    visibility_conditions JSONB DEFAULT '{}', -- Conditional display logic
    is_visible BOOLEAN DEFAULT true,
    created_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);;