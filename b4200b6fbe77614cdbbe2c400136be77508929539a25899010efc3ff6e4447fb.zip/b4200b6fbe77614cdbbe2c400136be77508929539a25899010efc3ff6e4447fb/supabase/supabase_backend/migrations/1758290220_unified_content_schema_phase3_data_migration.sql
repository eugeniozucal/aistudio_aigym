-- Migration: unified_content_schema_phase3_data_migration
-- Created at: 1758290220

-- Migration: Unified Content Schema Phase 3 - Data Migration
-- Description: Migrate existing data to unified schema

-- =============================================================================
-- PHASE 5: DATA MIGRATION
-- =============================================================================

-- Get default workspace ID
DO $$
DECLARE
    default_workspace UUID;
    default_user UUID;
BEGIN
    -- Get workspace and user IDs
    SELECT id INTO default_workspace FROM workspaces LIMIT 1;
    SELECT id INTO default_user FROM users LIMIT 1;
    
    -- Migrate from missions table (WODs) if it exists
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'missions') THEN
        INSERT INTO content_items_unified (
            id, workspace_id, repository_type, title, description, status, 
            created_by, updated_by, created_at, updated_at, thumbnail_url,
            estimated_duration_minutes, difficulty_level, tags, content, metadata
        )
        SELECT 
            id,
            default_workspace,
            'wods'::repository_type,
            title,
            description,
            status::content_status,
            COALESCE(created_by, default_user),
            COALESCE(created_by, default_user),
            created_at,
            updated_at,
            thumbnail_url,
            estimated_duration_minutes,
            difficulty_level,
            COALESCE(tags, '{}'),
            '{}'::jsonb, -- Empty content for now
            '{}'::jsonb   -- Empty metadata for now
        FROM missions
        ON CONFLICT (id) DO NOTHING;
    END IF;

    -- Migrate from workout_blocks table if it exists
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'workout_blocks') THEN
        INSERT INTO content_items_unified (
            id, workspace_id, repository_type, title, description, status,
            created_by, updated_by, created_at, updated_at, thumbnail_url,
            estimated_duration_minutes, difficulty_level, tags, content, metadata
        )
        SELECT 
            id,
            default_workspace,
            'blocks'::repository_type,
            title,
            description,
            CASE 
                WHEN status = 'draft' THEN 'draft'::content_status
                WHEN status = 'published' THEN 'published'::content_status
                WHEN status = 'archived' THEN 'archived'::content_status
                ELSE 'draft'::content_status
            END,
            default_user,
            default_user,
            created_at,
            updated_at,
            thumbnail_url,
            estimated_duration_minutes,
            difficulty_level,
            COALESCE(tags, '{}'),
            jsonb_build_object(
                'instructions', COALESCE(instructions, ''),
                'equipment_needed', COALESCE(equipment_needed, '{}'),
                'block_category', COALESCE(block_category, 'general')
            ),
            '{}'::jsonb
        FROM workout_blocks
        ON CONFLICT (id) DO NOTHING;
    END IF;

    -- Migrate from existing content_items table if it exists
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'content_items') THEN
        INSERT INTO content_items_unified (
            id, workspace_id, repository_type, title, description, status,
            created_by, updated_by, created_at, updated_at, thumbnail_url, content, metadata
        )
        SELECT 
            id,
            default_workspace,
            CASE 
                WHEN content_type = 'ai_agent' THEN 'ai_agents'::repository_type
                WHEN content_type = 'video' THEN 'videos'::repository_type
                WHEN content_type = 'document' THEN 'documents'::repository_type
                WHEN content_type = 'prompt' THEN 'prompts'::repository_type
                WHEN content_type = 'automation' THEN 'automations'::repository_type
                ELSE 'documents'::repository_type
            END,
            title,
            description,
            CASE 
                WHEN status = 'draft' THEN 'draft'::content_status
                WHEN status = 'published' THEN 'published'::content_status
                ELSE 'draft'::content_status
            END,
            COALESCE(created_by, default_user),
            COALESCE(created_by, default_user),
            created_at,
            updated_at,
            thumbnail_url,
            '{}'::jsonb,
            jsonb_build_object('original_content_type', content_type)
        FROM content_items
        ON CONFLICT (id) DO NOTHING;
    END IF;
    
END $$;;