-- Migration: create_page_builder_rls_and_indexes
-- Created at: 1756406422

-- RLS policies for all page builder tables
ALTER TABLE missions ENABLE ROW LEVEL SECURITY;
ALTER TABLE courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE blocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE mission_client_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE mission_user_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE mission_tag_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_client_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_user_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_tag_assignments ENABLE ROW LEVEL SECURITY;

-- Policies for authenticated users (admins can manage all)
CREATE POLICY "Admins can manage missions" ON missions FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage courses" ON courses FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage pages" ON pages FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage blocks" ON blocks FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Users can manage their own progress" ON user_progress 
    FOR ALL USING (
        auth.role() = 'authenticated' AND 
        (auth.uid() = user_id OR auth.role() = 'service_role')
    );
CREATE POLICY "Admins can manage mission client assignments" ON mission_client_assignments FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage mission user assignments" ON mission_user_assignments FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage mission tag assignments" ON mission_tag_assignments FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage course client assignments" ON course_client_assignments FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage course user assignments" ON course_user_assignments FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage course tag assignments" ON course_tag_assignments FOR ALL USING (auth.role() = 'authenticated');

-- Performance indexes
CREATE INDEX idx_pages_mission_id ON pages(mission_id);
CREATE INDEX idx_pages_course_id ON pages(course_id);
CREATE INDEX idx_pages_order_index ON pages(order_index);
CREATE INDEX idx_blocks_page_id ON blocks(page_id);
CREATE INDEX idx_blocks_type ON blocks(block_type);
CREATE INDEX idx_blocks_order ON blocks(page_id, order_index);
CREATE INDEX idx_blocks_visibility ON blocks(page_id, is_visible);
CREATE INDEX idx_user_progress_user_id ON user_progress(user_id);
CREATE INDEX idx_user_progress_mission_id ON user_progress(mission_id);
CREATE INDEX idx_user_progress_course_id ON user_progress(course_id);
CREATE INDEX idx_user_progress_page_id ON user_progress(page_id);
CREATE INDEX idx_user_progress_type ON user_progress(progress_type);

-- Triggers for updated_at timestamps
CREATE TRIGGER set_missions_timestamp
    BEFORE UPDATE ON missions
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();

CREATE TRIGGER set_courses_timestamp
    BEFORE UPDATE ON courses
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();

CREATE TRIGGER set_pages_timestamp
    BEFORE UPDATE ON pages
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();

CREATE TRIGGER set_blocks_timestamp
    BEFORE UPDATE ON blocks
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();

CREATE TRIGGER set_user_progress_timestamp
    BEFORE UPDATE ON user_progress
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_timestamp();;