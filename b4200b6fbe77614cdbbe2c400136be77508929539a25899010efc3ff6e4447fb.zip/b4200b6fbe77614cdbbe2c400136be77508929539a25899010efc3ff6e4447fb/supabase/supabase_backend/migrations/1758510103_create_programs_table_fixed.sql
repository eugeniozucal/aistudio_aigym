-- Migration: create_programs_table_fixed
-- Created at: 1758510103

-- Create programs table for hierarchical training programs
CREATE TABLE IF NOT EXISTS programs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
    difficulty_level VARCHAR(20) DEFAULT 'beginner' CHECK (difficulty_level IN ('beginner', 'intermediate', 'advanced')),
    estimated_duration_weeks INTEGER DEFAULT 8,
    program_type VARCHAR(30) DEFAULT 'strength' CHECK (program_type IN ('strength', 'cardio', 'weight-loss', 'muscle-gain', 'endurance', 'flexibility')),
    tags TEXT[],
    sections JSONB DEFAULT '[]'::jsonb,
    settings JSONB DEFAULT '{}'::jsonb,
    thumbnail_url TEXT,
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_programs_status ON programs(status);
CREATE INDEX IF NOT EXISTS idx_programs_difficulty ON programs(difficulty_level);
CREATE INDEX IF NOT EXISTS idx_programs_type ON programs(program_type);
CREATE INDEX IF NOT EXISTS idx_programs_created_by ON programs(created_by);
CREATE INDEX IF NOT EXISTS idx_programs_created_at ON programs(created_at);
CREATE INDEX IF NOT EXISTS idx_programs_updated_at ON programs(updated_at);

-- Create RLS policies
ALTER TABLE programs ENABLE ROW LEVEL SECURITY;

-- Policy for authenticated users to read published programs
CREATE POLICY "Users can view published programs" ON programs
    FOR SELECT
    USING (status = 'published');

-- Policy for program creators to manage their own programs
CREATE POLICY "Users can manage their own programs" ON programs
    FOR ALL
    USING (auth.uid() = created_by);

-- Policy for admins to manage all programs (using auth.email())
CREATE POLICY "Admins can manage all programs" ON programs
    FOR ALL
    USING (
        EXISTS (
            SELECT 1 FROM admins 
            WHERE email = auth.email()
        )
    );

-- Update trigger for updated_at
CREATE OR REPLACE FUNCTION update_programs_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_programs_updated_at
    BEFORE UPDATE ON programs
    FOR EACH ROW
    EXECUTE FUNCTION update_programs_updated_at();;