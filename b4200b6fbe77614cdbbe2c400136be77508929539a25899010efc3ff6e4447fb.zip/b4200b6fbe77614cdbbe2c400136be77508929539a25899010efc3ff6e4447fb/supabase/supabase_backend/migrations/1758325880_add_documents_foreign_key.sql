-- Migration: add_documents_foreign_key
-- Created at: 1758325880

-- Add missing foreign key constraint for documents table
ALTER TABLE documents
ADD CONSTRAINT documents_content_item_id_fkey 
FOREIGN KEY (content_item_id) 
REFERENCES content_items(id) 
ON DELETE CASCADE;;