-- Migration: add_community_foreign_key_constraints_batch4
-- Created at: 1758032165

-- Add foreign key constraints for community_id columns (batch 4) - final batch
-- Optional relationships
ALTER TABLE course_milestones 
  ADD CONSTRAINT course_milestones_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE SET NULL;

ALTER TABLE program_courses 
  ADD CONSTRAINT program_courses_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE SET NULL;

ALTER TABLE program_milestones 
  ADD CONSTRAINT program_milestones_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE SET NULL;

ALTER TABLE user_courses 
  ADD CONSTRAINT user_courses_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE SET NULL;

ALTER TABLE user_progress 
  ADD CONSTRAINT user_progress_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE SET NULL;

ALTER TABLE user_wods 
  ADD CONSTRAINT user_wods_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE SET NULL;

-- Mandatory relationships
ALTER TABLE user_achievements 
  ALTER COLUMN community_id SET NOT NULL,
  ADD CONSTRAINT user_achievements_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE CASCADE;

ALTER TABLE user_daily_activity 
  ALTER COLUMN community_id SET NOT NULL,
  ADD CONSTRAINT user_daily_activity_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE CASCADE;

ALTER TABLE user_milestone_progress 
  ALTER COLUMN community_id SET NOT NULL,
  ADD CONSTRAINT user_milestone_progress_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE CASCADE;

ALTER TABLE user_streaks 
  ALTER COLUMN community_id SET NOT NULL,
  ADD CONSTRAINT user_streaks_community_id_fkey FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE CASCADE;;