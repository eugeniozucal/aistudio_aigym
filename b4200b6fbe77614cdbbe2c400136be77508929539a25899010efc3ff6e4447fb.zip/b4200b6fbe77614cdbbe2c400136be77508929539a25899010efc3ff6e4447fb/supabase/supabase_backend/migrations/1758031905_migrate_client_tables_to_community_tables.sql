-- Migration: migrate_client_tables_to_community_tables
-- Created at: 1758031905

-- Migrate client_api_assignments to community_api_assignments
INSERT INTO community_api_assignments (community_id, api_key_id, created_at)
SELECT client_id, api_key_id, created_at FROM client_api_assignments;

-- Migrate client_features to community_features
INSERT INTO community_features (id, community_id, feature_name, enabled, config, created_at)
SELECT id, client_id, feature_name, enabled, config, created_at FROM client_features;

-- Migrate content_client_assignments to content_community_assignments
INSERT INTO content_community_assignments (id, community_id, content_id, created_at)
SELECT id, client_id, content_id, created_at FROM content_client_assignments;

-- Migrate course_client_assignments to course_community_assignments  
INSERT INTO course_community_assignments (id, community_id, course_id, created_at)
SELECT id, client_id, course_id, created_at FROM course_client_assignments;

-- Migrate wod_client_assignments to wod_community_assignments
INSERT INTO wod_community_assignments (id, community_id, wod_id, created_at)
SELECT id, client_id, wod_id, created_at FROM wod_client_assignments;;