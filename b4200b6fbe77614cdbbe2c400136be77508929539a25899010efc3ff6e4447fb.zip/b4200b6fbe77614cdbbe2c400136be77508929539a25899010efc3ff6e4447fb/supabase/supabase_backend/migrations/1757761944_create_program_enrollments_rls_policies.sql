-- Migration: create_program_enrollments_rls_policies
-- Created at: 1757761944

-- Enable RLS on program_enrollments table
ALTER TABLE program_enrollments ENABLE ROW LEVEL SECURITY;

-- Program enrollments policies
CREATE POLICY program_enrollments_select_policy ON program_enrollments
    FOR SELECT USING (
        -- Users can see their own enrollments
        user_id = auth.uid()
        OR
        -- Program creators and instructors can see all enrollments for their programs
        EXISTS (
            SELECT 1 FROM programs p 
            WHERE p.id = program_id 
            AND (p.created_by = auth.uid() OR auth.uid() = ANY(p.instructor_ids))
        )
        OR
        -- Client admin access within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = auth.uid() 
                AND u.client_id = program_enrollments.client_id
            )
        )
    );

CREATE POLICY program_enrollments_insert_policy ON program_enrollments
    FOR INSERT WITH CHECK (
        -- Users can enroll themselves
        user_id = auth.uid()
        OR
        -- Program creators and instructors can enroll users
        EXISTS (
            SELECT 1 FROM programs p 
            WHERE p.id = program_id 
            AND (p.created_by = auth.uid() OR auth.uid() = ANY(p.instructor_ids))
        )
        OR
        -- Client admin can enroll users within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = user_id 
                AND u.client_id = program_enrollments.client_id
            )
        )
    );

CREATE POLICY program_enrollments_update_policy ON program_enrollments
    FOR UPDATE USING (
        -- Users can update their own enrollment progress
        user_id = auth.uid()
        OR
        -- Program creators and instructors can update enrollments
        EXISTS (
            SELECT 1 FROM programs p 
            WHERE p.id = program_id 
            AND (p.created_by = auth.uid() OR auth.uid() = ANY(p.instructor_ids))
        )
        OR
        -- Client admin access within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = auth.uid() 
                AND u.client_id = program_enrollments.client_id
            )
        )
    ) WITH CHECK (
        -- Same conditions for WITH CHECK
        user_id = auth.uid()
        OR
        EXISTS (
            SELECT 1 FROM programs p 
            WHERE p.id = program_id 
            AND (p.created_by = auth.uid() OR auth.uid() = ANY(p.instructor_ids))
        )
        OR
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = user_id 
                AND u.client_id = program_enrollments.client_id
            )
        )
    );

CREATE POLICY program_enrollments_delete_policy ON program_enrollments
    FOR DELETE USING (
        -- Users can withdraw from their own programs
        user_id = auth.uid()
        OR
        -- Program creators and instructors can remove enrollments
        EXISTS (
            SELECT 1 FROM programs p 
            WHERE p.id = program_id 
            AND (p.created_by = auth.uid() OR auth.uid() = ANY(p.instructor_ids))
        )
        OR
        -- Client admin can remove enrollments within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = auth.uid() 
                AND u.client_id = program_enrollments.client_id
            )
        )
    );;