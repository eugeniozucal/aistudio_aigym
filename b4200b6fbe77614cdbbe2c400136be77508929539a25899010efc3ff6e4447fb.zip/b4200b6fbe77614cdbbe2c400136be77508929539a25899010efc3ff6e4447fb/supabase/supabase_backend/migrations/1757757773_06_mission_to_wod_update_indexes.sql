-- Migration: 06_mission_to_wod_update_indexes
-- Created at: 1757757773

-- Step 6: Update all indexes to reflect new table and column names

BEGIN;

-- Update indexes on the wods table (formerly missions)
ALTER INDEX missions_pkey RENAME TO wods_pkey;
ALTER INDEX idx_missions_category_id RENAME TO idx_wods_category_id;
ALTER INDEX idx_missions_client_id RENAME TO idx_wods_client_id;
ALTER INDEX idx_missions_created_by RENAME TO idx_wods_created_by;
ALTER INDEX idx_missions_published RENAME TO idx_wods_published;

-- Update pages table indexes
ALTER INDEX idx_pages_mission_id RENAME TO idx_pages_wod_id;

-- Update user_progress indexes - remove mission-related ones and ensure wod ones exist
DROP INDEX IF EXISTS idx_user_progress_mission_id;
DROP INDEX IF EXISTS idx_progress_user_mission;

-- Ensure wod index exists (it should already)
CREATE INDEX IF NOT EXISTS idx_user_progress_wod_id ON user_progress(wod_id);

-- Update assignment table indexes
ALTER INDEX mission_client_assignments_pkey RENAME TO wod_client_assignments_pkey;
ALTER INDEX mission_tag_assignments_pkey RENAME TO wod_tag_assignments_pkey;
ALTER INDEX mission_user_assignments_pkey RENAME TO wod_user_assignments_pkey;

COMMIT;;