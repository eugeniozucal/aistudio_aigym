-- Migration: create_page_builder_progress_and_assignments
-- Created at: 1756406393

-- Progress tracking for user progress through missions and courses
CREATE TABLE user_progress (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,
    mission_id UUID,
    course_id UUID,
    page_id UUID,
    block_id UUID,
    progress_type TEXT NOT NULL CHECK (progress_type IN (
        'page_started',
        'page_completed', 
        'block_interacted',
        'quiz_attempted',
        'quiz_completed',
        'submission_made',
        'mission_completed',
        'course_completed'
    )),
    progress_data JSONB DEFAULT '{}', -- Additional progress data
    completion_percentage DECIMAL(5,2) DEFAULT 0.00,
    time_spent_seconds INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Ensure progress belongs to appropriate parent
    CONSTRAINT check_progress_parent CHECK (
        (mission_id IS NOT NULL OR course_id IS NOT NULL)
    )
);

-- Assignment tables for missions and courses to clients/users/tags
CREATE TABLE mission_client_assignments (
    mission_id UUID NOT NULL,
    client_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (mission_id, client_id)
);

CREATE TABLE mission_user_assignments (
    mission_id UUID NOT NULL,
    user_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (mission_id, user_id)
);

CREATE TABLE mission_tag_assignments (
    mission_id UUID NOT NULL,
    tag_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (mission_id, tag_id)
);

CREATE TABLE course_client_assignments (
    course_id UUID NOT NULL,
    client_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (course_id, client_id)
);

CREATE TABLE course_user_assignments (
    course_id UUID NOT NULL,
    user_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (course_id, user_id)
);

CREATE TABLE course_tag_assignments (
    course_id UUID NOT NULL,
    tag_id UUID NOT NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID NOT NULL,
    PRIMARY KEY (course_id, tag_id)
);;