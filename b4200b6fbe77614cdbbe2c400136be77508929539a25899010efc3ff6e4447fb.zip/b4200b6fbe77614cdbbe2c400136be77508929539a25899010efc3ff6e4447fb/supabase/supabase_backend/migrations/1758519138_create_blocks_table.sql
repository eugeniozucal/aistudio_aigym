-- Migration: create_blocks_table
-- Created at: 1758519138

CREATE TABLE blocks (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  title text,
  description text,
  thumbnail_url text,
  status text,
  estimated_duration_minutes integer,
  difficulty_level text,
  tags text[],
  created_by uuid,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  category_id uuid,
  workout_type text,
  target_muscle_groups text[],
  equipment_needed text[],
  client_id uuid,
  wod_sequence jsonb,
  prerequisites jsonb,
  completion_criteria jsonb,
  is_published boolean DEFAULT false,
  community_id uuid,
  folder_id uuid,
  is_favorite boolean DEFAULT false,
  pages jsonb,
  settings jsonb
);;