-- Migration: fix_rls_policies
-- Created at: 1758138215

-- Phase 2.2: Fix Row Level Security (RLS) Policies
-- Remove dangerous and conflicting policies, implement secure ones

-- === Fix workout_blocks table policies ===

-- Drop the completely open policy (major security vulnerability)
DROP POLICY IF EXISTS "Allow all operations on workout_blocks" ON workout_blocks;

-- Drop all existing policies on workout_blocks to start clean
DROP POLICY IF EXISTS "Enable insert for authenticated users only" ON workout_blocks;
DROP POLICY IF EXISTS "Enable read access for all users" ON workout_blocks;
DROP POLICY IF EXISTS "Enable update for owners" ON workout_blocks;
DROP POLICY IF EXISTS "Enable delete for owners" ON workout_blocks;

-- Ensure RLS is enabled
ALTER TABLE workout_blocks ENABLE ROW LEVEL SECURITY;

-- Create secure policies for workout_blocks
-- Admins can manage all workout blocks
CREATE POLICY "Admins can manage workout_blocks" ON workout_blocks
    FOR ALL USING (EXISTS (SELECT 1 FROM admins WHERE id = auth.uid()));

-- Users can manage their own workout blocks
CREATE POLICY "Users can manage their own workout_blocks" ON workout_blocks
    FOR ALL USING (created_by = auth.uid());

-- Allow public read for published blocks
CREATE POLICY "Public can view published workout_blocks" ON workout_blocks
    FOR SELECT USING (status = 'published');

-- === Fix wods table policies ===

-- Drop duplicate and conflicting policies on wods
DROP POLICY IF EXISTS "Admins can manage wods" ON wods;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON wods;
DROP POLICY IF EXISTS "Enable insert for authenticated users only" ON wods;
DROP POLICY IF EXISTS "Enable read access for all users" ON wods;
DROP POLICY IF EXISTS "Enable update for creators" ON wods;
DROP POLICY IF EXISTS "Enable update for owners" ON wods;
DROP POLICY IF EXISTS "Public can view published wods" ON wods;

-- Keep only the admin policy and create proper user policies
-- Note: "Admin users can manage all wods" policy already exists and is correct

-- Users can manage their own wods
CREATE POLICY "Users can manage their own wods" ON wods
    FOR ALL USING (created_by = auth.uid());

-- Public can view published wods (unified policy)
CREATE POLICY "Public can view published wods" ON wods
    FOR SELECT USING (status = 'published' AND is_published = true);

-- Allow authenticated users to create new wods
CREATE POLICY "Authenticated users can create wods" ON wods
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- === Verify RLS is enabled on both tables ===
ALTER TABLE wods ENABLE ROW LEVEL SECURITY;
ALTER TABLE workout_blocks ENABLE ROW LEVEL SECURITY;;