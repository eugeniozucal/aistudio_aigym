-- Migration: create_achievements_rls_policies_fixed
-- Created at: 1757763111

-- Migration: create_achievements_rls_policies_fixed
-- Created at: 1757762110

-- Enable RLS on all achievement-related tables
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_milestones ENABLE ROW LEVEL SECURITY;
ALTER TABLE program_milestones ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_milestone_progress ENABLE ROW LEVEL SECURITY;

-- Achievements table policies
CREATE POLICY achievements_select_policy ON achievements
    FOR SELECT USING (
        -- Active achievements visible to all
        (status = 'active' AND is_hidden = false)
        OR
        -- Client-specific achievements visible to client members
        (client_id IS NOT NULL AND client_id IN (
            SELECT client_id FROM users WHERE id = auth.uid()
        ))
        OR
        -- Achievements visible to creators
        (created_by = auth.uid())
    );

CREATE POLICY achievements_insert_policy ON achievements
    FOR INSERT WITH CHECK (
        created_by = auth.uid()
        AND (
            client_id IS NULL 
            OR client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
        )
    );

CREATE POLICY achievements_update_policy ON achievements
    FOR UPDATE USING (
        created_by = auth.uid()
        OR (
            client_id IS NOT NULL 
            AND client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
        )
    ) WITH CHECK (
        created_by = auth.uid()
        OR (
            client_id IS NOT NULL 
            AND client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
        )
    );

CREATE POLICY achievements_delete_policy ON achievements
    FOR DELETE USING (
        created_by = auth.uid()
        OR (
            client_id IS NOT NULL 
            AND client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
        )
    );

-- User achievements table policies
CREATE POLICY user_achievements_select_policy ON user_achievements
    FOR SELECT USING (
        -- Users can see their own achievements
        user_id = auth.uid()
        OR
        -- Public achievements visible to same client members
        (is_public = true AND client_id IN (
            SELECT client_id FROM users WHERE id = auth.uid()
        ))
        OR
        -- Achievement creators can see all instances of their achievements
        EXISTS (
            SELECT 1 FROM achievements a 
            WHERE a.id = achievement_id AND a.created_by = auth.uid()
        )
        OR
        -- Client admin access within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = auth.uid() 
                AND u.client_id = user_achievements.client_id
            )
        )
    );

CREATE POLICY user_achievements_insert_policy ON user_achievements
    FOR INSERT WITH CHECK (
        -- Users can earn their own achievements
        user_id = auth.uid()
        OR
        -- Achievement creators can award their achievements
        EXISTS (
            SELECT 1 FROM achievements a 
            WHERE a.id = achievement_id AND a.created_by = auth.uid()
        )
        OR
        -- Client admin can award achievements within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = user_id 
                AND u.client_id = user_achievements.client_id
            )
        )
    );

CREATE POLICY user_achievements_update_policy ON user_achievements
    FOR UPDATE USING (
        -- Users can update their own achievement preferences
        user_id = auth.uid()
        OR
        -- Achievement creators can update award data
        EXISTS (
            SELECT 1 FROM achievements a 
            WHERE a.id = achievement_id AND a.created_by = auth.uid()
        )
        OR
        -- Client admin access within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = auth.uid() 
                AND u.client_id = user_achievements.client_id
            )
        )
    ) WITH CHECK (
        -- Same conditions for WITH CHECK
        user_id = auth.uid()
        OR
        EXISTS (
            SELECT 1 FROM achievements a 
            WHERE a.id = achievement_id AND a.created_by = auth.uid()
        )
        OR
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = user_id 
                AND u.client_id = user_achievements.client_id
            )
        )
    );

CREATE POLICY user_achievements_delete_policy ON user_achievements
    FOR DELETE USING (
        -- Achievement creators can remove awards
        EXISTS (
            SELECT 1 FROM achievements a 
            WHERE a.id = achievement_id AND a.created_by = auth.uid()
        )
        OR
        -- Client admin can remove achievements within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = auth.uid() 
                AND u.client_id = user_achievements.client_id
            )
        )
    );

-- Course milestones table policies
CREATE POLICY course_milestones_select_policy ON course_milestones
    FOR SELECT USING (
        -- Active milestones visible based on course access
        (status = 'active')
        AND
        (
            -- Published courses accessible to all
            EXISTS (
                SELECT 1 FROM courses c 
                WHERE c.id = course_id 
                AND c.status = 'published' 
                AND c.is_published = true
            )
            OR
            -- Client-specific courses visible to client members
            EXISTS (
                SELECT 1 FROM courses c 
                WHERE c.id = course_id 
                AND c.client_id IN (
                    SELECT client_id FROM users WHERE id = auth.uid()
                )
            )
            OR
            -- Course creators can see all milestones
            EXISTS (
                SELECT 1 FROM courses c 
                WHERE c.id = course_id 
                AND c.created_by = auth.uid()
            )
        )
    );

CREATE POLICY course_milestones_insert_policy ON course_milestones
    FOR INSERT WITH CHECK (
        created_by = auth.uid()
        AND EXISTS (
            SELECT 1 FROM courses c 
            WHERE c.id = course_id 
            AND (c.created_by = auth.uid() OR c.client_id IN (
                SELECT client_id FROM users WHERE id = auth.uid()
            ))
        )
    );

CREATE POLICY course_milestones_update_policy ON course_milestones
    FOR UPDATE USING (
        created_by = auth.uid()
        OR EXISTS (
            SELECT 1 FROM courses c 
            WHERE c.id = course_id 
            AND (c.created_by = auth.uid() OR c.client_id IN (
                SELECT client_id FROM users WHERE id = auth.uid()
            ))
        )
    ) WITH CHECK (
        created_by = auth.uid()
        OR EXISTS (
            SELECT 1 FROM courses c 
            WHERE c.id = course_id 
            AND (c.created_by = auth.uid() OR c.client_id IN (
                SELECT client_id FROM users WHERE id = auth.uid()
            ))
        )
    );

CREATE POLICY course_milestones_delete_policy ON course_milestones
    FOR DELETE USING (
        created_by = auth.uid()
        OR EXISTS (
            SELECT 1 FROM courses c 
            WHERE c.id = course_id 
            AND (c.created_by = auth.uid() OR c.client_id IN (
                SELECT client_id FROM users WHERE id = auth.uid()
            ))
        )
    );

-- Program milestones table policies
CREATE POLICY program_milestones_select_policy ON program_milestones
    FOR SELECT USING (
        -- Active milestones visible based on program access
        (status = 'active')
        AND
        (
            -- Public programs accessible to all
            EXISTS (
                SELECT 1 FROM programs p 
                WHERE p.id = program_id 
                AND p.status = 'published' 
                AND p.access_level = 'public'
            )
            OR
            -- Client-specific programs visible to client members
            EXISTS (
                SELECT 1 FROM programs p 
                WHERE p.id = program_id 
                AND p.client_id IN (
                    SELECT client_id FROM users WHERE id = auth.uid()
                )
            )
            OR
            -- Program creators can see all milestones
            EXISTS (
                SELECT 1 FROM programs p 
                WHERE p.id = program_id 
                AND (p.created_by = auth.uid() OR auth.uid() = ANY(p.instructor_ids))
            )
        )
    );

CREATE POLICY program_milestones_insert_policy ON program_milestones
    FOR INSERT WITH CHECK (
        created_by = auth.uid()
        AND EXISTS (
            SELECT 1 FROM programs p 
            WHERE p.id = program_id 
            AND (p.created_by = auth.uid() OR auth.uid() = ANY(p.instructor_ids) OR p.client_id IN (
                SELECT client_id FROM users WHERE id = auth.uid()
            ))
        )
    );

CREATE POLICY program_milestones_update_policy ON program_milestones
    FOR UPDATE USING (
        created_by = auth.uid()
        OR EXISTS (
            SELECT 1 FROM programs p 
            WHERE p.id = program_id 
            AND (p.created_by = auth.uid() OR auth.uid() = ANY(p.instructor_ids) OR p.client_id IN (
                SELECT client_id FROM users WHERE id = auth.uid()
            ))
        )
    ) WITH CHECK (
        created_by = auth.uid()
        OR EXISTS (
            SELECT 1 FROM programs p 
            WHERE p.id = program_id 
            AND (p.created_by = auth.uid() OR auth.uid() = ANY(p.instructor_ids) OR p.client_id IN (
                SELECT client_id FROM users WHERE id = auth.uid()
            ))
        )
    );

CREATE POLICY program_milestones_delete_policy ON program_milestones
    FOR DELETE USING (
        created_by = auth.uid()
        OR EXISTS (
            SELECT 1 FROM programs p 
            WHERE p.id = program_id 
            AND (p.created_by = auth.uid() OR auth.uid() = ANY(p.instructor_ids) OR p.client_id IN (
                SELECT client_id FROM users WHERE id = auth.uid()
            ))
        )
    );

-- User milestone progress table policies
CREATE POLICY user_milestone_progress_select_policy ON user_milestone_progress
    FOR SELECT USING (
        -- Users can see their own progress
        user_id = auth.uid()
        OR
        -- Milestone creators and course/program owners can see progress
        (
            (milestone_type = 'course' AND EXISTS (
                SELECT 1 FROM course_milestones cm 
                JOIN courses c ON c.id = cm.course_id
                WHERE cm.id = milestone_id 
                AND (c.created_by = auth.uid() OR cm.created_by = auth.uid())
            ))
            OR
            (milestone_type = 'program' AND EXISTS (
                SELECT 1 FROM program_milestones pm 
                JOIN programs p ON p.id = pm.program_id
                WHERE pm.id = milestone_id 
                AND (p.created_by = auth.uid() OR auth.uid() = ANY(p.instructor_ids) OR pm.created_by = auth.uid())
            ))
        )
        OR
        -- Client admin access within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = auth.uid() 
                AND u.client_id = user_milestone_progress.client_id
            )
        )
    );

CREATE POLICY user_milestone_progress_insert_policy ON user_milestone_progress
    FOR INSERT WITH CHECK (
        user_id = auth.uid()
        AND client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
    );

CREATE POLICY user_milestone_progress_update_policy ON user_milestone_progress
    FOR UPDATE USING (
        -- Users can update their own progress
        user_id = auth.uid()
        OR
        -- Milestone creators and validators can update progress
        (
            (milestone_type = 'course' AND EXISTS (
                SELECT 1 FROM course_milestones cm 
                JOIN courses c ON c.id = cm.course_id
                WHERE cm.id = milestone_id 
                AND (c.created_by = auth.uid() OR cm.created_by = auth.uid())
            ))
            OR
            (milestone_type = 'program' AND EXISTS (
                SELECT 1 FROM program_milestones pm 
                JOIN programs p ON p.id = pm.program_id
                WHERE pm.id = milestone_id 
                AND (p.created_by = auth.uid() OR auth.uid() = ANY(p.instructor_ids) OR pm.created_by = auth.uid())
            ))
        )
        OR
        -- Client admin access within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = auth.uid() 
                AND u.client_id = user_milestone_progress.client_id
            )
        )
    ) WITH CHECK (
        -- Same conditions for WITH CHECK
        user_id = auth.uid()
        OR
        (
            (milestone_type = 'course' AND EXISTS (
                SELECT 1 FROM course_milestones cm 
                JOIN courses c ON c.id = cm.course_id
                WHERE cm.id = milestone_id 
                AND (c.created_by = auth.uid() OR cm.created_by = auth.uid())
            ))
            OR
            (milestone_type = 'program' AND EXISTS (
                SELECT 1 FROM program_milestones pm 
                JOIN programs p ON p.id = pm.program_id
                WHERE pm.id = milestone_id 
                AND (p.created_by = auth.uid() OR auth.uid() = ANY(p.instructor_ids) OR pm.created_by = auth.uid())
            ))
        )
        OR
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = user_id 
                AND u.client_id = user_milestone_progress.client_id
            )
        )
    );

CREATE POLICY user_milestone_progress_delete_policy ON user_milestone_progress
    FOR DELETE USING (
        -- Milestone creators and admin can delete progress records
        (
            (milestone_type = 'course' AND EXISTS (
                SELECT 1 FROM course_milestones cm 
                JOIN courses c ON c.id = cm.course_id
                WHERE cm.id = milestone_id 
                AND (c.created_by = auth.uid() OR cm.created_by = auth.uid())
            ))
            OR
            (milestone_type = 'program' AND EXISTS (
                SELECT 1 FROM program_milestones pm 
                JOIN programs p ON p.id = pm.program_id
                WHERE pm.id = milestone_id 
                AND (p.created_by = auth.uid() OR auth.uid() = ANY(p.instructor_ids) OR pm.created_by = auth.uid())
            ))
        )
        OR
        -- Client admin access within same client
        (
            client_id IN (SELECT client_id FROM users WHERE id = auth.uid())
            AND EXISTS (
                SELECT 1 FROM users u 
                WHERE u.id = auth.uid() 
                AND u.client_id = user_milestone_progress.client_id
            )
        )
    );;