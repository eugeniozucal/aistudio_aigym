-- Migration: create_phase6_indexes_and_policies
-- Created at: 1757726803

-- Create comprehensive indexes for performance
CREATE INDEX IF NOT EXISTS idx_missions_client_id ON missions(client_id);
CREATE INDEX IF NOT EXISTS idx_missions_created_by ON missions(created_by);
CREATE INDEX IF NOT EXISTS idx_missions_published ON missions(is_published) WHERE is_published = true;

CREATE INDEX IF NOT EXISTS idx_courses_client_id ON courses(client_id);
CREATE INDEX IF NOT EXISTS idx_courses_instructor ON courses(instructor_id);
CREATE INDEX IF NOT EXISTS idx_courses_published ON courses(is_published) WHERE is_published = true;

CREATE INDEX IF NOT EXISTS idx_enrollments_course_user ON course_enrollments(course_id, user_id);
CREATE INDEX IF NOT EXISTS idx_enrollments_user_status ON course_enrollments(user_id, status);
CREATE INDEX IF NOT EXISTS idx_enrollments_client ON course_enrollments(client_id);

CREATE INDEX IF NOT EXISTS idx_progress_user_course ON user_progress(user_id, course_id);
CREATE INDEX IF NOT EXISTS idx_progress_user_mission ON user_progress(user_id, mission_id);
CREATE INDEX IF NOT EXISTS idx_progress_user_wod ON user_progress(user_id, wod_id);
CREATE INDEX IF NOT EXISTS idx_progress_status ON user_progress(status);
CREATE INDEX IF NOT EXISTS idx_progress_client ON user_progress(client_id);

-- Enable Row Level Security for new table
ALTER TABLE course_enrollments ENABLE ROW LEVEL SECURITY;;