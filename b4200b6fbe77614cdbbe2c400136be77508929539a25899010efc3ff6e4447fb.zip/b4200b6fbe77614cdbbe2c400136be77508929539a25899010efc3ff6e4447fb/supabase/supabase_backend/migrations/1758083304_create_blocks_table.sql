-- Migration: create_blocks_table
-- Created at: 1758083304

-- Create blocks table with similar structure to WODs
CREATE TABLE IF NOT EXISTS blocks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR(255) NOT NULL,
  description TEXT,
  thumbnail_url TEXT,
  status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  estimated_duration_minutes INTEGER DEFAULT 30,
  difficulty_level VARCHAR(20) DEFAULT 'beginner' CHECK (difficulty_level IN ('beginner', 'intermediate', 'advanced')),
  tags TEXT[] DEFAULT '{}',
  created_by UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Create updated_at trigger for blocks
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = timezone('utc'::text, now());
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_blocks_updated_at BEFORE UPDATE ON blocks
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE blocks ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for blocks
CREATE POLICY "Admins can view all blocks" ON blocks
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM admins 
            WHERE admins.user_id = auth.uid() 
            AND admins.status = 'active'
        )
    );

CREATE POLICY "Admins can insert blocks" ON blocks
    FOR INSERT WITH CHECK (
        EXISTS (
            SELECT 1 FROM admins 
            WHERE admins.user_id = auth.uid() 
            AND admins.status = 'active'
        )
    );

CREATE POLICY "Admins can update blocks" ON blocks
    FOR UPDATE USING (
        EXISTS (
            SELECT 1 FROM admins 
            WHERE admins.user_id = auth.uid() 
            AND admins.status = 'active'
        )
    );

CREATE POLICY "Admins can delete blocks" ON blocks
    FOR DELETE USING (
        EXISTS (
            SELECT 1 FROM admins 
            WHERE admins.user_id = auth.uid() 
            AND admins.status = 'active'
        )
    );

-- Create block community assignments table
CREATE TABLE IF NOT EXISTS block_community_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  block_id UUID REFERENCES blocks(id) ON DELETE CASCADE,
  community_id UUID REFERENCES communities(id) ON DELETE CASCADE,
  assigned_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  assigned_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  UNIQUE(block_id, community_id)
);

-- Enable RLS for block assignments
ALTER TABLE block_community_assignments ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for block assignments
CREATE POLICY "Admins can manage block assignments" ON block_community_assignments
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM admins 
            WHERE admins.user_id = auth.uid() 
            AND admins.status = 'active'
        )
    );

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_blocks_status ON blocks(status);
CREATE INDEX IF NOT EXISTS idx_blocks_difficulty ON blocks(difficulty_level);
CREATE INDEX IF NOT EXISTS idx_blocks_created_at ON blocks(created_at);
CREATE INDEX IF NOT EXISTS idx_blocks_updated_at ON blocks(updated_at);
CREATE INDEX IF NOT EXISTS idx_block_assignments_block_id ON block_community_assignments(block_id);
CREATE INDEX IF NOT EXISTS idx_block_assignments_community_id ON block_community_assignments(community_id);;