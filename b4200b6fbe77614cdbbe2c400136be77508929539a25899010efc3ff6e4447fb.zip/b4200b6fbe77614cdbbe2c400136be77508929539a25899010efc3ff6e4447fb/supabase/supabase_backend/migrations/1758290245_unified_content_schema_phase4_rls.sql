-- Migration: unified_content_schema_phase4_rls
-- Created at: 1758290245

-- Migration: Unified Content Schema Phase 4 - RLS Policies
-- Description: Add Row Level Security policies

-- =============================================================================
-- PHASE 7: RLS POLICIES
-- =============================================================================

-- Enable RLS
ALTER TABLE content_items_unified ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE auto_save_snapshots ENABLE ROW LEVEL SECURITY;

-- Content items policies - allow all operations for authenticated users
CREATE POLICY "Authenticated users can manage content" ON content_items_unified
    FOR ALL USING (auth.role() = 'authenticated');

-- Content history policies - allow read access for authenticated users
CREATE POLICY "Authenticated users can view content history" ON content_history
    FOR SELECT USING (auth.role() = 'authenticated');

-- Auto-save policies - allow all operations for authenticated users
CREATE POLICY "Authenticated users can manage auto-save snapshots" ON auto_save_snapshots
    FOR ALL USING (auth.role() = 'authenticated');

-- Add comments for documentation
COMMENT ON TABLE content_items_unified IS 'Unified content storage for all content types (WODs, blocks, programs, etc.)';
COMMENT ON TABLE content_history IS 'Version history and audit trail for all content changes';
COMMENT ON TABLE auto_save_snapshots IS 'Auto-save snapshots for recovery in case of browser crashes';
COMMENT ON FUNCTION fn_cleanup_auto_save() IS 'Should be called via cron job every hour: SELECT fn_cleanup_auto_save();';

-- Create a view to maintain backward compatibility with old queries
CREATE OR REPLACE VIEW missions AS
SELECT 
    id,
    title,
    description,
    thumbnail_url,
    status::text,
    estimated_duration_minutes,
    difficulty_level,
    tags,
    created_by,
    created_at,
    updated_at
FROM content_items_unified 
WHERE repository_type = 'wods';

-- Create view for workout_blocks compatibility
CREATE OR REPLACE VIEW workout_blocks AS
SELECT 
    id,
    title,
    description,
    thumbnail_url,
    status::text,
    estimated_duration_minutes,
    difficulty_level,
    tags,
    content->>'block_category' as block_category,
    content->>'instructions' as instructions,
    content->'equipment_needed' as equipment_needed,
    created_by::text as created_by,
    created_at,
    updated_at
FROM content_items_unified 
WHERE repository_type = 'blocks';;