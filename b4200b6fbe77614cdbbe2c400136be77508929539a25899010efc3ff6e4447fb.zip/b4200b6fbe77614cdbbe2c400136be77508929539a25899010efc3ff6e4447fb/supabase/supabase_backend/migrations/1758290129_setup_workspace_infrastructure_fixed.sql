-- Migration: setup_workspace_infrastructure_fixed
-- Created at: 1758290129

-- Migration: Setup Workspace Infrastructure Fixed
-- Description: Create workspaces table and ensure folder system is ready

-- Create workspaces table if it doesn't exist
CREATE TABLE IF NOT EXISTS workspaces (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    owner_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT workspace_name_length CHECK (char_length(name) >= 1 AND char_length(name) <= 255)
);

-- Create indexes for workspaces
CREATE INDEX IF NOT EXISTS idx_workspaces_owner ON workspaces(owner_id);

-- Create users table if not exists (for referential integrity)
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Get the first existing user ID or create a default one
DO $$
DECLARE
    default_user_id UUID;
    default_workspace_id UUID;
BEGIN
    -- Create or get default user
    INSERT INTO users (email) 
    VALUES ('admin@ai-gym.com')
    ON CONFLICT (email) DO NOTHING;
    
    SELECT id INTO default_user_id FROM users WHERE email = 'admin@ai-gym.com' LIMIT 1;
    
    -- Create default workspace
    INSERT INTO workspaces (name, description, owner_id) 
    VALUES (
        'Default Workspace',
        'Default workspace for existing content',
        default_user_id
    ) 
    ON CONFLICT DO NOTHING
    RETURNING id INTO default_workspace_id;
    
    -- If workspace already exists, get its ID
    IF default_workspace_id IS NULL THEN
        SELECT id INTO default_workspace_id FROM workspaces WHERE name = 'Default Workspace' LIMIT 1;
    END IF;
    
END $$;;