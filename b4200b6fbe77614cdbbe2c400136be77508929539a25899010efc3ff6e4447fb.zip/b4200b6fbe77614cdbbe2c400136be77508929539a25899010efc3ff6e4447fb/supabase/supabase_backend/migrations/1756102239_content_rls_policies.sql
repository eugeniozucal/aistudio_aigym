-- Migration: content_rls_policies
-- Created at: 1756102239

-- Enable RLS on all content management tables
ALTER TABLE content_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE prompts ENABLE ROW LEVEL SECURITY;
ALTER TABLE automations ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_client_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_user_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_tag_assignments ENABLE ROW LEVEL SECURITY;

-- Content Items: Admin access and content visibility based on assignments
CREATE POLICY "Admin full access to content_items" 
ON content_items
FOR ALL
TO authenticated
USING (
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);

CREATE POLICY "Users see assigned content items" 
ON content_items
FOR SELECT
TO authenticated
USING (
    NOT EXISTS (SELECT 1 FROM admins WHERE id = auth.uid()) 
    AND (
        -- Content assigned to user's client
        id IN (
            SELECT content_item_id FROM content_client_assignments 
            WHERE client_id = (SELECT client_id FROM users WHERE id = auth.uid() LIMIT 1)
        )
        OR
        -- Content assigned to specific user
        id IN (
            SELECT content_item_id FROM content_user_assignments 
            WHERE user_id = auth.uid()
        )
        OR
        -- Content assigned to user's tags
        id IN (
            SELECT content_item_id FROM content_tag_assignments 
            WHERE tag_id IN (
                SELECT tag_id FROM user_tag_assignments 
                WHERE user_id = auth.uid()
            )
        )
    )
);

-- AI Agents: Admin access and linked to content_items
CREATE POLICY "Admin full access to ai_agents" 
ON ai_agents
FOR ALL
TO authenticated
USING (
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);

CREATE POLICY "Users see assigned ai_agents" 
ON ai_agents
FOR SELECT
TO authenticated
USING (
    NOT EXISTS (SELECT 1 FROM admins WHERE id = auth.uid()) 
    AND content_item_id IN (
        SELECT id FROM content_items WHERE 
        id IN (
            SELECT content_item_id FROM content_client_assignments 
            WHERE client_id = (SELECT client_id FROM users WHERE id = auth.uid() LIMIT 1)
        )
        OR id IN (
            SELECT content_item_id FROM content_user_assignments 
            WHERE user_id = auth.uid()
        )
        OR id IN (
            SELECT content_item_id FROM content_tag_assignments 
            WHERE tag_id IN (
                SELECT tag_id FROM user_tag_assignments 
                WHERE user_id = auth.uid()
            )
        )
    )
);

-- Videos: Similar pattern
CREATE POLICY "Admin full access to videos" 
ON videos
FOR ALL
TO authenticated
USING (
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);

CREATE POLICY "Users see assigned videos" 
ON videos
FOR SELECT
TO authenticated
USING (
    NOT EXISTS (SELECT 1 FROM admins WHERE id = auth.uid()) 
    AND content_item_id IN (
        SELECT id FROM content_items WHERE 
        id IN (
            SELECT content_item_id FROM content_client_assignments 
            WHERE client_id = (SELECT client_id FROM users WHERE id = auth.uid() LIMIT 1)
        )
        OR id IN (
            SELECT content_item_id FROM content_user_assignments 
            WHERE user_id = auth.uid()
        )
        OR id IN (
            SELECT content_item_id FROM content_tag_assignments 
            WHERE tag_id IN (
                SELECT tag_id FROM user_tag_assignments 
                WHERE user_id = auth.uid()
            )
        )
    )
);

-- Documents: Similar pattern
CREATE POLICY "Admin full access to documents" 
ON documents
FOR ALL
TO authenticated
USING (
    EXISTS (SELECT 1 FROM admins WHERE id = auth.uid())
);

CREATE POLICY "Users see assigned documents" 
ON documents
FOR SELECT
TO authenticated
USING (
    NOT EXISTS (SELECT 1 FROM admins WHERE id = auth.uid()) 
    AND content_item_id IN (
        SELECT id FROM content_items WHERE 
        id IN (
            SELECT content_item_id FROM content_client_assignments 
            WHERE client_id = (SELECT client_id FROM users WHERE id = auth.uid() LIMIT 1)
        )
        OR id IN (
            SELECT content_item_id FROM content_user_assignments 
            WHERE user_id = auth.uid()
        )
        OR id IN (
            SELECT content_item_id FROM content_tag_assignments 
            WHERE tag_id IN (
                SELECT tag_id FROM user_tag_assignments 
                WHERE user_id = auth.uid()
            )
        )
    )
);;