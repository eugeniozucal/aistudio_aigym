-- Migration: 09_mission_to_wod_update_courses_sequence
-- Created at: 1757757814

-- Step 9: Update courses table mission_sequence to wod_sequence for semantic consistency

BEGIN;

-- Rename mission_sequence to wod_sequence in courses table for consistency
ALTER TABLE courses RENAME COLUMN mission_sequence TO wod_sequence;

COMMIT;;