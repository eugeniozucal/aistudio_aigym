-- Migration: 05_mission_to_wod_consolidate_user_progress
-- Created at: 1757757765

-- Step 5: Consolidate user_progress to use only wod_id (remove mission_id)

BEGIN;

-- Update the check constraint to use wod_id instead of mission_id
ALTER TABLE user_progress DROP CONSTRAINT check_progress_parent;
ALTER TABLE user_progress ADD CONSTRAINT check_progress_parent CHECK (
    (wod_id IS NOT NULL) OR (course_id IS NOT NULL)
);

-- Update the progress_type check constraint to include 'wod_completed' instead of 'mission_completed'
ALTER TABLE user_progress DROP CONSTRAINT user_progress_progress_type_check;
ALTER TABLE user_progress ADD CONSTRAINT user_progress_progress_type_check CHECK (
    progress_type = ANY (ARRAY[
        'page_started'::text, 
        'page_completed'::text, 
        'block_interacted'::text, 
        'quiz_attempted'::text, 
        'quiz_completed'::text, 
        'submission_made'::text, 
        'wod_completed'::text, 
        'course_completed'::text
    ])
);

-- Update existing progress_type values from 'mission_completed' to 'wod_completed'
UPDATE user_progress 
SET progress_type = 'wod_completed' 
WHERE progress_type = 'mission_completed';

-- Now safe to remove mission_id column
ALTER TABLE user_progress DROP COLUMN mission_id;

COMMIT;;