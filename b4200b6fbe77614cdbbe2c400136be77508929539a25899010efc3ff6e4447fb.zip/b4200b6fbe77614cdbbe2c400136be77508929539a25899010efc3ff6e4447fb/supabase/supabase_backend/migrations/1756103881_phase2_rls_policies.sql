-- Migration: phase2_rls_policies
-- Created at: 1756103881

-- Phase 2: RLS Policies for new tables

-- Enable RLS on new tables
ALTER TABLE client_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_engagements ENABLE ROW LEVEL SECURITY;
ALTER TABLE agent_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE bulk_uploads ENABLE ROW LEVEL SECURITY;
ALTER TABLE platform_settings ENABLE ROW LEVEL SECURITY;

-- Client Features Policies
CREATE POLICY "Enable full access for admins on client_features" ON client_features
    FOR ALL USING (
        (SELECT role FROM admins WHERE id = auth.uid()) = 'super_admin'
    );

-- User Activities Policies
CREATE POLICY "Enable read access for admins on user_activities" ON user_activities
    FOR SELECT USING (
        (SELECT role FROM admins WHERE id = auth.uid()) = 'super_admin'
    );

CREATE POLICY "Enable insert for authenticated users on user_activities" ON user_activities
    FOR INSERT WITH CHECK (
        auth.uid() = user_id OR 
        (SELECT role FROM admins WHERE id = auth.uid()) = 'super_admin'
    );

-- Content Engagements Policies
CREATE POLICY "Enable full access for admins on content_engagements" ON content_engagements
    FOR ALL USING (
        (SELECT role FROM admins WHERE id = auth.uid()) = 'super_admin'
    );

CREATE POLICY "Enable insert for users on content_engagements" ON content_engagements
    FOR INSERT WITH CHECK (
        auth.uid() = user_id
    );

-- Agent Conversations Policies
CREATE POLICY "Enable full access for admins on agent_conversations" ON agent_conversations
    FOR ALL USING (
        (SELECT role FROM admins WHERE id = auth.uid()) = 'super_admin'
    );

CREATE POLICY "Enable access for users on their conversations" ON agent_conversations
    FOR ALL USING (
        auth.uid() = user_id
    );

-- Bulk Uploads Policies
CREATE POLICY "Enable full access for admins on bulk_uploads" ON bulk_uploads
    FOR ALL USING (
        (SELECT role FROM admins WHERE id = auth.uid()) = 'super_admin'
    );

-- Platform Settings Policies
CREATE POLICY "Enable read access for admins on platform_settings" ON platform_settings
    FOR SELECT USING (
        (SELECT role FROM admins WHERE id = auth.uid()) = 'super_admin'
    );

CREATE POLICY "Enable full access for super admins on platform_settings" ON platform_settings
    FOR ALL USING (
        (SELECT role FROM admins WHERE id = auth.uid()) = 'super_admin'
    );;