-- Migration: fix_mission_builder_rls_policies
-- Created at: 1756451381

-- Fix RLS policies for Mission Builder v4

-- Enable RLS on existing tables (if not already enabled)
ALTER TABLE missions ENABLE ROW LEVEL SECURITY;
ALTER TABLE pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE blocks ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Admin users can manage all missions" ON missions;
DROP POLICY IF EXISTS "Admin users can manage all pages" ON pages;
DROP POLICY IF EXISTS "Admin users can manage all blocks" ON blocks;

-- Create comprehensive policies for admin users
CREATE POLICY "Admin users can manage all missions" ON missions
  USING (
    EXISTS (
      SELECT 1 FROM admins 
      WHERE admins.id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admins 
      WHERE admins.id = auth.uid()
    )
  );

CREATE POLICY "Admin users can manage all pages" ON pages
  USING (
    EXISTS (
      SELECT 1 FROM admins 
      WHERE admins.id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admins 
      WHERE admins.id = auth.uid()
    )
  );

CREATE POLICY "Admin users can manage all blocks" ON blocks
  USING (
    EXISTS (
      SELECT 1 FROM admins 
      WHERE admins.id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admins 
      WHERE admins.id = auth.uid()
    )
  );;