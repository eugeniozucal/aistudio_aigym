-- Migration: setup_workspace_infrastructure
-- Created at: 1758290117

-- Migration: Setup Workspace Infrastructure
-- Description: Create workspaces table and ensure folder system is ready

-- Create workspaces table if it doesn't exist
CREATE TABLE IF NOT EXISTS workspaces (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    owner_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT workspace_name_length CHECK (char_length(name) >= 1 AND char_length(name) <= 255)
);

-- Create indexes for workspaces
CREATE INDEX IF NOT EXISTS idx_workspaces_owner ON workspaces(owner_id);

-- Create users table if not exists (for referential integrity)
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Ensure folders table has proper structure
ALTER TABLE folders 
ADD COLUMN IF NOT EXISTS workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE;

-- Create default workspace
INSERT INTO workspaces (id, name, description, owner_id) 
VALUES (
    'default-workspace-uuid'::uuid, 
    'Default Workspace',
    'Default workspace for existing content',
    'default-user-uuid'::uuid
) ON CONFLICT (id) DO NOTHING;

-- Create default user
INSERT INTO users (id, email) 
VALUES (
    'default-user-uuid'::uuid,
    'admin@ai-gym.com'
) ON CONFLICT (id) DO NOTHING;;