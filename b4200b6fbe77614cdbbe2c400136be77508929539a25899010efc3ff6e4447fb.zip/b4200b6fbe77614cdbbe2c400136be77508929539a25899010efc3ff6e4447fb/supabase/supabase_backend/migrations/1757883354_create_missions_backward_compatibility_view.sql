-- Migration: create_missions_backward_compatibility_view
-- Created at: 1757883354

-- Create a backward compatibility view that maps "missions" to "wods"
-- This allows existing frontend code to continue working while the migration is completed

-- Create a view named "missions" that points to the "wods" table
CREATE VIEW missions AS 
SELECT 
    id,
    title,
    description,
    thumbnail_url,
    status,
    estimated_duration_minutes,
    difficulty_level,
    tags,
    category_id,
    workout_type,
    target_muscle_groups,
    equipment_needed,
    client_id,
    wod_sequence,
    prerequisites,
    completion_criteria,
    is_published,
    created_by,
    created_at,
    updated_at
FROM wods;

-- Create an INSTEAD OF trigger to handle INSERT operations on the view
CREATE OR REPLACE FUNCTION insert_mission_to_wod()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO wods (
        id, title, description, thumbnail_url, status, estimated_duration_minutes,
        difficulty_level, tags, category_id, workout_type, target_muscle_groups,
        equipment_needed, client_id, wod_sequence, prerequisites, completion_criteria,
        is_published, created_by, created_at, updated_at
    ) VALUES (
        COALESCE(NEW.id, gen_random_uuid()),
        NEW.title,
        NEW.description,
        NEW.thumbnail_url,
        NEW.status,
        NEW.estimated_duration_minutes,
        NEW.difficulty_level,
        NEW.tags,
        NEW.category_id,
        NEW.workout_type,
        NEW.target_muscle_groups,
        NEW.equipment_needed,
        NEW.client_id,
        NEW.wod_sequence,
        NEW.prerequisites,
        NEW.completion_criteria,
        NEW.is_published,
        NEW.created_by,
        COALESCE(NEW.created_at, NOW()),
        COALESCE(NEW.updated_at, NOW())
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER insert_mission_trigger
    INSTEAD OF INSERT ON missions
    FOR EACH ROW
    EXECUTE FUNCTION insert_mission_to_wod();

-- Create an INSTEAD OF trigger to handle UPDATE operations on the view
CREATE OR REPLACE FUNCTION update_mission_to_wod()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE wods SET
        title = NEW.title,
        description = NEW.description,
        thumbnail_url = NEW.thumbnail_url,
        status = NEW.status,
        estimated_duration_minutes = NEW.estimated_duration_minutes,
        difficulty_level = NEW.difficulty_level,
        tags = NEW.tags,
        category_id = NEW.category_id,
        workout_type = NEW.workout_type,
        target_muscle_groups = NEW.target_muscle_groups,
        equipment_needed = NEW.equipment_needed,
        client_id = NEW.client_id,
        wod_sequence = NEW.wod_sequence,
        prerequisites = NEW.prerequisites,
        completion_criteria = NEW.completion_criteria,
        is_published = NEW.is_published,
        updated_at = NOW()
    WHERE id = NEW.id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_mission_trigger
    INSTEAD OF UPDATE ON missions
    FOR EACH ROW
    EXECUTE FUNCTION update_mission_to_wod();

-- Create an INSTEAD OF trigger to handle DELETE operations on the view
CREATE OR REPLACE FUNCTION delete_mission_from_wod()
RETURNS TRIGGER AS $$
BEGIN
    DELETE FROM wods WHERE id = OLD.id;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER delete_mission_trigger
    INSTEAD OF DELETE ON missions
    FOR EACH ROW
    EXECUTE FUNCTION delete_mission_from_wod();

-- Apply the same RLS policies to the missions view as the wods table
ALTER VIEW missions OWNER TO postgres;

-- Grant appropriate permissions
GRANT ALL ON missions TO authenticated;
GRANT ALL ON missions TO service_role;;