-- Migration: 03_mission_to_wod_cleanup_orphaned_data
-- Created at: 1757757746

-- Step 3A: Clean up orphaned data before updating pages table

BEGIN;

-- First, create a backup of orphaned pages for audit
CREATE TEMP TABLE orphaned_pages_backup AS
SELECT * FROM pages 
WHERE mission_id IS NOT NULL 
AND mission_id NOT IN (SELECT id FROM wods);

-- Delete orphaned pages that reference non-existent missions
-- This is necessary for data integrity
DELETE FROM pages 
WHERE mission_id IS NOT NULL 
AND mission_id NOT IN (SELECT id FROM wods);

-- Also clean up orphaned user_progress entries
DELETE FROM user_progress 
WHERE mission_id IS NOT NULL 
AND mission_id NOT IN (SELECT id FROM wods);

COMMIT;;