-- Migration: add_content_management_tables
-- Created at: 1756113600

-- Create content categories table
CREATE TABLE content_categories (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  color VARCHAR(7) DEFAULT '#3B82F6',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create content articles table
CREATE TABLE content_articles (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  excerpt TEXT,
  author VARCHAR(100) NOT NULL,
  category_id INTEGER REFERENCES content_categories(id) ON DELETE SET NULL,
  status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  tags TEXT[],
  featured_image_url TEXT,
  slug VARCHAR(255) UNIQUE,
  seo_title VARCHAR(255),
  seo_description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  published_at TIMESTAMP WITH TIME ZONE
);

-- Create indexes for better performance
CREATE INDEX idx_content_articles_category_id ON content_articles(category_id);
CREATE INDEX idx_content_articles_status ON content_articles(status);
CREATE INDEX idx_content_articles_created_at ON content_articles(created_at DESC);
CREATE INDEX idx_content_articles_slug ON content_articles(slug);

-- Enable RLS
ALTER TABLE content_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_articles ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for admin access
CREATE POLICY "Admin full access to content_categories" ON content_categories
FOR ALL USING (true);

CREATE POLICY "Admin full access to content_articles" ON content_articles
FOR ALL USING (true);

-- Insert default categories
INSERT INTO content_categories (name, description, color) VALUES
('Tutorials', 'Step-by-step guides and tutorials', '#10B981'),
('Documentation', 'Technical documentation and references', '#3B82F6'),
('Blog Posts', 'Company blog and announcements', '#EF4444'),
('Resources', 'Tools, templates, and resources', '#8B5CF6'),
('Case Studies', 'Customer success stories and case studies', '#F59E0B');

-- Insert sample articles
INSERT INTO content_articles (title, content, excerpt, author, category_id, status, slug, published_at) VALUES
('Getting Started with AI GYM Platform', 
 '<h1>Welcome to AI GYM Platform</h1><p>This comprehensive guide will help you get started with the AI GYM Platform...</p>', 
 'Learn the basics of AI GYM Platform and start building your first AI agent.', 
 'Admin User', 
 1, 
 'published', 
 'getting-started-ai-gym',
 now()),
('API Documentation Overview', 
 '<h1>API Reference</h1><p>Complete API documentation for developers...</p>', 
 'Complete reference for all API endpoints and authentication methods.', 
 'Admin User', 
 2, 
 'published', 
 'api-documentation-overview',
 now()),
('Platform Updates - December 2024', 
 '<h1>Latest Updates</h1><p>We are excited to share the latest platform improvements...</p>', 
 'Discover the newest features and improvements in our latest release.', 
 'Admin User', 
 3, 
 'published', 
 'platform-updates-december-2024',
 now() - INTERVAL '1 day');
