-- Migration: fix_clients_table_structure
-- Created at: 1756110772

-- Fix clients table structure to remove duplicate columns
-- Remove duplicate columns and standardize
ALTER TABLE clients DROP COLUMN IF EXISTS has_forum;
ALTER TABLE clients DROP COLUMN IF EXISTS color_hex;

-- Make sure the remaining columns have proper names and types
ALTER TABLE clients ALTER COLUMN brand_color SET DEFAULT '#3B82F6';
ALTER TABLE clients ALTER COLUMN forum_enabled SET DEFAULT true;

-- Ensure project_name can be null (it should be optional)
ALTER TABLE clients ALTER COLUMN project_name DROP NOT NULL;;