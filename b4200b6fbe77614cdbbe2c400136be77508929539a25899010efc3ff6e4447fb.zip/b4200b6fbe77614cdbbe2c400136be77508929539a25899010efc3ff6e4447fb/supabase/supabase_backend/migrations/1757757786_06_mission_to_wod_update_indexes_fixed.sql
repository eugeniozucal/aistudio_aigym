-- Migration: 06_mission_to_wod_update_indexes_fixed
-- Created at: 1757757786

-- Step 6: Update all indexes to reflect new table and column names (corrected)

BEGIN;

-- Update indexes on the wods table (formerly missions)
ALTER INDEX missions_pkey RENAME TO wods_pkey;
ALTER INDEX idx_missions_category_id RENAME TO idx_wods_category_id;
ALTER INDEX idx_missions_client_id RENAME TO idx_wods_client_id;
ALTER INDEX idx_missions_created_by RENAME TO idx_wods_created_by;
ALTER INDEX idx_missions_published RENAME TO idx_wods_published;

-- Create new index for pages.wod_id (since mission_id column was dropped)
CREATE INDEX idx_pages_wod_id ON pages(wod_id);

-- Update assignment table indexes (they still reference mission_id columns that need updating)
ALTER INDEX mission_client_assignments_pkey RENAME TO wod_client_assignments_pkey;
ALTER INDEX mission_tag_assignments_pkey RENAME TO wod_tag_assignments_pkey;  
ALTER INDEX mission_user_assignments_pkey RENAME TO wod_user_assignments_pkey;

COMMIT;;