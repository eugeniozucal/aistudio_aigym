-- Migration: create_program_enrollments_table
-- Created at: 1757761884

-- Create program_enrollments table for user enrollment tracking
CREATE TABLE IF NOT EXISTS program_enrollments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Core enrollment data
    program_id UUID NOT NULL REFERENCES programs(id) ON DELETE CASCADE,
    user_id UUID NOT NULL,
    client_id UUID NOT NULL,
    
    -- Enrollment status and timing
    enrolled_at TIMESTAMPTZ DEFAULT now(),
    status VARCHAR DEFAULT 'active', -- 'active', 'paused', 'completed', 'dropped', 'expired'
    enrollment_source TEXT, -- 'self_enrollment', 'admin_assigned', 'bulk_import', 'referral'
    enrollment_pathway TEXT, -- custom tracking for enrollment journey
    
    -- Progress tracking
    progress_percentage NUMERIC DEFAULT 0 CHECK (progress_percentage >= 0 AND progress_percentage <= 100),
    current_course_id UUID, -- current course in sequence (if sequential)
    current_course_position INTEGER DEFAULT 0, -- position in course sequence
    completed_courses JSONB DEFAULT '[]'::jsonb, -- array of completed course IDs
    
    -- Completion and timing
    started_at TIMESTAMPTZ, -- when user started actual content
    last_activity_at TIMESTAMPTZ DEFAULT now(),
    completed_at TIMESTAMPTZ,
    target_completion_date DATE, -- user's personal target
    actual_completion_date DATE,
    
    -- Performance metrics
    total_time_spent INTERVAL DEFAULT '0 hours'::interval,
    completion_score NUMERIC, -- overall program score if applicable
    performance_data JSONB DEFAULT '{}'::jsonb, -- detailed performance metrics
    
    -- Customization and settings
    program_settings JSONB DEFAULT '{}'::jsonb, -- user-specific program settings
    notes TEXT, -- user or admin notes
    
    -- Certification
    certificate_issued_at TIMESTAMPTZ,
    certificate_url TEXT,
    certificate_id VARCHAR, -- unique certificate identifier
    
    -- Administrative
    assigned_by UUID, -- user who assigned this enrollment (for admin assignments)
    priority_level INTEGER DEFAULT 0, -- enrollment priority (for scheduling)
    
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    
    -- Unique constraint to prevent duplicate enrollments
    UNIQUE(program_id, user_id, client_id),
    
    -- Check constraints
    CONSTRAINT program_enrollments_status_check CHECK (
        status IN ('active', 'paused', 'completed', 'dropped', 'expired')
    ),
    CONSTRAINT program_enrollments_progress_valid CHECK (
        progress_percentage >= 0 AND progress_percentage <= 100
    )
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS program_enrollments_program_id_idx ON program_enrollments(program_id);
CREATE INDEX IF NOT EXISTS program_enrollments_user_id_idx ON program_enrollments(user_id);
CREATE INDEX IF NOT EXISTS program_enrollments_client_id_idx ON program_enrollments(client_id);
CREATE INDEX IF NOT EXISTS program_enrollments_status_idx ON program_enrollments(status);
CREATE INDEX IF NOT EXISTS program_enrollments_enrolled_at_idx ON program_enrollments(enrolled_at DESC);
CREATE INDEX IF NOT EXISTS program_enrollments_progress_idx ON program_enrollments(progress_percentage);
CREATE INDEX IF NOT EXISTS program_enrollments_completion_idx ON program_enrollments(completed_at) WHERE completed_at IS NOT NULL;

-- Composite indexes for common queries
CREATE INDEX IF NOT EXISTS program_enrollments_user_status_idx ON program_enrollments(user_id, status);
CREATE INDEX IF NOT EXISTS program_enrollments_program_status_idx ON program_enrollments(program_id, status);;