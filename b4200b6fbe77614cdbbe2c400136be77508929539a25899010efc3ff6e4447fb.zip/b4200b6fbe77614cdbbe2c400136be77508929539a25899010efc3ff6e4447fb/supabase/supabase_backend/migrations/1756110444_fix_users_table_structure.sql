-- Migration: fix_users_table_structure
-- Created at: 1756110444

-- Fix the users table structure to avoid conflicts
-- First, create a temporary table with the correct structure
CREATE TABLE users_temp (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES clients(id),
  email text NOT NULL,
  first_name text,
  last_name text,
  last_active timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Copy any existing data that makes sense
INSERT INTO users_temp (id, client_id, email, first_name, last_name, last_active, created_at)
SELECT 
  COALESCE(id, gen_random_uuid()),
  client_id,
  COALESCE(email, ''),
  first_name,
  last_name,
  last_active,
  COALESCE(created_at, now())
FROM users
WHERE client_id IS NOT NULL AND email IS NOT NULL AND email != '';

-- Drop the problematic table (with cascade to handle dependencies)
DROP TABLE users CASCADE;

-- Rename the temp table to users
ALTER TABLE users_temp RENAME TO users;

-- Recreate the foreign key constraints
ALTER TABLE user_activities 
ADD CONSTRAINT user_activities_user_id_fkey 
FOREIGN KEY (user_id) REFERENCES users(id);

ALTER TABLE content_engagements 
ADD CONSTRAINT content_engagements_user_id_fkey 
FOREIGN KEY (user_id) REFERENCES users(id);

ALTER TABLE agent_conversations 
ADD CONSTRAINT agent_conversations_user_id_fkey 
FOREIGN KEY (user_id) REFERENCES users(id);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for users table
CREATE POLICY "Users are viewable by authenticated admins" ON users
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM admins 
    WHERE admins.id = auth.uid()
  )
);

CREATE POLICY "Users can be inserted by authenticated admins" ON users
FOR INSERT WITH CHECK (
  EXISTS (
    SELECT 1 FROM admins 
    WHERE admins.id = auth.uid()
  )
);

CREATE POLICY "Users can be updated by authenticated admins" ON users
FOR UPDATE USING (
  EXISTS (
    SELECT 1 FROM admins 
    WHERE admins.id = auth.uid()
  )
);

CREATE POLICY "Users can be deleted by authenticated admins" ON users
FOR DELETE USING (
  EXISTS (
    SELECT 1 FROM admins 
    WHERE admins.id = auth.uid()
  )
);;