-- Migration: unified_content_schema_phase2
-- Created at: 1758290198

-- Migration: Unified Content Schema Phase 2
-- Description: Add indexes, triggers, and functions

-- =============================================================================
-- PHASE 3: INDEXES FOR PERFORMANCE
-- =============================================================================

-- Content items indexes
CREATE INDEX idx_content_unified_workspace_repo ON content_items_unified(workspace_id, repository_type);
CREATE INDEX idx_content_unified_folder ON content_items_unified(folder_id);
CREATE INDEX idx_content_unified_status ON content_items_unified(status);
CREATE INDEX idx_content_unified_created_by ON content_items_unified(created_by);
CREATE INDEX idx_content_unified_updated_at ON content_items_unified(updated_at DESC);
CREATE INDEX idx_content_unified_tags_gin ON content_items_unified USING GIN(tags);

-- Content history indexes
CREATE INDEX idx_content_history_content_id ON content_history(content_id);
CREATE INDEX idx_content_history_version ON content_history(content_id, version DESC);
CREATE INDEX idx_content_history_created_at ON content_history(created_at DESC);

-- Auto-save indexes  
CREATE INDEX idx_auto_save_content_session ON auto_save_snapshots(content_id, session_id);
CREATE INDEX idx_auto_save_created_at ON auto_save_snapshots(created_at DESC);

-- =============================================================================
-- PHASE 4: TRIGGERS AND FUNCTIONS
-- =============================================================================

-- Updated timestamp trigger function
CREATE OR REPLACE FUNCTION fn_set_updated_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    IF TG_OP = 'UPDATE' THEN
        NEW.version = OLD.version + 1;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Content history tracking function
CREATE OR REPLACE FUNCTION fn_track_content_history()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO content_history(
            content_id, version, title, description, content, metadata, 
            status, operation_type, created_by
        ) VALUES (
            NEW.id, NEW.version, NEW.title, NEW.description, NEW.content, 
            NEW.metadata, NEW.status, 'create', NEW.created_by
        );
    ELSIF TG_OP = 'UPDATE' AND (OLD.content != NEW.content OR OLD.title != NEW.title OR OLD.description != NEW.description) THEN
        INSERT INTO content_history(
            content_id, version, title, description, content, metadata, 
            status, operation_type, created_by
        ) VALUES (
            NEW.id, NEW.version, NEW.title, NEW.description, NEW.content, 
            NEW.metadata, NEW.status, 'update', NEW.updated_by
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Auto-save cleanup function
CREATE OR REPLACE FUNCTION fn_cleanup_auto_save()
RETURNS void AS $$
BEGIN
    -- Delete auto-save snapshots older than 24 hours
    DELETE FROM auto_save_snapshots 
    WHERE created_at < CURRENT_TIMESTAMP - INTERVAL '24 hours';
    
    -- Keep only the latest 10 snapshots per content item per session
    DELETE FROM auto_save_snapshots
    WHERE id NOT IN (
        SELECT id FROM (
            SELECT id, 
                   ROW_NUMBER() OVER (PARTITION BY content_id, session_id ORDER BY created_at DESC) as rn
            FROM auto_save_snapshots
        ) ranked
        WHERE rn <= 10
    );
END;
$$ LANGUAGE plpgsql;

-- Create triggers
CREATE TRIGGER tr_content_unified_updated_at
    BEFORE UPDATE ON content_items_unified
    FOR EACH ROW
    EXECUTE FUNCTION fn_set_updated_timestamp();

CREATE TRIGGER tr_track_content_history
    AFTER INSERT OR UPDATE ON content_items_unified
    FOR EACH ROW
    EXECUTE FUNCTION fn_track_content_history();;