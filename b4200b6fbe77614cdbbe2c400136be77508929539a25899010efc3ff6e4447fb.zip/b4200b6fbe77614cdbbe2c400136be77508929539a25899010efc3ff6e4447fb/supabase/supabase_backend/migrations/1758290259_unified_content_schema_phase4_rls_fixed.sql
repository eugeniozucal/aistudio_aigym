-- Migration: unified_content_schema_phase4_rls_fixed
-- Created at: 1758290259

-- Migration: Unified Content Schema Phase 4 - RLS Policies Fixed
-- Description: Add Row Level Security policies and create compatibility views

-- =============================================================================
-- PHASE 7: RLS POLICIES
-- =============================================================================

-- Enable RLS
ALTER TABLE content_items_unified ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE auto_save_snapshots ENABLE ROW LEVEL SECURITY;

-- Content items policies - allow all operations for authenticated users
CREATE POLICY "Authenticated users can manage content" ON content_items_unified
    FOR ALL USING (auth.role() = 'authenticated');

-- Content history policies - allow read access for authenticated users
CREATE POLICY "Authenticated users can view content history" ON content_history
    FOR SELECT USING (auth.role() = 'authenticated');

-- Auto-save policies - allow all operations for authenticated users
CREATE POLICY "Authenticated users can manage auto-save snapshots" ON auto_save_snapshots
    FOR ALL USING (auth.role() = 'authenticated');

-- Add comments for documentation
COMMENT ON TABLE content_items_unified IS 'Unified content storage for all content types (WODs, blocks, programs, etc.)';
COMMENT ON TABLE content_history IS 'Version history and audit trail for all content changes';
COMMENT ON TABLE auto_save_snapshots IS 'Auto-save snapshots for recovery in case of browser crashes';
COMMENT ON FUNCTION fn_cleanup_auto_save() IS 'Should be called via cron job every hour: SELECT fn_cleanup_auto_save();';

-- Replace old table with unified structure (backup first)
DO $$
BEGIN
    -- Backup content_items if it exists
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'content_items') THEN
        EXECUTE 'ALTER TABLE content_items RENAME TO content_items_backup_' || EXTRACT(EPOCH FROM NOW());
    END IF;
    
    -- Rename unified table to content_items
    ALTER TABLE content_items_unified RENAME TO content_items;
    
    -- Update any dependent views or triggers
    EXCEPTION WHEN OTHERS THEN
        -- Log error but continue
        RAISE NOTICE 'Error during table rename: %', SQLERRM;
END $$;;