-- Migration: add_ai_agents_foreign_key
-- Created at: 1758326476

-- Add missing foreign key constraint for ai_agents table
ALTER TABLE ai_agents
ADD CONSTRAINT ai_agents_content_item_id_fkey 
FOREIGN KEY (content_item_id) 
REFERENCES content_items(id) 
ON DELETE CASCADE;;