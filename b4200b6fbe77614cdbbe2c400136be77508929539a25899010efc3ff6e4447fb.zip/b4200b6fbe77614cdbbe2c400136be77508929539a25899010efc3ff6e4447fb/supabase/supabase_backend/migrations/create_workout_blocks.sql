-- Create workout_blocks table for storing workout building blocks
-- Note: Using 'workout_blocks' to avoid conflict with existing 'blocks' table

CREATE TABLE IF NOT EXISTS workout_blocks (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    thumbnail_url TEXT,
    status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
    estimated_duration_minutes INTEGER DEFAULT 0,
    difficulty_level VARCHAR(20) DEFAULT 'beginner' CHECK (difficulty_level IN ('beginner', 'intermediate', 'advanced')),
    tags JSONB DEFAULT '[]'::jsonb,
    block_category VARCHAR(50) DEFAULT 'general' CHECK (block_category IN ('warm-up', 'cardio', 'strength', 'flexibility', 'cool-down', 'general')),
    equipment_needed JSONB DEFAULT '[]'::jsonb,
    instructions TEXT,
    created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_workout_blocks_updated_at
    BEFORE UPDATE ON workout_blocks
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Enable Row Level Security
ALTER TABLE workout_blocks ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
-- Policy for admins to have full access
CREATE POLICY "Admins can manage workout_blocks" ON workout_blocks
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM profiles 
            WHERE profiles.id = auth.uid() 
            AND profiles.role = 'admin'
        )
    );

-- Policy for authenticated users to read published blocks
CREATE POLICY "Users can view published workout_blocks" ON workout_blocks
    FOR SELECT USING (
        status = 'published' AND 
        auth.role() = 'authenticated'
    );

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_workout_blocks_status ON workout_blocks(status);
CREATE INDEX IF NOT EXISTS idx_workout_blocks_difficulty ON workout_blocks(difficulty_level);
CREATE INDEX IF NOT EXISTS idx_workout_blocks_category ON workout_blocks(block_category);
CREATE INDEX IF NOT EXISTS idx_workout_blocks_created_at ON workout_blocks(created_at);
CREATE INDEX IF NOT EXISTS idx_workout_blocks_updated_at ON workout_blocks(updated_at);

-- Add comment for documentation
COMMENT ON TABLE workout_blocks IS 'Stores reusable workout building blocks for the Training Zone BLOCKS module';