-- Migration: setup_workspace_simple
-- Created at: 1758290147

-- Migration: Setup Workspace Simple
-- Description: Create workspaces table for unified content system

-- Create workspaces table if it doesn't exist
CREATE TABLE IF NOT EXISTS workspaces (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    owner_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT workspace_name_length CHECK (char_length(name) >= 1 AND char_length(name) <= 255)
);

-- Create indexes for workspaces
CREATE INDEX IF NOT EXISTS idx_workspaces_owner ON workspaces(owner_id);

-- Create default workspace using first existing user
INSERT INTO workspaces (name, description, owner_id) 
SELECT 
    'Default Workspace',
    'Default workspace for existing content',
    (SELECT id FROM users LIMIT 1)
WHERE NOT EXISTS (SELECT 1 FROM workspaces WHERE name = 'Default Workspace');;