-- Migration: 03_mission_to_wod_update_pages_table
-- Created at: 1757757721

-- Step 3: Update pages table to use wod_id instead of mission_id

BEGIN;

-- Add wod_id column to pages table
ALTER TABLE pages ADD COLUMN wod_id UUID;

-- Copy data from mission_id to wod_id
UPDATE pages SET wod_id = mission_id WHERE mission_id IS NOT NULL;

-- Add foreign key constraint for wod_id
ALTER TABLE pages ADD CONSTRAINT pages_wod_id_fkey FOREIGN KEY (wod_id) REFERENCES wods(id) ON DELETE CASCADE;

-- Update the check constraint to use wod_id instead of mission_id
ALTER TABLE pages DROP CONSTRAINT check_page_parent;
ALTER TABLE pages ADD CONSTRAINT check_page_parent CHECK (
    (wod_id IS NOT NULL AND course_id IS NULL) OR
    (wod_id IS NULL AND course_id IS NOT NULL)
);

-- Remove the old mission_id column (after data is safely copied)
ALTER TABLE pages DROP COLUMN mission_id;

COMMIT;;