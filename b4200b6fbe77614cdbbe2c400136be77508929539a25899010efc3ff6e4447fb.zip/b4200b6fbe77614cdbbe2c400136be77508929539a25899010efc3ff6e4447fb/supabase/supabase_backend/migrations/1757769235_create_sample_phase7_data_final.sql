-- Migration: create_sample_phase7_data_final
-- Created at: 1757769235

-- Create sample data for Phase 7 testing with all required fields
-- Insert sample programs for testing

INSERT INTO programs (id, title, description, difficulty_level, is_active, status, program_type, access_level, client_id, created_by)
VALUES 
    ('550e8400-e29b-41d4-a716-446655440001', 'Web Development Fundamentals', 'Complete introduction to web development including HTML, CSS, and JavaScript basics', 'beginner', true, 'published', 'training', 'public', '550e8400-e29b-41d4-a716-446655440000', '550e8400-e29b-41d4-a716-446655440000'),
    ('550e8400-e29b-41d4-a716-446655440002', 'Advanced React Development', 'Master React.js with hooks, context, and advanced patterns', 'advanced', true, 'published', 'training', 'public', '550e8400-e29b-41d4-a716-446655440000', '550e8400-e29b-41d4-a716-446655440000'),
    ('550e8400-e29b-41d4-a716-446655440003', 'Data Science with Python', 'Learn data analysis, visualization, and machine learning with Python', 'intermediate', true, 'published', 'certification', 'public', '550e8400-e29b-41d4-a716-446655440000', '550e8400-e29b-41d4-a716-446655440000')
ON CONFLICT (id) DO NOTHING;

-- Insert sample courses with all required fields
INSERT INTO courses (id, title, description, is_active, client_id, created_by)
VALUES 
    ('660e8400-e29b-41d4-a716-446655440001', 'HTML Fundamentals', 'Learn the basics of HTML markup language', true, '550e8400-e29b-41d4-a716-446655440000', '550e8400-e29b-41d4-a716-446655440000'),
    ('660e8400-e29b-41d4-a716-446655440002', 'CSS Styling', 'Master CSS for beautiful web designs', true, '550e8400-e29b-41d4-a716-446655440000', '550e8400-e29b-41d4-a716-446655440000'),
    ('660e8400-e29b-41d4-a716-446655440003', 'JavaScript Basics', 'Introduction to JavaScript programming', true, '550e8400-e29b-41d4-a716-446655440000', '550e8400-e29b-41d4-a716-446655440000'),
    ('660e8400-e29b-41d4-a716-446655440004', 'React Components', 'Building reusable React components', true, '550e8400-e29b-41d4-a716-446655440000', '550e8400-e29b-41d4-a716-446655440000'),
    ('660e8400-e29b-41d4-a716-446655440005', 'Python Data Analysis', 'Data manipulation with Pandas', true, '550e8400-e29b-41d4-a716-446655440000', '550e8400-e29b-41d4-a716-446655440000')
ON CONFLICT (id) DO NOTHING;

-- Insert sample achievements
INSERT INTO achievements (id, title, name, description, category, difficulty_level, point_value, points_value, is_active, badge_icon, client_id, created_by)
VALUES 
    ('770e8400-e29b-41d4-a716-446655440001', 'First Steps', 'First Steps', 'Complete your first course', 'learning', 'beginner', 100, 100, true, '🎯', '550e8400-e29b-41d4-a716-446655440000', '550e8400-e29b-41d4-a716-446655440000'),
    ('770e8400-e29b-41d4-a716-446655440002', 'Learning Streak', 'Learning Streak', 'Learn for 7 consecutive days', 'engagement', 'intermediate', 250, 250, true, '🔥', '550e8400-e29b-41d4-a716-446655440000', '550e8400-e29b-41d4-a716-446655440000'),
    ('770e8400-e29b-41d4-a716-446655440003', 'Course Master', 'Course Master', 'Complete 10 courses', 'achievement', 'advanced', 500, 500, true, '🏆', '550e8400-e29b-41d4-a716-446655440000', '550e8400-e29b-41d4-a716-446655440000'),
    ('770e8400-e29b-41d4-a716-446655440004', 'Program Graduate', 'Program Graduate', 'Complete your first program', 'milestone', 'intermediate', 300, 300, true, '🎓', '550e8400-e29b-41d4-a716-446655440000', '550e8400-e29b-41d4-a716-446655440000')
ON CONFLICT (id) DO NOTHING;

-- Insert program-course relationships
INSERT INTO program_courses (program_id, course_id, sequence_order, client_id)
VALUES 
    ('550e8400-e29b-41d4-a716-446655440001', '660e8400-e29b-41d4-a716-446655440001', 1, '550e8400-e29b-41d4-a716-446655440000'),
    ('550e8400-e29b-41d4-a716-446655440001', '660e8400-e29b-41d4-a716-446655440002', 2, '550e8400-e29b-41d4-a716-446655440000'),
    ('550e8400-e29b-41d4-a716-446655440001', '660e8400-e29b-41d4-a716-446655440003', 3, '550e8400-e29b-41d4-a716-446655440000'),
    ('550e8400-e29b-41d4-a716-446655440002', '660e8400-e29b-41d4-a716-446655440004', 1, '550e8400-e29b-41d4-a716-446655440000'),
    ('550e8400-e29b-41d4-a716-446655440003', '660e8400-e29b-41d4-a716-446655440005', 1, '550e8400-e29b-41d4-a716-446655440000')
ON CONFLICT (program_id, course_id) DO NOTHING;;