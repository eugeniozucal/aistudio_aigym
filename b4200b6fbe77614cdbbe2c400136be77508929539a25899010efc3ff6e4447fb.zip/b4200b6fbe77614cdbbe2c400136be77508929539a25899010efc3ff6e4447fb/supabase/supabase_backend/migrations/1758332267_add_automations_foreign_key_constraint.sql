-- Migration: add_automations_foreign_key_constraint
-- Created at: 1758332267

ALTER TABLE automations 
ADD CONSTRAINT automations_content_item_id_fkey 
FOREIGN KEY (content_item_id) 
REFERENCES content_items(id) 
ON DELETE CASCADE;;