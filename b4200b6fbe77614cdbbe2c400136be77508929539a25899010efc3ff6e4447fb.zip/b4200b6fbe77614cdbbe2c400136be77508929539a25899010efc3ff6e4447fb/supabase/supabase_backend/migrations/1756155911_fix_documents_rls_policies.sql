-- Migration: fix_documents_rls_policies
-- Created at: 1756155911

-- Drop existing conflicting policies for documents
DROP POLICY IF EXISTS "Admin full access to documents" ON documents;
DROP POLICY IF EXISTS "Admins can manage documents" ON documents;

-- Create clear and consistent policies for documents
CREATE POLICY "Authenticated users can view documents"
ON documents
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Admins can manage documents"
ON documents
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admins 
    WHERE admins.id = auth.uid()
  )
);

CREATE POLICY "Service role has full access to documents"
ON documents
FOR ALL
TO service_role
USING (true);;