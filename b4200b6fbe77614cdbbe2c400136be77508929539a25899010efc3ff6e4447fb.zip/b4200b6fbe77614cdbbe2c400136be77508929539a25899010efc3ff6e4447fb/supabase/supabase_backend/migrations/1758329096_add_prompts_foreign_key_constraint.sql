-- Migration: add_prompts_foreign_key_constraint
-- Created at: 1758329096

ALTER TABLE prompts 
ADD CONSTRAINT prompts_content_item_id_fkey 
FOREIGN KEY (content_item_id) 
REFERENCES content_items(id) 
ON DELETE CASCADE;;