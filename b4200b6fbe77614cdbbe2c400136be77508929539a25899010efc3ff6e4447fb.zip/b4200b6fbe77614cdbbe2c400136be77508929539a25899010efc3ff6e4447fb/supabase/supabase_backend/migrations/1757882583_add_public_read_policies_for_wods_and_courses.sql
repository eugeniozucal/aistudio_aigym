-- Migration: add_public_read_policies_for_wods_and_courses
-- Created at: 1757882583

-- Add public read access for published courses and WODs
-- This allows anonymous users to browse published content

-- Allow public SELECT access to published courses
CREATE POLICY "Public can view published courses" ON courses
    FOR SELECT USING (is_published = true AND status = 'published');

-- Allow public SELECT access to published WODs  
CREATE POLICY "Public can view published wods" ON wods
    FOR SELECT USING (is_published = true AND status = 'published');

-- Allow public SELECT access to WOD categories (needed for filtering)
CREATE POLICY "Public can view wod categories" ON wod_categories
    FOR SELECT USING (is_active = true);;