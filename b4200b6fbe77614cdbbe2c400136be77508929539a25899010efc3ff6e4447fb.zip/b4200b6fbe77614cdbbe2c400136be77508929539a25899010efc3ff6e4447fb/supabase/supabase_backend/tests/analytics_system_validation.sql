-- Analytics System Validation Test Data Generation
-- This script creates comprehensive test data to demonstrate the advanced analytics capabilities

-- Insert sample learning analytics data
INSERT INTO learning_analytics (
    user_id, client_id, analytics_period, period_start_date, period_end_date,
    total_learning_time_minutes, active_learning_time_minutes, learning_sessions_count,
    blocks_attempted, blocks_completed, blocks_mastered, avg_learning_velocity,
    learning_velocity_trend, content_consumption_rate, avg_engagement_score,
    avg_focus_score, interaction_intensity, attention_span_minutes, break_frequency,
    avg_completion_percentage, avg_mastery_score, performance_consistency_score,
    improvement_rate, retention_score, skill_degradation_risk, knowledge_decay_rate,
    preferred_session_duration_minutes, optimal_learning_times, content_type_preferences,
    device_usage_patterns, completion_prediction_score, at_risk_indicator,
    estimated_time_to_mastery_hours, success_probability, peer_ranking_percentile,
    cohort_comparison_score, organizational_benchmark_score, time_efficiency_score,
    effort_efficiency_score, help_seeking_frequency, self_sufficiency_score,
    return_frequency, session_completion_rate, content_abandonment_rate,
    goal_achievement_rate, learning_style_indicators, strength_areas,
    improvement_areas, recommended_interventions, personalized_recommendations,
    data_quality_score
) VALUES 
-- High Performer Example
(
    'a45cb75e-0260-4f25-bffb-34479c7c52ac',
    'f522ecd6-061c-4b49-8bde-e645064f7ee4',
    'weekly',
    '2025-09-07T00:00:00Z',
    '2025-09-13T23:59:59Z',
    420, 380, 12,
    45, 42, 35, 1.8,
    'improving', 6.2, 87.5,
    82.3, 4.2, 35, 2.1,
    93.5, 88.7, 92.1,
    15.3, 89.2, 15.0, 2.1,
    35, '[9, 10, 14, 15, 19, 20]', '{"video": 95, "quiz": 88, "reading": 82}',
    '{"desktop": 75, "mobile": 20, "tablet": 5}', 92.5, false,
    12.5, 91.8, 85.2,
    88.9, 87.3, 88.5,
    91.2, 1.8, 89.7,
    11.2, 94.1, 8.5,
    87.3, '{"visual": 85, "kinesthetic": 70, "auditory": 60}', '["problem_solving", "quick_learning", "consistency"]',
    '["time_management"]', '["continue_current_pace"]', '["advanced_challenges", "peer_mentoring_opportunities"]',
    95.5
),
-- At-Risk Learner Example
(
    '39da584e-99a5-4a9b-a8ac-9122bbee9e92',
    'f522ecd6-061c-4b49-8bde-e645064f7ee4',
    'weekly',
    '2025-09-07T00:00:00Z',
    '2025-09-13T23:59:59Z',
    180, 120, 4,
    25, 8, 2, 0.4,
    'declining', 1.3, 42.1,
    38.5, 1.8, 18, 4.2,
    32.0, 28.5, 35.2,
    -8.5, 35.8, 78.5, 12.8,
    45, '[19, 20, 21]', '{"video": 45, "quiz": 28, "reading": 35}',
    '{"mobile": 85, "desktop": 15}', 25.3, true,
    45.8, 28.2, 15.8,
    25.1, 22.7, 18.9,
    21.5, 5.8, 19.2,
    2.8, 38.2, 45.8,
    22.1, '{"visual": 30, "auditory": 25, "kinesthetic": 35}', '["persistence"]',
    '["engagement", "comprehension", "time_management", "motivation"]', 
    '["immediate_instructor_contact", "simplified_content", "motivational_support", "study_schedule_assistance"]', 
    '["remedial_exercises", "one_on_one_tutoring", "gamification_elements"]',
    65.2
),
-- Average Performer Example
(
    'bdad5a53-0de2-4d4e-acd1-a9e0463f4a46',
    'f522ecd6-061c-4b49-8bde-e645064f7ee4',
    'weekly',
    '2025-09-07T00:00:00Z',
    '2025-09-13T23:59:59Z',
    300, 240, 8,
    32, 24, 15, 1.1,
    'stable', 3.2, 68.3,
    65.8, 2.8, 28, 3.1,
    75.0, 62.8, 71.5,
    5.2, 68.5, 35.2, 5.8,
    40, '[14, 15, 16, 19, 20]', '{"video": 72, "quiz": 65, "reading": 58}',
    '{"desktop": 60, "mobile": 35, "tablet": 5}', 68.5, false,
    28.5, 72.1, 55.8,
    62.3, 65.9, 58.2,
    68.1, 3.2, 65.8,
    7.2, 71.8, 22.5,
    68.9, '{"visual": 65, "auditory": 55, "kinesthetic": 50}', '["steady_progress", "reliable_completion"]',
    '["engagement_variety", "challenge_level"]', '["content_variety", "goal_setting"]', 
    '["skill_challenges", "progress_tracking_tools"]',
    82.1
);

-- Insert sample performance benchmarks
INSERT INTO performance_benchmarks (
    benchmark_type, benchmark_scope, scope_id, content_type, difficulty_level,
    avg_completion_time_hours, avg_mastery_score, avg_engagement_score,
    median_attempts, success_rate_percentage, performance_percentiles,
    velocity_percentiles, engagement_percentiles, sample_size,
    computation_period_days
) VALUES 
('organizational', 'client', 'f522ecd6-061c-4b49-8bde-e645064f7ee4', 'course', 'intermediate',
 25.5, 72.8, 68.5, 3, 78.2,
 '{"P10": 45, "P25": 58, "P50": 72, "P75": 85, "P90": 92}',
 '{"P10": 0.8, "P25": 1.2, "P50": 1.8, "P75": 2.4, "P90": 3.1}',
 '{"P10": 52, "P25": 62, "P50": 71, "P75": 82, "P90": 91}',
 150, 30),
('industry', 'global', null, 'course', 'intermediate',
 28.2, 69.5, 65.8, 3, 73.8,
 '{"P10": 42, "P25": 55, "P50": 69, "P75": 82, "P90": 89}',
 '{"P10": 0.6, "P25": 1.0, "P50": 1.5, "P75": 2.2, "P90": 2.8}',
 '{"P10": 48, "P25": 58, "P50": 66, "P75": 78, "P90": 87}',
 5000, 90),
('cohort', 'client', 'f522ecd6-061c-4b49-8bde-e645064f7ee4', 'wod', 'beginner',
 8.5, 78.2, 72.1, 2, 85.3,
 '{"P10": 55, "P25": 68, "P50": 78, "P75": 88, "P90": 95}',
 '{"P10": 1.2, "P25": 1.8, "P50": 2.5, "P75": 3.2, "P90": 4.1}',
 '{"P10": 58, "P25": 68, "P50": 72, "P75": 82, "P90": 89}',
 45, 30);

-- Insert computation log entries
INSERT INTO analytics_computation_log (
    computation_type, computation_scope, scope_id, status, started_at, completed_at,
    records_processed, records_updated, errors_count, computation_duration_seconds,
    performance_metrics
) VALUES 
('weekly', 'client', 'f522ecd6-061c-4b49-8bde-e645064f7ee4', 'completed',
 '2025-09-13T10:00:00Z', '2025-09-13T10:02:15Z',
 150, 145, 0, 135,
 '{"avg_processing_time_ms": 890, "memory_usage_mb": 45, "query_performance": "optimal"}'),
('daily', 'user', 'a45cb75e-0260-4f25-bffb-34479c7c52ac', 'completed',
 '2025-09-13T11:30:00Z', '2025-09-13T11:30:45Z',
 1, 1, 0, 45,
 '{"avg_processing_time_ms": 245, "memory_usage_mb": 12, "query_performance": "good"}'),
('benchmarks', 'global', null, 'completed',
 '2025-09-13T09:00:00Z', '2025-09-13T09:15:30Z',
 5000, 5000, 2, 930,
 '{"avg_processing_time_ms": 1250, "memory_usage_mb": 128, "query_performance": "acceptable", "errors": "timeout_retries"}');

-- Verify the test data
SELECT 'Learning Analytics Data' as data_type, count(*) as records FROM learning_analytics
UNION ALL
SELECT 'Performance Benchmarks', count(*) FROM performance_benchmarks
UNION ALL
SELECT 'Computation Logs', count(*) FROM analytics_computation_log;