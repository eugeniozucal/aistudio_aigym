-- Migration: create_multi_community_support_schema
-- Created at: 1758804344

-- Migration: create_multi_community_support_schema
-- Enhances existing system to support many-to-many user-community relationships

-- Create user_communities junction table for many-to-many relationships
CREATE TABLE IF NOT EXISTS public.user_communities (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    community_id UUID NOT NULL,
    role TEXT DEFAULT 'member' CHECK (role IN ('member', 'moderator', 'admin')),
    joined_at TIMESTAMPTZ DEFAULT NOW(),
    invited_by UUID,
    signup_token TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, community_id)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_user_communities_user_id ON public.user_communities(user_id);
CREATE INDEX IF NOT EXISTS idx_user_communities_community_id ON public.user_communities(community_id);
CREATE INDEX IF NOT EXISTS idx_user_communities_signup_token ON public.user_communities(signup_token);
CREATE INDEX IF NOT EXISTS idx_user_communities_joined_at ON public.user_communities(joined_at DESC);

-- Enable RLS
ALTER TABLE public.user_communities ENABLE ROW LEVEL SECURITY;

-- RLS policies for user_communities
CREATE POLICY "Users can view their community memberships" ON public.user_communities
    FOR SELECT USING (
        user_id = auth.uid() OR 
        EXISTS (
            SELECT 1 FROM public.user_communities uc 
            WHERE uc.user_id = auth.uid() 
            AND uc.community_id = user_communities.community_id 
            AND uc.role IN ('admin', 'moderator')
        )
    );

CREATE POLICY "Users can manage memberships in their admin communities" ON public.user_communities
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.user_communities uc 
            WHERE uc.user_id = auth.uid() 
            AND uc.community_id = user_communities.community_id 
            AND uc.role = 'admin'
        )
    );

-- Create function to add user to community
CREATE OR REPLACE FUNCTION add_user_to_community(
    p_user_id UUID,
    p_community_id UUID,
    p_role TEXT DEFAULT 'member',
    p_signup_token TEXT DEFAULT NULL,
    p_invited_by UUID DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
    membership_id UUID;
BEGIN
    INSERT INTO public.user_communities (user_id, community_id, role, signup_token, invited_by)
    VALUES (p_user_id, p_community_id, p_role, p_signup_token, p_invited_by)
    ON CONFLICT (user_id, community_id) 
    DO UPDATE SET 
        role = EXCLUDED.role,
        signup_token = COALESCE(EXCLUDED.signup_token, user_communities.signup_token),
        updated_at = NOW()
    RETURNING id INTO membership_id;
    
    RETURN membership_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to remove user from community
CREATE OR REPLACE FUNCTION remove_user_from_community(
    p_user_id UUID,
    p_community_id UUID
)
RETURNS BOOLEAN AS $$
DECLARE
    rows_affected INTEGER;
BEGIN
    DELETE FROM public.user_communities 
    WHERE user_id = p_user_id AND community_id = p_community_id;
    
    GET DIAGNOSTICS rows_affected = ROW_COUNT;
    RETURN rows_affected > 0;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to get user communities
CREATE OR REPLACE FUNCTION get_user_communities(p_user_id UUID)
RETURNS TABLE(
    community_id UUID,
    community_name TEXT,
    role TEXT,
    joined_at TIMESTAMPTZ,
    brand_color TEXT,
    logo_url TEXT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        c.id,
        c.name,
        uc.role,
        uc.joined_at,
        c.brand_color,
        c.logo_url
    FROM public.user_communities uc
    JOIN public.communities c ON c.id = uc.community_id
    WHERE uc.user_id = p_user_id AND c.status = 'active'
    ORDER BY uc.joined_at DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to get community members
CREATE OR REPLACE FUNCTION get_community_members(p_community_id UUID)
RETURNS TABLE(
    user_id UUID,
    email TEXT,
    first_name TEXT,
    last_name TEXT,
    role TEXT,
    joined_at TIMESTAMPTZ
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        p.id,
        p.email,
        p.first_name,
        p.last_name,
        uc.role,
        uc.joined_at
    FROM public.user_communities uc
    JOIN public.profiles p ON p.id = uc.user_id
    WHERE uc.community_id = p_community_id
    ORDER BY uc.joined_at DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update the signup link generation function
CREATE OR REPLACE FUNCTION generate_community_signup_link(community_id UUID)
RETURNS TEXT AS $$
DECLARE
    token TEXT;
    base_url TEXT := 'https://u9ncd9m2gi3l.space.minimax.io';
    link TEXT;
BEGIN
    -- Generate a secure token
    token := encode(digest(community_id::TEXT || extract(epoch from now())::TEXT || gen_random_uuid()::TEXT, 'sha256'), 'hex');
    
    -- Update community with signup token and link
    UPDATE public.communities 
    SET signup_token = token,
        signup_link = base_url || '/signup?community=' || token,
        updated_at = NOW()
    WHERE id = community_id;
    
    -- Return the signup link
    RETURN base_url || '/signup?community=' || token;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update profiles RLS policies for multi-community access
DROP POLICY IF EXISTS "Users can view profiles in their community" ON public.profiles;
CREATE POLICY "Users can view profiles in shared communities" ON public.profiles
    FOR SELECT USING (
        id = auth.uid() OR
        EXISTS (
            SELECT 1 FROM public.user_communities uc1
            JOIN public.user_communities uc2 ON uc1.community_id = uc2.community_id
            WHERE uc1.user_id = auth.uid() AND uc2.user_id = profiles.id
        )
    );

-- Create trigger to automatically create user_communities entry when profile is created with community_id
CREATE OR REPLACE FUNCTION auto_create_community_membership()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.community_id IS NOT NULL THEN
        INSERT INTO public.user_communities (user_id, community_id, role)
        VALUES (NEW.id, NEW.community_id, 'member')
        ON CONFLICT (user_id, community_id) DO NOTHING;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER trigger_auto_create_community_membership
    AFTER INSERT OR UPDATE ON public.profiles
    FOR EACH ROW
    WHEN (NEW.community_id IS NOT NULL)
    EXECUTE FUNCTION auto_create_community_membership();;