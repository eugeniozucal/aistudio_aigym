-- Migration: create_test_user_account_fixed
-- Created at: 1758728058

-- Create test user account
DO $$
DECLARE
    test_user_id UUID := '123e4567-e89b-12d3-a456-426614174000';
    target_client_id UUID := 'e9563aa3-6ada-488f-9bbb-53932250b3f7';
BEGIN
    -- Insert into users table (our custom table)
    INSERT INTO public.users (id, client_id, email, first_name, last_name, created_at)
    VALUES (
        test_user_id,
        target_client_id,
        'ez@eugeniozucal.com',
        'Ez',
        'Zucal',
        NOW()
    )
    ON CONFLICT (client_id, email) DO NOTHING;

    -- Insert into profiles table
    INSERT INTO public.profiles (id, email, first_name, last_name, is_admin, client_id, created_at)
    VALUES (
        test_user_id,
        'ez@eugeniozucal.com',
        'Ez',
        'Zucal',
        FALSE,  -- Ensure this user is NOT an admin
        target_client_id,
        NOW()
    )
    ON CONFLICT (id) DO UPDATE SET
        email = EXCLUDED.email,
        first_name = EXCLUDED.first_name,
        last_name = EXCLUDED.last_name,
        is_admin = FALSE,
        client_id = EXCLUDED.client_id;

    -- Insert some sample programs for the training zone
    INSERT INTO public.programs (title, description, thumbnail_url, price, currency, client_id, status)
    VALUES 
        ('Advanced React Development', 'Master modern React patterns and best practices', '/images/react-course.jpg', 199.00, 'USD', target_client_id, 'active'),
        ('TypeScript Fundamentals', 'Learn TypeScript from scratch to advanced concepts', '/images/typescript-course.jpg', 149.00, 'USD', target_client_id, 'active'),
        ('Full Stack Development', 'Complete web development course with React and Node.js', '/images/fullstack-course.jpg', 299.00, 'USD', target_client_id, 'active'),
        ('UI/UX Design Principles', 'Design beautiful and functional user interfaces', '/images/design-course.jpg', 99.00, 'USD', target_client_id, 'active')
    ON CONFLICT DO NOTHING;

    -- Insert some sample posts for demonstration
    INSERT INTO public.posts (user_id, client_id, content, created_at)
    VALUES 
        (test_user_id, target_client_id, 'Welcome to our community! I''m excited to be here and learn from everyone. Looking forward to connecting with fellow developers!', NOW() - INTERVAL '2 hours'),
        (test_user_id, target_client_id, 'Just finished the React Development course - highly recommend it! The practical examples really helped me understand the concepts better.', NOW() - INTERVAL '1 hour'),
        (test_user_id, target_client_id, 'Has anyone worked with TypeScript before? I''m considering taking that course next and would love to hear about your experience.', NOW() - INTERVAL '30 minutes')
    ON CONFLICT DO NOTHING;

END $$;;