-- Migration: add_community_signup_functionality
-- Created at: 1758736591

-- Add signup fields to communities table
ALTER TABLE public.communities 
ADD COLUMN IF NOT EXISTS signup_token TEXT UNIQUE,
ADD COLUMN IF NOT EXISTS signup_link TEXT;

-- Create community signup link generation function
CREATE OR REPLACE FUNCTION generate_community_signup_link(community_id UUID)
RETURNS TEXT AS $$
DECLARE
    token TEXT;
    base_url TEXT := 'https://8ibrygvx1j4m.space.minimax.io';
BEGIN
    -- Generate a secure token
    token := encode(digest(community_id::TEXT || extract(epoch from now())::TEXT || gen_random_uuid()::TEXT, 'sha256'), 'hex');
    
    -- Update community with signup token and link
    UPDATE public.communities 
    SET signup_token = token,
        signup_link = base_url || '/signup?community=' || token
    WHERE id = community_id;
    
    -- Return the signup link
    RETURN base_url || '/signup?community=' || token;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to get community by signup token
CREATE OR REPLACE FUNCTION get_community_by_signup_token(token TEXT)
RETURNS TABLE(id UUID, name TEXT, brand_color TEXT, logo_url TEXT) AS $$
BEGIN
    RETURN QUERY
    SELECT c.id, c.name, c.brand_color, c.logo_url
    FROM public.communities c
    WHERE c.signup_token = token AND c.status = 'active';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add community_id column to profiles if it doesn't exist
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS community_id UUID;

-- Update RLS policies for community-scoped access
DROP POLICY IF EXISTS "Users can view profiles" ON public.profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert their own profile" ON public.profiles;

CREATE POLICY "Users can view profiles in their community" ON public.profiles
    FOR SELECT USING (
        community_id IN (
            SELECT p.community_id FROM public.profiles p WHERE p.id = auth.uid()
        )
    );

CREATE POLICY "Users can update their own profile" ON public.profiles
    FOR UPDATE USING (id = auth.uid());

CREATE POLICY "Users can insert their own profile" ON public.profiles
    FOR INSERT WITH CHECK (id = auth.uid());

-- Update users table to reference community_id instead of client_id
ALTER TABLE public.users 
ADD COLUMN IF NOT EXISTS community_id UUID;

-- Update RLS policies for users table to use community_id
DROP POLICY IF EXISTS "Users can view users for their client" ON public.users;
DROP POLICY IF EXISTS "Users can update their own data" ON public.users;

CREATE POLICY "Users can view users in their community" ON public.users
    FOR SELECT USING (
        community_id IN (
            SELECT u.community_id FROM public.users u WHERE u.id = auth.uid()
        )
    );

CREATE POLICY "Users can update their own data" ON public.users
    FOR UPDATE USING (id = auth.uid());

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_communities_signup_token ON public.communities(signup_token);
CREATE INDEX IF NOT EXISTS idx_profiles_community_id ON public.profiles(community_id);
CREATE INDEX IF NOT EXISTS idx_users_community_id ON public.users(community_id);;