-- Migration: fix_community_signup_function_types
-- Created at: 1758736959

-- Fix community signup function type mismatch
DROP FUNCTION IF EXISTS get_community_by_signup_token(TEXT);

CREATE OR REPLACE FUNCTION get_community_by_signup_token(token TEXT)
RETURNS TABLE(id UUID, name TEXT, brand_color VARCHAR, logo_url TEXT) AS $$
BEGIN
    RETURN QUERY
    SELECT c.id, c.name, c.brand_color, c.logo_url
    FROM public.communities c
    WHERE c.signup_token = token AND c.status = 'active';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;