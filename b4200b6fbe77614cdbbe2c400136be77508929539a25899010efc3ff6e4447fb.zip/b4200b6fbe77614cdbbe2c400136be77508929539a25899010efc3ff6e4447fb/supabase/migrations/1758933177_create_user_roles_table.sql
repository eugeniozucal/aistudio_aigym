-- Migration: create_user_roles_table
-- Created at: 1758933177

-- Create the core user_roles table for explicit role management
CREATE TABLE user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    role VARCHAR(50) NOT NULL CHECK (role IN ('admin', 'community_user')),
    community_id UUID NULL, -- Only for community users
    assigned_at TIMESTAMP DEFAULT NOW(),
    assigned_by UUID REFERENCES auth.users(id),
    is_active BOOLEAN DEFAULT true,
    UNIQUE(user_id, role)
);

-- Create indexes for performance
CREATE INDEX idx_user_roles_user_id ON user_roles(user_id);
CREATE INDEX idx_user_roles_role ON user_roles(role);
CREATE INDEX idx_user_roles_community_id ON user_roles(community_id);
CREATE INDEX idx_user_roles_active ON user_roles(is_active);

-- RLS Policies for security
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own roles" ON user_roles
FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all roles" ON user_roles
FOR ALL USING (
    EXISTS (
        SELECT 1 FROM user_roles ur 
        WHERE ur.user_id = auth.uid() 
        AND ur.role = 'admin' 
        AND ur.is_active = true
    )
);

-- Function to get user role with fallbacks
CREATE OR REPLACE FUNCTION get_user_role(p_user_id UUID)
RETURNS TABLE(role VARCHAR(50), community_id UUID) AS $$
DECLARE
    user_role_record RECORD;
    metadata_role TEXT;
    metadata_community_id UUID;
BEGIN
    -- First: Check explicit role assignment in user_roles table
    SELECT ur.role, ur.community_id INTO user_role_record
    FROM user_roles ur
    WHERE ur.user_id = p_user_id AND ur.is_active = true
    ORDER BY ur.assigned_at DESC
    LIMIT 1;
    
    IF FOUND THEN
        RETURN QUERY SELECT user_role_record.role, user_role_record.community_id;
        RETURN;
    END IF;
    
    -- Second: Check legacy metadata from auth.users
    SELECT 
        CASE 
            WHEN (raw_user_meta_data->>'is_admin')::boolean = true THEN 'admin'
            WHEN raw_user_meta_data->>'community_id' IS NOT NULL THEN 'community_user'
            ELSE NULL
        END,
        (raw_user_meta_data->>'community_id')::UUID
    INTO metadata_role, metadata_community_id
    FROM auth.users
    WHERE id = p_user_id;
    
    IF metadata_role IS NOT NULL THEN
        -- Auto-assign role based on metadata for smooth migration
        INSERT INTO user_roles (user_id, role, community_id, assigned_by)
        VALUES (p_user_id, metadata_role, metadata_community_id, p_user_id)
        ON CONFLICT (user_id, role) DO NOTHING;
        
        RETURN QUERY SELECT metadata_role::VARCHAR(50), metadata_community_id;
        RETURN;
    END IF;
    
    -- Third: Default assignment - community user with prompt for confirmation
    INSERT INTO user_roles (user_id, role, assigned_by)
    VALUES (p_user_id, 'community_user', p_user_id)
    ON CONFLICT (user_id, role) DO NOTHING;
    
    RETURN QUERY SELECT 'community_user'::VARCHAR(50), NULL::UUID;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function for admin to assign roles
CREATE OR REPLACE FUNCTION assign_user_role(
    p_user_id UUID,
    p_role VARCHAR(50),
    p_community_id UUID DEFAULT NULL,
    p_assigned_by UUID DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
    role_id UUID;
    assigner_id UUID;
BEGIN
    -- Get the assigner (current user if not specified)
    assigner_id := COALESCE(p_assigned_by, auth.uid());
    
    -- Verify the assigner has admin privileges
    IF NOT EXISTS (
        SELECT 1 FROM user_roles ur 
        WHERE ur.user_id = assigner_id 
        AND ur.role = 'admin' 
        AND ur.is_active = true
    ) THEN
        RAISE EXCEPTION 'Only admins can assign user roles';
    END IF;
    
    -- Validate role
    IF p_role NOT IN ('admin', 'community_user') THEN
        RAISE EXCEPTION 'Invalid role. Must be admin or community_user';
    END IF;
    
    -- For community users, community_id should be provided
    IF p_role = 'community_user' AND p_community_id IS NULL THEN
        RAISE EXCEPTION 'Community ID is required for community users';
    END IF;
    
    -- Insert or update role
    INSERT INTO user_roles (user_id, role, community_id, assigned_by)
    VALUES (p_user_id, p_role, p_community_id, assigner_id)
    ON CONFLICT (user_id, role) 
    DO UPDATE SET 
        community_id = EXCLUDED.community_id,
        assigned_by = EXCLUDED.assigned_by,
        assigned_at = NOW(),
        is_active = true
    RETURNING id INTO role_id;
    
    RETURN role_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create audit trail table for authentication events
CREATE TABLE auth_audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id),
    event_type VARCHAR(50) NOT NULL,
    event_data JSONB,
    ip_address INET,
    user_agent TEXT,
    success BOOLEAN NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_auth_audit_user_id ON auth_audit_log(user_id);
CREATE INDEX idx_auth_audit_event_type ON auth_audit_log(event_type);
CREATE INDEX idx_auth_audit_created_at ON auth_audit_log(created_at DESC);

-- Function to log authentication events
CREATE OR REPLACE FUNCTION log_auth_event(
    p_user_id UUID,
    p_event_type VARCHAR(50),
    p_event_data JSONB DEFAULT NULL,
    p_ip_address INET DEFAULT NULL,
    p_user_agent TEXT DEFAULT NULL,
    p_success BOOLEAN DEFAULT true
)
RETURNS UUID AS $$
DECLARE
    log_id UUID;
BEGIN
    INSERT INTO auth_audit_log (user_id, event_type, event_data, ip_address, user_agent, success)
    VALUES (p_user_id, p_event_type, p_event_data, p_ip_address, p_user_agent, p_success)
    RETURNING id INTO log_id;
    
    RETURN log_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;