-- Migration: update_signup_link_base_url_final
-- Created at: 1758805088

-- Migration: update_signup_link_base_url_final
-- Update the signup link generation function to use the new deployment URL

CREATE OR REPLACE FUNCTION generate_community_signup_link(community_id UUID)
RETURNS TEXT AS $$
DECLARE
    token TEXT;
    base_url TEXT := 'https://e0ysmyzk4k8r.space.minimax.io';
    link TEXT;
BEGIN
    -- Generate a secure token
    token := encode(digest(community_id::TEXT || extract(epoch from now())::TEXT || gen_random_uuid()::TEXT, 'sha256'), 'hex');
    
    -- Update community with signup token and link
    UPDATE public.communities 
    SET signup_token = token,
        signup_link = base_url || '/signup?community=' || token,
        updated_at = NOW()
    WHERE id = community_id;
    
    -- Return the signup link
    RETURN base_url || '/signup?community=' || token;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;