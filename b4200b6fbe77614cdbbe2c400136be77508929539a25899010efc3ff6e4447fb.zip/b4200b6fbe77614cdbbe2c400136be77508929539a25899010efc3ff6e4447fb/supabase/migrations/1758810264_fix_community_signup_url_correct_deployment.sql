-- Migration: fix_community_signup_url_correct_deployment
-- Created at: 1758810264

-- Fix critical base URL mismatch in community signup function
-- Current deployment: https://u9ncd9m2gi3l.space.minimax.io

CREATE OR REPLACE FUNCTION generate_community_signup_link(community_id UUID)
RETURNS TEXT AS $$
DECLARE
    token TEXT;
    base_url TEXT := 'https://u9ncd9m2gi3l.space.minimax.io';
    link TEXT;
BEGIN
    -- Generate a secure token
    token := encode(digest(community_id::TEXT || extract(epoch from now())::TEXT || gen_random_uuid()::TEXT, 'sha256'), 'hex');
    
    -- Update community with signup token and link
    UPDATE public.communities 
    SET signup_token = token,
        signup_link = base_url || '/signup?community=' || token,
        updated_at = NOW()
    WHERE id = community_id;
    
    -- Return the signup link
    RETURN base_url || '/signup?community=' || token;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Ensure test admin user exists
INSERT INTO public.admins (id, email, role, created_at, updated_at)
SELECT 
    id, 
    email, 
    'super_admin',
    NOW(),
    NOW()
FROM auth.users 
WHERE email = 'ez@aiworkify.com'
ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    role = EXCLUDED.role,
    updated_at = NOW();

-- Check if dlocal@aiworkify.com exists and needs admin record
INSERT INTO public.admins (id, email, role, created_at, updated_at)
SELECT 
    id, 
    email, 
    'super_admin',
    NOW(),
    NOW()
FROM auth.users 
WHERE email = 'dlocal@aiworkify.com'
ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    role = EXCLUDED.role,
    updated_at = NOW();;