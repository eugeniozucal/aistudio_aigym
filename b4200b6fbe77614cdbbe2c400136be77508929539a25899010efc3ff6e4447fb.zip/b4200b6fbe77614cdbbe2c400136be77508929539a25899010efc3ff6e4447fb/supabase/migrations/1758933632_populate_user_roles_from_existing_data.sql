-- Migration: populate_user_roles_from_existing_data
-- Created at: 1758933632

-- Migration to populate user_roles table from existing user data
-- This migration will migrate existing users to the new bulletproof authentication system

-- Function to migrate existing admin users
CREATE OR REPLACE FUNCTION migrate_existing_admins()
RETURNS INTEGER AS $$
DECLARE
    admin_record RECORD;
    role_count INTEGER := 0;
BEGIN
    -- Migrate admins from the admins table
    FOR admin_record IN 
        SELECT a.id, a.email, a.role, a.created_at
        FROM public.admins a
        WHERE EXISTS (SELECT 1 FROM auth.users au WHERE au.id = a.id)
    LOOP
        INSERT INTO public.user_roles (user_id, role, assigned_at, assigned_by, is_active)
        VALUES (
            admin_record.id,
            'admin',
            admin_record.created_at,
            admin_record.id, -- Self-assigned for migration
            true
        )
        ON CONFLICT (user_id, role) DO NOTHING;
        
        role_count := role_count + 1;
    END LOOP;
    
    RETURN role_count;
END;
$$ LANGUAGE plpgsql;

-- Function to migrate existing community users
CREATE OR REPLACE FUNCTION migrate_existing_community_users()
RETURNS INTEGER AS $$
DECLARE
    user_record RECORD;
    role_count INTEGER := 0;
    community_id_from_metadata UUID;
BEGIN
    -- Migrate community users from auth.users metadata
    FOR user_record IN 
        SELECT au.id, au.email, au.raw_user_meta_data, au.created_at
        FROM auth.users au
        WHERE au.raw_user_meta_data->>'community_id' IS NOT NULL
        AND NOT EXISTS (SELECT 1 FROM public.admins a WHERE a.id = au.id)
    LOOP
        -- Extract community_id from metadata
        community_id_from_metadata := (user_record.raw_user_meta_data->>'community_id')::UUID;
        
        INSERT INTO public.user_roles (user_id, role, community_id, assigned_at, assigned_by, is_active)
        VALUES (
            user_record.id,
            'community_user',
            community_id_from_metadata,
            user_record.created_at,
            user_record.id, -- Self-assigned for migration
            true
        )
        ON CONFLICT (user_id, role) DO NOTHING;
        
        role_count := role_count + 1;
    END LOOP;
    
    RETURN role_count;
END;
$$ LANGUAGE plpgsql;

-- Function to handle users without explicit roles
CREATE OR REPLACE FUNCTION assign_default_roles_to_remaining_users()
RETURNS INTEGER AS $$
DECLARE
    user_record RECORD;
    role_count INTEGER := 0;
BEGIN
    -- Assign default community_user role to remaining authenticated users
    FOR user_record IN 
        SELECT au.id, au.email, au.created_at
        FROM auth.users au
        WHERE au.email_confirmed_at IS NOT NULL -- Only confirmed users
        AND NOT EXISTS (SELECT 1 FROM public.user_roles ur WHERE ur.user_id = au.id)
        AND NOT EXISTS (SELECT 1 FROM public.admins a WHERE a.id = au.id)
    LOOP
        INSERT INTO public.user_roles (user_id, role, assigned_at, assigned_by, is_active)
        VALUES (
            user_record.id,
            'community_user',
            user_record.created_at,
            user_record.id, -- Self-assigned for migration
            true
        )
        ON CONFLICT (user_id, role) DO NOTHING;
        
        role_count := role_count + 1;
    END LOOP;
    
    RETURN role_count;
END;
$$ LANGUAGE plpgsql;

-- Execute the migration functions
DO $$
DECLARE
    admin_count INTEGER;
    community_count INTEGER;
    default_count INTEGER;
BEGIN
    -- Log the start of migration
    RAISE NOTICE 'Starting user roles migration...';
    
    -- Migrate admins
    SELECT migrate_existing_admins() INTO admin_count;
    RAISE NOTICE 'Migrated % admin users', admin_count;
    
    -- Migrate community users
    SELECT migrate_existing_community_users() INTO community_count;
    RAISE NOTICE 'Migrated % community users', community_count;
    
    -- Assign default roles to remaining users
    SELECT assign_default_roles_to_remaining_users() INTO default_count;
    RAISE NOTICE 'Assigned default roles to % users', default_count;
    
    -- Log completion
    RAISE NOTICE 'Migration completed. Total roles assigned: %', (admin_count + community_count + default_count);
END;
$$;

-- Clean up migration functions (they're no longer needed)
DROP FUNCTION IF EXISTS migrate_existing_admins();
DROP FUNCTION IF EXISTS migrate_existing_community_users();
DROP FUNCTION IF EXISTS assign_default_roles_to_remaining_users();;