-- Migration: create_user_community_schema
-- Created at: 1758727986

-- Create posts table for community forum
CREATE TABLE IF NOT EXISTS public.posts (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    client_id UUID NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create post_tags table for categorizing posts
CREATE TABLE IF NOT EXISTS public.post_tags (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    color VARCHAR(7) DEFAULT '#3B82F6',
    client_id UUID NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(name, client_id)
);

-- Create post_tag_assignments table for many-to-many relationship
CREATE TABLE IF NOT EXISTS public.post_tag_assignments (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    post_id UUID NOT NULL,
    tag_id UUID NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(post_id, tag_id)
);

-- Create programs table for training zone marketplace
CREATE TABLE IF NOT EXISTS public.programs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    thumbnail_url TEXT,
    price DECIMAL(10,2),
    currency VARCHAR(3) DEFAULT 'USD',
    client_id UUID NOT NULL,
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'draft')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create profiles table to match user requirements (maps to existing auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY,
    email TEXT,
    first_name TEXT,
    last_name TEXT,
    avatar_url TEXT,
    is_admin BOOLEAN DEFAULT FALSE,
    client_id UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create organizations table (maps to existing clients table)
CREATE VIEW public.organizations AS
SELECT 
    id,
    name,
    project_name,
    logo_url,
    color_hex as brand_color,
    has_forum as forum_enabled,
    'active' as status,
    created_at,
    updated_at
FROM public.clients;

-- Create members table (maps to existing users + profiles)
CREATE VIEW public.members AS
SELECT 
    u.id,
    u.client_id as organization_id,
    u.email,
    u.first_name,
    u.last_name,
    u.created_at,
    COALESCE(p.is_admin, false) as is_admin
FROM public.users u
LEFT JOIN public.profiles p ON u.id = p.id;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_posts_client_id ON public.posts(client_id);
CREATE INDEX IF NOT EXISTS idx_posts_user_id ON public.posts(user_id);
CREATE INDEX IF NOT EXISTS idx_posts_created_at ON public.posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_post_tags_client_id ON public.post_tags(client_id);
CREATE INDEX IF NOT EXISTS idx_post_tag_assignments_post_id ON public.post_tag_assignments(post_id);
CREATE INDEX IF NOT EXISTS idx_post_tag_assignments_tag_id ON public.post_tag_assignments(tag_id);
CREATE INDEX IF NOT EXISTS idx_programs_client_id ON public.programs(client_id);
CREATE INDEX IF NOT EXISTS idx_programs_status ON public.programs(status);
CREATE INDEX IF NOT EXISTS idx_profiles_client_id ON public.profiles(client_id);

-- Insert default GENERAL tag for each client
INSERT INTO public.post_tags (name, color, client_id)
SELECT 'GENERAL', '#6B7280', id
FROM public.clients
ON CONFLICT (name, client_id) DO NOTHING;

-- Enable RLS
ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.post_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.post_tag_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.programs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- RLS policies for posts (users can view and create posts for their client)
CREATE POLICY "Users can view posts for their client" ON public.posts
    FOR SELECT USING (
        client_id IN (
            SELECT client_id FROM public.users WHERE id = auth.uid()
        )
    );

CREATE POLICY "Users can create posts for their client" ON public.posts
    FOR INSERT WITH CHECK (
        user_id = auth.uid() AND
        client_id IN (
            SELECT client_id FROM public.users WHERE id = auth.uid()
        )
    );

CREATE POLICY "Users can update their own posts" ON public.posts
    FOR UPDATE USING (user_id = auth.uid());

CREATE POLICY "Users can delete their own posts" ON public.posts
    FOR DELETE USING (user_id = auth.uid());

-- RLS policies for post_tags
CREATE POLICY "Users can view tags for their client" ON public.post_tags
    FOR SELECT USING (
        client_id IN (
            SELECT client_id FROM public.users WHERE id = auth.uid()
        )
    );

CREATE POLICY "Users can manage tags for their client" ON public.post_tags
    FOR ALL USING (
        client_id IN (
            SELECT client_id FROM public.users WHERE id = auth.uid()
        )
    );

-- RLS policies for post_tag_assignments
CREATE POLICY "Users can view tag assignments for their client" ON public.post_tag_assignments
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.posts p 
            WHERE p.id = post_id AND p.client_id IN (
                SELECT client_id FROM public.users WHERE id = auth.uid()
            )
        )
    );

CREATE POLICY "Users can manage tag assignments for their posts" ON public.post_tag_assignments
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.posts p 
            WHERE p.id = post_id AND p.user_id = auth.uid()
        )
    );

-- RLS policies for programs
CREATE POLICY "Users can view programs for their client" ON public.programs
    FOR SELECT USING (
        client_id IN (
            SELECT client_id FROM public.users WHERE id = auth.uid()
        )
    );

CREATE POLICY "Admins can manage programs" ON public.programs
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.profiles p 
            WHERE p.id = auth.uid() AND p.is_admin = true
        )
    );

-- RLS policies for profiles
CREATE POLICY "Users can view all profiles" ON public.profiles
    FOR SELECT USING (true);

CREATE POLICY "Users can update their own profile" ON public.profiles
    FOR UPDATE USING (id = auth.uid());

CREATE POLICY "Users can insert their own profile" ON public.profiles
    FOR INSERT WITH CHECK (id = auth.uid());;